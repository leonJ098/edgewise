import Dashboard from '@/components/dashboard';
import { getBoard } from '@/lib/data/board';
import { easternDate,addDays } from '@/lib/safety/engine';
import { VERSION,TIMEZONE } from '@/lib/safety/rules';
import type { BoardData } from '@/lib/types';
import { requireWorkspace } from '@/lib/http';
export const dynamic='force-dynamic';
export default async function HomePage(){
  let board:BoardData;
  try {const workspace=await requireWorkspace().catch(()=>null);board=await getBoard(undefined,7,false,workspace?.maxPicks??3);} catch {const today=easternDate();board={games:[],sources:[{id:'connection',name:'Data connections',state:'error',detail:'The board could not load. Use Run analysis to retry; no sample picks are substituted.',checkedAt:null,url:'https://www.mlb.com/scores'}],today,startDate:today,endDate:addDays(today,6),refreshedAt:new Date().toISOString(),timezone:TIMEZONE,nflWeek:null,officialCount:0,algorithmVersion:VERSION,warnings:['Data is currently unavailable.']};}
  return <Dashboard initialBoard={board}/>;
}
