import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
export const metadata:Metadata={title:'Edgewise — The Disciplined Edge',description:'Safety-first NFL and MLB research. Verified upcoming games, transparent matchup analysis, exact-line checks and a disciplined official-pick card. No forced picks or guaranteed outcomes.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:ReactNode}){return <html lang="en"><body>{children}</body></html>;}
