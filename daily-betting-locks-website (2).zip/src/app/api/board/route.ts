import { NextResponse } from 'next/server';
import { getBoard } from '@/lib/data/board';
import { boardQuerySchema } from '@/lib/safety/validation';
import { easternDate } from '@/lib/safety/engine';
import { apiError,HttpError,requireWorkspace } from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(req:Request){
  try{
    const params=new URL(req.url).searchParams;
    const query=boardQuerySchema.parse({date:params.get('date')??undefined,days:params.get('days')??7});
    const date=query.date??easternDate();
    if(Math.abs(Date.parse(date)-Date.parse(easternDate()))>366*86400_000)throw new HttpError(400,'Choose a date within one year.');
    const workspace=await requireWorkspace().catch(()=>null);
    return NextResponse.json(await getBoard(date,query.days,false,workspace?.maxPicks??3),{headers:{'Cache-Control':'no-store'}});
  }catch(error){return apiError(error);}
}
