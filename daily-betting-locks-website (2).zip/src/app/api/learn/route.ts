import { NextResponse } from 'next/server';
import { desc, eq } from 'drizzle-orm';
import { db } from '@/db';
import { adaptiveLessons, adaptiveEvolution, adaptivePredictions } from '@/db/schema';
import { apiError } from '@/lib/http';
import { getModelState, learningCycle } from '@/lib/learn/evolve';
import { topRatings } from '@/lib/learn/ratings';
import { DEFAULT_WEIGHTS } from '@/lib/learn/model';
import type { LearnData, Sport } from '@/lib/types';

export const dynamic = 'force-dynamic';
export const maxDuration = 120;

async function learnData(): Promise<LearnData> {
  const [nfl, mlb] = await Promise.all([getModelState('NFL'), getModelState('MLB')]);
  const [lessons, evolution, recentRows, nflRatings, mlbRatings] = await Promise.all([
    db.select().from(adaptiveLessons).orderBy(desc(adaptiveLessons.createdAt)).limit(30),
    db.select().from(adaptiveEvolution).orderBy(desc(adaptiveEvolution.createdAt)).limit(30),
    db.select().from(adaptivePredictions).orderBy(desc(adaptivePredictions.createdAt)).limit(25),
    topRatings('NFL', 8),
    topRatings('MLB', 8),
  ]);
  const models = {} as LearnData['models'];
  for (const s of [nfl, mlb]) {
    const cal = Object.entries(s.calibration)
      .map(([bucket, v]) => ({ bucket, predicted: v.predicted, observed: v.observed, count: v.count }))
      .sort((a, b) => a.bucket.localeCompare(b.bucket));
    models[s.sport as Sport] = {
      version: s.version, weights: s.weights, defaultWeights: DEFAULT_WEIGHTS[s.sport as Sport],
      thresholds: s.thresholds,
      stats: {
        graded: s.stats.graded, wins: s.stats.wins, losses: s.stats.losses, pushes: s.stats.pushes,
        brier: s.stats.graded ? Math.round((s.stats.brierSum / s.stats.graded) * 1000) / 1000 : null,
        winRate: s.stats.graded ? s.stats.wins / s.stats.graded : null,
      },
      calibration: cal, updatedAt: s.updatedAt,
    };
  }
  return {
    models, lessons: lessons.map((l) => ({
      id: l.id, sport: l.sport as Sport, category: l.category, title: l.title,
      detail: l.detail, adjustment: l.adjustment as Record<string, number>,
      sampleSize: l.sampleSize, createdAt: l.createdAt.toISOString(),
    })),
    evolution: evolution.map((e) => ({
      id: e.id, sport: e.sport as Sport, fromVersion: e.fromVersion, toVersion: e.toVersion,
      trigger: e.trigger, summary: e.summary,
      metricsBefore: e.metricsBefore as Record<string, number | null>,
      metricsAfter: e.metricsAfter as Record<string, number | null>,
      weightDelta: e.weightDelta as Record<string, number>,
      gradedInCycle: e.gradedInCycle, createdAt: e.createdAt.toISOString(),
    })),
    recent: recentRows.map((r) => ({
      gameId: r.gameId, sport: r.sport as Sport, date: r.date,
      pick: r.predictedSide === 'home' ? r.homeName : r.awayName,
      confidence: r.confidence, tier: r.tier, status: r.status,
      score: r.homeScore !== null && r.awayScore !== null ? `${r.awayName.split(' ').slice(-1)} ${r.awayScore} – ${r.homeName.split(' ').slice(-1)} ${r.homeScore}` : 'vs ' + (r.predictedSide === 'home' ? r.awayName : r.homeName),
    })),
    ratings: [...nflRatings, ...mlbRatings],
  };
}

export async function GET() {
  try {
    return NextResponse.json(await learnData(), { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return apiError(error);
  }
}

export async function POST() {
  try {
    const cycle = await learningCycle();
    const data = await learnData();
    const summary = cycle.graded
      ? `Graded ${cycle.graded} finished game${cycle.graded === 1 ? '' : 's'} and updated the models. ${cycle.results.map((r) => r.summary).join(' ')}`
      : 'Checked for finished games — nothing new to grade yet. The model keeps every pending pick and learns the moment finals arrive.';
    return NextResponse.json({ ...data, cycleSummary: summary, graded: cycle.graded });
  } catch (error) {
    return apiError(error);
  }
}
