import { NextResponse } from 'next/server';
import { z } from 'zod';
import { apiError,HttpError } from '@/lib/http';
import { getCachedGame } from '@/lib/data/cache';
import { getAnalytics,mlbPitcherDetail } from '@/lib/data/providers';
import { attachInjuries } from '@/lib/data/injuries';
import { assessGame } from '@/lib/safety/engine';
import type { Game } from '@/lib/types';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}) {try{const {id}=await params;z.string().regex(/^(mlb|nfl)-\d+$/).parse(id);const game=await getCachedGame<Game>(id);if(!game)throw new HttpError(404,'This game is not in the verified schedule. Reload the board.');const [analytics,pitchers]=await Promise.all([getAnalytics(),mlbPitcherDetail(game),attachInjuries([game])]);const report=analytics.reports.find(r=>r.gameId===id);return NextResponse.json({game,analysis:assessGame(game,report),pitchers,injuries:{home:game.homeInjuries??null,away:game.awayInjuries??null}});}catch(error){return apiError(error);}}
