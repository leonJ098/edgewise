import { NextResponse } from 'next/server';
import { getModelLocks } from '@/lib/learn/locks';
import { boardQuerySchema } from '@/lib/safety/validation';
import { easternDate } from '@/lib/safety/engine';
import { apiError, HttpError } from '@/lib/http';

export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export async function GET(req: Request) {
  try {
    const params = new URL(req.url).searchParams;
    const query = boardQuerySchema.parse({ date: params.get('date') ?? undefined, days: params.get('days') ?? 7 });
    const date = query.date ?? easternDate();
    if (Math.abs(Date.parse(date) - Date.parse(easternDate())) > 366 * 86400000) {
      throw new HttpError(400, 'Choose a date within one year.');
    }
    const data = await getModelLocks(date, query.days);
    return NextResponse.json(data, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return apiError(error);
  }
}
