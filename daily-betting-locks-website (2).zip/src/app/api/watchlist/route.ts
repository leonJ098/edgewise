import { NextResponse } from 'next/server';
import { z } from 'zod';
import { and,eq } from 'drizzle-orm';
import { db } from '@/db';
import { watchlist } from '@/db/schema';
import { apiError,HttpError,requireWorkspace,readBody } from '@/lib/http';
import { getCachedGame } from '@/lib/data/cache';
import { cleanGame } from '@/lib/data/board';
import type { Game } from '@/lib/types';
const input=z.object({gameId:z.string().regex(/^(mlb|nfl)-\d+$/),note:z.string().trim().max(2000).optional()});
export async function POST(req:Request) {try{const workspace=await requireWorkspace(),body=input.parse(await readBody(req));const game=await getCachedGame<Game>(body.gameId);if(!game)throw new HttpError(404,'Reload the schedule before saving this game.');const [row]=await db.insert(watchlist).values({workspaceId:workspace.id,gameId:game.id,game:cleanGame(game),note:body.note??''}).onConflictDoNothing().returning();return NextResponse.json({success:true,id:row?.id});}catch(error){return apiError(error);}}
export async function DELETE(req:Request) {try{const workspace=await requireWorkspace(),body=input.parse(await readBody(req));await db.delete(watchlist).where(and(eq(watchlist.workspaceId,workspace.id),eq(watchlist.gameId,body.gameId)));return NextResponse.json({success:true});}catch(error){return apiError(error);}}
export async function PATCH(req:Request) {try{const workspace=await requireWorkspace(),body=input.parse(await readBody(req));const rows=await db.update(watchlist).set({note:body.note??''}).where(and(eq(watchlist.workspaceId,workspace.id),eq(watchlist.gameId,body.gameId))).returning({id:watchlist.id});if(!rows.length)throw new HttpError(404,'Save the game before adding a note.');return NextResponse.json({success:true});}catch(error){return apiError(error);}}
