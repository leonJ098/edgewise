import { NextResponse } from 'next/server';
import { apiError,readBody,HttpError } from '@/lib/http';
import { labSchema } from '@/lib/safety/validation';
import { scoreNFL,impliedProbability,fairAmerican,pitcherKModel } from '@/lib/safety/engine';
import { NFL_FACTORS } from '@/lib/safety/rules';
export async function POST(req:Request) {try{const input=labSchema.parse(await readBody(req));if(input.sport==='MLB')return NextResponse.json(pitcherKModel(input));if(NFL_FACTORS.some(f=>input.ratings[f.key]===undefined))throw new HttpError(400,'Supply all nine NFL factor ratings.');const p=input.probability/100,lower=Math.max(0,p-input.uncertainty/100),implied=impliedProbability(input.odds)!;const score=scoreNFL(input.ratings);return NextResponse.json({score,probability:p,lower,implied,edge:p-implied,conservativeEdge:lower-implied,fairOdds:fairAmerican(p),fairDecimal:1/p,pricePass:lower-implied>=.025,status:'RESEARCH ONLY',note:'Scores and user-entered probabilities are independent. This worksheet is not calibrated, source-verified, or eligible for the official card.'});}catch(error){return apiError(error);}}
