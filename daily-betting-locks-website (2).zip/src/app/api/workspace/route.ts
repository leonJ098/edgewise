import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { eq, desc } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '@/db';
import { workspaces,watchlist,analysisRuns } from '@/db/schema';
import { SESSION_COOKIE,apiError,readBody,requireWorkspace } from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET() {try{const cookie=(await cookies()).get(SESSION_COOKIE)?.value;let workspace:typeof workspaces.$inferSelect|undefined;
  if(cookie&&z.string().uuid().safeParse(cookie).success)[workspace]=await db.select().from(workspaces).where(eq(workspaces.id,cookie)).limit(1);
  if(!workspace)[workspace]=await db.insert(workspaces).values({}).returning();
  const [saved,runs]=await Promise.all([db.select({id:watchlist.id,gameId:watchlist.gameId,game:watchlist.game,createdAt:watchlist.createdAt,note:watchlist.note}).from(watchlist).where(eq(watchlist.workspaceId,workspace.id)).orderBy(desc(watchlist.createdAt)),db.select({id:analysisRuns.id,createdAt:analysisRuns.createdAt,gamesChecked:analysisRuns.gamesChecked,officialCount:analysisRuns.officialCount}).from(analysisRuns).where(eq(analysisRuns.workspaceId,workspace.id)).orderBy(desc(analysisRuns.createdAt)).limit(20)]);
  const response=NextResponse.json({displayName:workspace.displayName,maxPicks:workspace.maxPicks,defaultSport:workspace.defaultSport,watchlist:saved,runs},{headers:{'Cache-Control':'no-store'}});
  response.cookies.set(SESSION_COOKIE,workspace.id,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:365*86400,path:'/'});return response;
}catch(error){return apiError(error);}}
export async function PATCH(req:Request) {try{const workspace=await requireWorkspace();const body=z.object({displayName:z.string().trim().min(1).max(60),maxPicks:z.number().int().min(1).max(3),defaultSport:z.enum(['ALL','NFL','MLB'])}).parse(await readBody(req));await db.update(workspaces).set(body).where(eq(workspaces.id,workspace.id));return NextResponse.json({success:true,...body});}catch(error){return apiError(error);}}
