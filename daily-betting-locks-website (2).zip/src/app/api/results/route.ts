import { NextResponse } from 'next/server';
import { and,eq,desc } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '@/db';
import { officialSelections } from '@/db/schema';
import { apiError,HttpError,readBody,requireWorkspace } from '@/lib/http';
import { gradeVerified } from '@/lib/data/grading';
export const dynamic='force-dynamic';
export async function GET() {try{const workspace=await requireWorkspace();const records=await db.select({id:officialSelections.id,game:officialSelections.game,analysis:officialSelections.analysis,publishedAt:officialSelections.publishedAt,grade:officialSelections.grade,actual:officialSelections.actual,resultSource:officialSelections.resultSource,gradedAt:officialSelections.gradedAt,review:officialSelections.review}).from(officialSelections).where(eq(officialSelections.workspaceId,workspace.id)).orderBy(desc(officialSelections.publishedAt)).limit(200);
  const settled=records.filter(r=>r.grade==='win'||r.grade==='loss'),wins=settled.filter(r=>r.grade==='win').length;
  const forecasted=settled.filter(r=>r.analysis.probability!==null);
  const brier=forecasted.length>=10?forecasted.reduce((s,r)=>s+Math.pow(r.analysis.probability!-(r.grade==='win'?1:0),2),0)/forecasted.length:null;
  return NextResponse.json({records,stats:{settled:settled.length,wins,losses:settled.length-wins,winRate:settled.length?wins/settled.length:null,brier,sampleSize:forecasted.length}},{headers:{'Cache-Control':'no-store'}});
}catch(error){return apiError(error);}}
export async function POST(req:Request) {try{await readBody(req);const workspace=await requireWorkspace();const pending=await db.select().from(officialSelections).where(and(eq(officialSelections.workspaceId,workspace.id),eq(officialSelections.grade,'pending'))).limit(30);let graded=0,unavailable=0;
  await Promise.all(pending.map(async row=>{try{const result=await gradeVerified(row.game,row.analysis);if(result){await db.update(officialSelections).set({...result,gradedAt:new Date()}).where(and(eq(officialSelections.id,row.id),eq(officialSelections.grade,'pending')));graded++;}else unavailable++;}catch{unavailable++;}}));
  return NextResponse.json({success:true,graded,pending:unavailable,message:graded?`${graded} official result${graded===1?'':'s'} verified. ${unavailable} awaiting final or settlement evidence.`:pending.length?'No new verifiable finals. Pending selections were not simulated.':'No official picks to grade yet.'});
}catch(error){return apiError(error);}}
export async function PATCH(req:Request) {try{const workspace=await requireWorkspace();const body=z.object({id:z.string().uuid(),cause:z.enum(['Good model read','Bad matchup read','Workload error','Early-hook error','Lineup error','Injury error','Bullpen error','Variance','Small sample','Incorrect probability','Bad line value']),notes:z.string().trim().min(10).max(1500)}).parse(await readBody(req));const [row]=await db.select().from(officialSelections).where(and(eq(officialSelections.id,body.id),eq(officialSelections.workspaceId,workspace.id))).limit(1);if(!row||row.grade==='pending')throw new HttpError(400,'Only a verified, graded official pick can be reviewed.');await db.update(officialSelections).set({review:`${body.cause}: ${body.notes}`}).where(eq(officialSelections.id,row.id));return NextResponse.json({success:true});}catch(error){return apiError(error);}}
