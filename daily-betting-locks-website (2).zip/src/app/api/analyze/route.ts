import { NextResponse } from 'next/server';
import { and,eq,desc,gte } from 'drizzle-orm';
import { db } from '@/db';
import { analysisRuns,officialSelections } from '@/db/schema';
import { apiError,HttpError,requireWorkspace,readBody } from '@/lib/http';
import { getBoard,cleanGame } from '@/lib/data/board';
import { boardQuerySchema } from '@/lib/safety/validation';
import { easternDate } from '@/lib/safety/engine';
import { VERSION } from '@/lib/safety/rules';
import type { Assessment } from '@/lib/types';
export async function POST(req:Request) {try{
  const workspace=await requireWorkspace(),query=boardQuerySchema.parse(await readBody(req));
  const [last]=await db.select({createdAt:analysisRuns.createdAt}).from(analysisRuns).where(eq(analysisRuns.workspaceId,workspace.id)).orderBy(desc(analysisRuns.createdAt)).limit(1);
  if(last&&Date.now()-last.createdAt.getTime()<30_000)throw new HttpError(429,'Analysis was just refreshed. Please wait 30 seconds before running it again.');
  const date=query.date??easternDate();if(Math.abs(Date.parse(date)-Date.parse(easternDate()))>366*86400_000)throw new HttpError(400,'Choose a date within one year.');
  const board=await getBoard(date,query.days,true,workspace.maxPicks);
  const existing=await db.select().from(officialSelections).where(and(eq(officialSelections.workspaceId,workspace.id),gte(officialSelections.publishedAt,new Date(Date.now()-48*3600_000))));
  const key=(a:Assessment)=>[a.gameId,a.market,a.side,a.playerId,a.direction,a.exactLine].join(':');
  const todays=existing.filter(p=>p.game.date===board.today),groups=new Set(todays.map(p=>p.analysis.correlationGroup)),games=new Set(todays.map(p=>p.analysis.gameId));
  let total=todays.length;
  for(const g of [...board.games].sort((a,b)=>(b.analysis.lower??0)-(a.analysis.lower??0))) {
    if(g.analysis.decision!=='OFFICIAL')continue;
    const selectionKey=key(g.analysis);if(todays.some(p=>p.selectionKey===selectionKey))continue;
    if(total>=workspace.maxPicks||groups.has(g.analysis.correlationGroup)||games.has(g.id)){g.analysis={...g.analysis,decision:'WATCH',label:'Daily exposure limit',reasons:['An existing official selection already uses this game, risk group, or today’s card capacity.']};continue;}
    await db.insert(officialSelections).values({workspaceId:workspace.id,selectionKey,game:cleanGame(g),analysis:g.analysis}).onConflictDoNothing();total++;groups.add(g.analysis.correlationGroup);games.add(g.id);
  }
  board.officialCount=board.games.filter(g=>g.analysis.decision==='OFFICIAL').length;
  const [run]=await db.insert(analysisRuns).values({workspaceId:workspace.id,gamesChecked:board.games.length,officialCount:board.officialCount,algorithmVersion:VERSION,sources:board.sources,decisions:board.games.map(g=>g.analysis)}).returning({id:analysisRuns.id});
  return NextResponse.json({...board,runId:run.id});
}catch(error){return apiError(error);}}
