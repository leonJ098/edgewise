import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { db } from '@/db';
import { workspaces } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { z,ZodError } from 'zod';
export const SESSION_COOKIE='edgewise_workspace';
export class HttpError extends Error { constructor(public status:number,message:string){super(message);} }
export async function requireWorkspace(){
  const id=(await cookies()).get(SESSION_COOKIE)?.value;
  if(!id||!z.string().uuid().safeParse(id).success)throw new HttpError(401,'Open your workspace before saving.');
  const [workspace]=await db.select().from(workspaces).where(eq(workspaces.id,id)).limit(1);
  if(!workspace)throw new HttpError(401,'Workspace expired. Reload to reconnect.');
  return workspace;
}
export async function readBody(req:Request){
  const origin=req.headers.get('origin');
  if(origin){
    // The managed HTTPS reverse proxy may use an internal HTTP request URL.
    // Compare the external request authority rather than rejecting valid TLS termination.
    const hosts=new Set([new URL(req.url).host,req.headers.get('host'),req.headers.get('x-forwarded-host')?.split(',')[0].trim()].filter(Boolean).map(host=>host!.toLowerCase()));
    let parsed:URL;try{parsed=new URL(origin);}catch{throw new HttpError(403,'Cross-origin changes are not permitted.');}
    if(!['http:','https:'].includes(parsed.protocol)||!hosts.has(parsed.host.toLowerCase()))throw new HttpError(403,'Cross-origin changes are not permitted.');
  }
  const text=await req.text();
  if(text.length>100_000)throw new HttpError(413,'Request is too large.');
  try{return JSON.parse(text);}catch{throw new HttpError(400,'A valid JSON body is required.');}
}
export function apiError(error:unknown){
  if(error instanceof HttpError)return NextResponse.json({error:error.message},{status:error.status});
  if(error instanceof ZodError)return NextResponse.json({error:error.issues.map(i=>`${i.path.join('.')}: ${i.message}`).join('; ')},{status:400});
  console.error('Edgewise request failed',error instanceof Error?error.message:'Unknown error');
  return NextResponse.json({error:'The request could not be completed. Please try again.'},{status:500});
}
