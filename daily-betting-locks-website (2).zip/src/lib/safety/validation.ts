import { z } from 'zod';

const url = z.string().url().refine((v) => v.startsWith('https://'), 'An HTTPS evidence URL is required');
const time = z.string().datetime({ offset: true });
const probability = z.number().min(0).max(1);
export const marketSchema = z.enum(['moneyline', 'pitcher_strikeouts', 'pitcher_outs', 'pitcher_earned_runs', 'batter_hits', 'batter_total_bases', 'batter_home_runs', 'team_total', 'f5_total']);
export const reportSchema = z.object({
  gameId: z.string().min(1).max(80), sport: z.enum(['NFL', 'MLB']), startsAt: time,
  homeId: z.string().min(1), awayId: z.string().min(1), generatedAt: time,
  market: marketSchema, side: z.enum(['home', 'away']),
  player: z.string().min(2).max(100).optional(), playerId: z.string().regex(/^\d+$/).optional(),
  line: z.number().min(0).max(100).optional(), direction: z.enum(['over', 'under']).optional(),
  factors: z.record(z.string(), z.object({ rating: z.number().min(0).max(10), rationale: z.string().min(15).max(1500), sourceUrl: url, checkedAt: time })),
  evidence: z.array(z.object({ key: z.string().max(40), verified: z.boolean(), detail: z.string().min(10).max(1200), sourceUrl: url, checkedAt: time })).max(30),
  risks: z.array(z.string().max(60)).max(30), modeledRisks: z.array(z.string().max(60)).max(30),
  probability: z.object({ estimate: probability, lower: probability, upper: probability, riskModelVersion: z.string(), modelVersion: z.string().max(80), sourceUrl: url,
    calibration: z.object({ sampleSize: z.number().int().min(1), brierScore: z.number().min(0).max(1), method: z.string().min(10).max(300), trainedThrough: time, evaluationStart: time, evaluationEnd: time })
  }).refine((v) => v.lower <= v.estimate && v.estimate <= v.upper && v.lower > 0 && v.upper < 1, 'Invalid uncertainty interval'),
  scripts: z.record(z.string(), z.string().min(15).max(1200)),
  upsetPaths: z.array(z.string().min(10).max(1000)).max(10),
  strengths: z.array(z.string().min(10).max(600)).min(2).max(8),
  mainRisk: z.string().min(15).max(1000),
  correlationGroup: z.string().min(1).max(100),
  entryEvaluation: z.object({ expectedReturnLower: z.number().min(-1).max(10), jointModel: z.literal(true), rulesSourceUrl: url, checkedAt: time, detail: z.string().min(30) }).optional(),
}).superRefine((report, context) => {
  const playerProp = report.market.startsWith('pitcher_') || report.market.startsWith('batter_');
  if (playerProp && (!report.player || !report.playerId || report.line === undefined || !report.direction)) {
    context.addIssue({ code: 'custom', path: ['playerId'], message: 'Player props require the exact player name, MLB ID, numeric line and direction.' });
  }
});
export const reportFeedSchema = z.object({ reports: z.array(reportSchema).max(500) });
export type AnalyticsReport = z.infer<typeof reportSchema>;
export const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((s) => {
  const d = new Date(s + 'T12:00:00Z'); return !isNaN(d.getTime()) && d.toISOString().slice(0,10) === s;
}, 'Invalid calendar date');
export const boardQuerySchema = z.object({ date: dateSchema.optional(), days: z.coerce.number().int().min(1).max(14).default(7) });
export const labSchema = z.discriminatedUnion('sport', [
  z.object({ sport: z.literal('NFL'), ratings: z.record(z.string(), z.number().min(0).max(10)), probability: z.number().min(1).max(99), uncertainty: z.number().min(1).max(30), odds: z.number().int().refine((v) => Math.abs(v) >= 100 && Math.abs(v) <= 5000, 'Use American odds of at least +100 or at most -100') }),
  z.object({ sport: z.literal('MLB'), pitcherK: z.number().min(5).max(50), opponentK: z.number().min(5).max(50), sample: z.number().int().min(1).max(2000), batters: z.number().int().min(5).max(36), hook: z.number().min(0).max(75), line: z.number().min(0.5).max(15.5) }),
]);
