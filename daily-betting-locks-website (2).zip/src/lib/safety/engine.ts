import type { Assessment, Game, MoneylineQuote, Penalty, Sport, Verification } from '../types';
import type { AnalyticsReport } from './validation';
import { checksFor, factorsFor, HARD_RISKS, RISK_PENALTIES, TIMEZONE, VERSION, NFL_FACTORS } from './rules';

export function easternDate(now = new Date()) { return new Intl.DateTimeFormat('en-CA', { timeZone: TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now); }
export function addDays(date: string, days: number) { const d = new Date(date + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + days); return d.toISOString().slice(0,10); }
export function fresh(when: string | undefined, minutes: number, now = new Date()) { if (!when) return false; const age = now.getTime() - new Date(when).getTime(); return Number.isFinite(age) && age >= -60_000 && age <= minutes * 60_000; }
export function impliedProbability(odds: number) { if (!Number.isFinite(odds) || Math.abs(odds) < 100) return null; return odds < 0 ? -odds / (-odds + 100) : 100 / (odds + 100); }
export function fairAmerican(p: number) { if (p <= 0 || p >= 1) return null; return Math.round(p >= .5 ? -100 * p / (1-p) : 100 * (1-p) / p); }
export function noVig(quote: MoneylineQuote, side: 'home' | 'away') { const home = impliedProbability(quote.home), away = impliedProbability(quote.away); return home !== null && away !== null ? (side === 'home' ? home : away) / (home + away) : null; }
export function nflRecentForm(recent: [number, number, number]) { return recent[0] * .5 + recent[1] * .3 + recent[2] * .2; }
export function mlbSkillBlend(season: number, recent: number, matchup: number) { return season * .6 + recent * .25 + matchup * .15; }
export function scoreNFL(ratings: Record<string, number>) { return NFL_FACTORS.reduce((sum, f) => sum + (ratings[f.key] ?? 0) / 10 * f.weight, 0); }

// A research-only posterior-predictive workload mixture. Not a calibrated betting forecast.
function logGamma(z: number): number {
  const p = [676.5203681218851,-1259.1392167224028,771.32342877765313,-176.61502916214059,12.507343278686905,-.13857109526572012,9.9843695780195716e-6,1.5056327351493116e-7];
  if (z < .5) return Math.log(Math.PI) - Math.log(Math.sin(Math.PI * z)) - logGamma(1-z);
  z -= 1; let x = .99999999999980993; for (let i=0;i<p.length;i++) x += p[i]/(z+i+1);
  const t = z + p.length - .5; return .5*Math.log(2*Math.PI)+(z+.5)*Math.log(t)-t+Math.log(x);
}
function betaBinomial(n: number, k: number, alpha: number, beta: number) {
  return Math.exp(logGamma(n+1)-logGamma(k+1)-logGamma(n-k+1)+logGamma(k+alpha)+logGamma(n-k+beta)-logGamma(n+alpha+beta)-logGamma(alpha)-logGamma(beta)+logGamma(alpha+beta));
}
export function pitcherKModel(input: { pitcherK: number; opponentK: number; sample: number; batters: number; hook: number; line: number }) {
  const prior = .225, priorVolume = 200;
  const shrunk = ((input.pitcherK/100)*input.sample + prior*priorVolume)/(input.sample+priorVolume);
  const rate = .7*shrunk + .3*(input.opponentK/100);
  const concentration = Math.min(200, input.sample + 25), alpha = rate*concentration, beta = (1-rate)*concentration;
  const hook = input.hook/100;
  const scenarios = [{ label: 'Early exit', batters: Math.max(1,Math.round(input.batters*.6)), weight: hook }, { label: 'Expected outing', batters: input.batters, weight: .9-hook }, { label: 'Extended outing', batters: Math.round(input.batters*1.15), weight: .1 }];
  let over=0, under=0, push=0;
  for (const s of scenarios) for (let k=0;k<=s.batters;k++) { const p = s.weight*betaBinomial(s.batters,k,alpha,beta); if (k>input.line) over+=p; else if (k<input.line) under+=p; else push+=p; }
  return { over, under, push, adjustedKRate: rate, expectedKs: scenarios.reduce((s,v)=>s+v.batters*v.weight*rate,0), scenarios, smallSample: input.sample < 200, status: 'RESEARCH ONLY', note: 'Workload-mixture estimate with a 22.5% illustrative prior. Not out-of-sample calibrated; never eligible for the official card.' };
}

const EVIDENCE_MINUTES: Record<string, number> = { starters: 90, backups: 180, injuries: 90, lineup: 90, weather: 60, workload: 360, bullpen: 180, park: 720, scripts: 360, metrics: 720, trenches: 360 };
export function assessGame(game: Game, report: AnalyticsReport | undefined, now = new Date()): Assessment {
  const reasons: string[] = [];
  const sameGame = !!report && report.gameId===game.id && report.sport===game.sport && report.homeId===game.home.id && report.awayId===game.away.id && Math.abs(Date.parse(report.startsAt)-Date.parse(game.startsAt))<60_000;
  if (report && !sameGame) { reasons.push('Analytics identity or start time does not match this exact game.'); report = undefined; }
  const strengths = report?.strengths ?? [], market = report?.market ?? 'moneyline';
  const isProp = market !== 'moneyline';
  const isPlayerProp = market.startsWith('pitcher_') || market.startsWith('batter_');
  if (report && isPlayerProp && (!report.player || !report.playerId || report.line === undefined || !report.direction)) reasons.push('The exact player identity, market line and direction are required.');
  if (report && market.startsWith('pitcher_') && game[report.side].starter?.id !== report.playerId) reasons.push('Pitcher identity does not match the current scheduled starter; re-verification is required.');
  const quote = !isProp && game.quote && fresh(game.quote.observedAt,15,now) ? game.quote : null;
  const propQuote = isProp && report ? game.props.find(p => p.bookmaker==='underdog' && p.market===market && p.player.toLowerCase()===report.player?.toLowerCase() && p.line===report.line && p.direction===report.direction && fresh(p.observedAt,15,now)) : undefined;
  const calibration = report?.probability.calibration;
  const calibrated = !!report && !!calibration && calibration.sampleSize >= 200 && calibration.brierScore < .25 && Date.parse(calibration.trainedThrough) < Date.parse(calibration.evaluationStart) && Date.parse(calibration.evaluationStart) <= Date.parse(calibration.evaluationEnd) && Date.parse(calibration.evaluationEnd) < Date.parse(game.startsAt) && Date.parse(calibration.evaluationEnd) <= now.getTime() && report.probability.riskModelVersion===VERSION && fresh(report.generatedAt,60,now);
  const scheduleOk = fresh(game.fetchedAt,20,now) && !game.scheduleStale && !game.timeTbd && !game.conditional && game.status==='scheduled' && Date.parse(game.startsAt)>now.getTime();
  const checks: Verification[] = checksFor(game.sport).map(([key,label]) => {
    if (key==='schedule') return { key,label,status:scheduleOk?'verified':'stale', detail:scheduleOk?`${game.away.name} at ${game.home.name}; ${game.date}${game.week?`; week ${game.week}`:''}.`: 'Schedule is stale, start time is unresolved, conditional, or game is no longer upcoming.',sourceUrl:game.sourceUrl,checkedAt:game.fetchedAt };
    if (key==='line') return { key,label:isProp?'Exact Underdog player & line':label,status:(isProp?!!propQuote:!!quote)?'verified':'missing',detail: isProp?(propQuote?`${propQuote.player} ${propQuote.direction} ${propQuote.line}; Underdog only.`:'No fresh, exact Underdog player, side and line match. Other books are never substituted.'):(quote?`${quote.bookmaker}: home ${quote.home}, away ${quote.away}.`:'A current two-sided moneyline and timestamp are required.'),sourceUrl:propQuote?.sourceUrl??quote?.sourceUrl,checkedAt:propQuote?.observedAt??quote?.observedAt };
    if (key==='calibration') return { key,label,status:calibrated?'verified':'missing',detail:calibrated?`${calibration!.sampleSize} held-out forecasts; Brier ${calibration!.brierScore.toFixed(3)}. Provider-reported validation.`:'Requires a risk-adjusted forecast, uncertainty interval and dated out-of-sample validation. Scores are not win probabilities.',sourceUrl:report?.probability.sourceUrl,checkedAt:report?.generatedAt };
    const proof=report?.evidence.find(e=>e.key===key && e.verified);
    const recent=proof && fresh(proof.checkedAt,EVIDENCE_MINUTES[key]??180,now);
    let detail=proof?.detail??'Verified evidence has not been supplied.';
    if(key==='starters'&&!proof&&game.sport==='MLB') detail=`${game.away.starter?.name??'Away starter TBD'} / ${game.home.starter?.name??'Home starter TBD'}. Probable pitchers are not confirmed starters.`;
    return { key,label,status:!proof?'missing':recent?'verified':'stale',detail,sourceUrl:proof?.sourceUrl,checkedAt:proof?.checkedAt };
  });
  const factors=factorsFor(game.sport).map(f=>{ const v=report?.factors[f.key]; const valid=v && fresh(v.checkedAt,720,now); return { key:f.key,label:f.label,weight:f.weight,rating:valid?v.rating:null,points:valid?v.rating/10*f.weight:null,detail:valid?v.rationale:f.detail }; });
  const risks=new Set(report?.risks??[]);
  if (game.sport==='NFL' && new Intl.DateTimeFormat('en-US',{timeZone:TIMEZONE,weekday:'long'}).format(new Date(game.startsAt))==='Thursday') risks.add('thursday');
  if (/coors/i.test(game.venue)) risks.add('coors');
  if (market==='pitcher_strikeouts' && (report?.line??0)>=7.5) risks.add('high_k');
  if (market==='batter_total_bases') risks.add('total_bases');
  if (market==='batter_home_runs') risks.add('home_runs');
  if (market==='batter_hits' && (report?.line??0)>=1.5) risks.add('two_hits');
  if (market==='team_total' && (report?.line??100)<=4.5) risks.add('thin_total');
  if ((report?.upsetPaths.length??0)>=2) risks.add('multiple_upsets');
  const penalties: Penalty[]=Array.from(risks).filter(r=>RISK_PENALTIES[r]).map(key=>({key,...RISK_PENALTIES[key]}));
  const score=factors.every(f=>f.points!==null)?Math.round(Math.max(0,factors.reduce((s,f)=>s+(f.points??0),0)-penalties.reduce((s,p)=>s+p.points,0))*10)/10:null;
  const blocked = checks.filter(c=>c.status!=='verified');
  if(!report) reasons.push('Advanced matchup evidence and a validated probability forecast are not connected.');
  if(blocked.length) reasons.push(`${blocked.length} required checks are unresolved: ${blocked.map(c=>c.label).join(', ')}.`);
  if(game.date!==easternDate(now)) reasons.push('Upcoming watch only. Official picks require same-day re-verification in Eastern Time.');
  if(game.sport==='NFL'&&!game.week) reasons.push('The exact NFL week has not been verified.');
  if(game.sport==='NFL'&&market!=='moneyline') reasons.push('The NFL framework supports moneyline only.');
  for (const r of risks) if (HARD_RISKS[r]) reasons.push(`Hard pass: ${HARD_RISKS[r]}.`);
  if(report && Array.from(risks).some(r=>!report!.modeledRisks.includes(r))) reasons.push('The probability forecast does not account for every identified risk.');
  if(report && score===null) reasons.push('One or more weighted matchup factors are missing or stale.');
  if(score!==null && score<85) reasons.push(`Safety score ${score}/100 is below the 85-point official threshold.`);
  if(report && game.sport==='NFL' && ['control','close','trailing','underdogLead','turnovers'].some(k=>!report!.scripts[k])) reasons.push('All five football game scripts must be documented.');
  if(risks.has('multiple_upsets')) reasons.push('At least two realistic upset paths: reject for the max-safety card.');
  if(market==='pitcher_strikeouts'&&report?.direction==='over'&&risks.has('rookie')&&risks.has('high_k')) reasons.push('Limited MLB sample plus an aggressive K line is an automatic pass.');
  if(market==='pitcher_outs'&&report?.direction==='under'&&!report.evidence.some(e=>e.key==='outs_restriction'&&e.verified&&fresh(e.checkedAt,360,now))) reasons.push('Outs Under needs documented pitch-limit or early-removal evidence, not fatigue alone.');
  if(market==='f5_total'||market==='team_total') reasons.push('Exact team/F5 market settlement and price feed are not supported yet; no official pick.');
  for (const risk of risks) if (!HARD_RISKS[risk] && !RISK_PENALTIES[risk]) reasons.push(`Unclassified risk requires review: ${risk}.`);
  const probabilityAvailable = calibrated && (!isProp || !!propQuote);
  const probability=probabilityAvailable?report!.probability.estimate:null, lower=probabilityAvailable?report!.probability.lower:null, upper=probabilityAvailable?report!.probability.upper:null;
  const side=report?.side??null, odds=side&&quote?quote[side]:null;
  const implied=odds!==null?impliedProbability(odds):null;
  const edge=probability!==null&&implied!==null?probability-implied:null;
  const highVariance=['batter_total_bases','batter_home_runs','team_total'].includes(market)||risks.has('coors');
  if(lower!==null&&lower<(highVariance?.72:game.sport==='NFL'?.68:.65)) reasons.push('Conservative probability bound is below the market-specific safety threshold.');
  if(lower!==null&&upper!==null&&upper-lower>.14) reasons.push('Probability uncertainty is too wide.');
  if(lower!==null&&implied!==null&&lower-implied<(game.sport==='NFL'?.025:highVariance?.08:.04)) reasons.push('The conservative probability bound does not clear the price by a sufficient margin.');
  if(odds!==null&&odds < -500) reasons.push('Moneyline is more expensive than -500: automatic price pass.');
  if(odds!==null&&odds < -350 && ((score??0)<95 || lower===null || implied===null || lower-implied<.04)) reasons.push('An expensive favorite needs at least 95/100 and four percentage points of conservative price edge.');
  if(odds!==null&&odds<=-110&&odds>=-160&&game.sport==='NFL'&&((score??0)<90||!factors.some(f=>['qb','trenches','defense'].includes(f.key)&&(f.rating??0)>=9))) reasons.push('Short favorite lacks exceptional, identifiable football separation.');
  if(isProp && (!report?.entryEvaluation || !fresh(report.entryEvaluation.checkedAt,15,now) || report.entryEvaluation.expectedReturnLower < .03)) reasons.push('Underdog entry-dependent payout and joint outcome risk must be verified. No standalone implied probability is invented.');
  const decision=reasons.length===0?'OFFICIAL':(game.status==='scheduled'&&blocked.length>0&&!Array.from(risks).some(r=>HARD_RISKS[r]))?'WATCH':'PASS';
  const selection=report?(market==='moneyline'?`${game[report.side].name} ML`:`${report.player??game[report.side].name} ${report.direction==='over'?'More':'Less'} ${report.line??''} ${market.replaceAll('_',' ')}`):null;
  const expiries=checks.filter(c=>c.checkedAt).map(c=>Date.parse(c.checkedAt!)+(c.key==='schedule'?20:c.key==='line'?15:c.key==='calibration'?60:EVIDENCE_MINUTES[c.key]??180)*60_000);
  return { gameId:game.id,sport:game.sport,decision,label:decision==='OFFICIAL'?'Official pick':decision==='WATCH'?'Awaiting verification':'No official pick',market,selection,side,player:report?.player??null,playerId:report?.playerId??null,direction:report?.direction??null,exactLine:report?.line??null,odds,bookmaker:isProp?(propQuote?'Underdog':null):quote?.bookmaker??null,score,probability,lower,upper,implied,noVig:quote&&side?noVig(quote,side):null,edge,fairOdds:probability?fairAmerican(probability):null,reasons,strengths,mainRisk:report?.mainRisk??'Unverified information is the primary risk. A familiar team or a short price does not make a safe pick.',checks,factors,penalties,verifiedCount:checks.filter(c=>c.status==='verified').length,requiredCount:checks.length,scripts:report?.scripts??{},upsetPaths:report?.upsetPaths??[],modelVersion:VERSION,correlationGroup:report?.correlationGroup??game.id,generatedAt:now.toISOString(),expiresAt:new Date(Math.max(now.getTime(),Math.min(now.getTime()+15*60_000,...expiries))).toISOString(),probabilitySource:report?.probability.sourceUrl??null };
}

export function limitOfficialCard<T extends { analysis: Assessment }>(games:T[], maxPicks=3):T[] {
  const official=games.filter(g=>g.analysis.decision==='OFFICIAL').sort((a,b)=>(b.analysis.lower??0)-(a.analysis.lower??0));
  const groups=new Set<string>(), gameIds=new Set<string>(), allowed=new Set<Assessment>();
  for(const g of official) if(allowed.size<maxPicks&&!groups.has(g.analysis.correlationGroup)&&!gameIds.has(g.analysis.gameId)) { groups.add(g.analysis.correlationGroup);gameIds.add(g.analysis.gameId);allowed.add(g.analysis); }
  return games.map(g=>g.analysis.decision==='OFFICIAL'&&!allowed.has(g.analysis)?{...g,analysis:{...g.analysis,decision:'WATCH' as const,label:'Card exposure limit',reasons:['Excluded to respect the card limit or avoid correlated game exposure.']}}:g);
}
