import type { Sport } from '../types';

export const VERSION = '2.0.0';
export const TIMEZONE = 'America/New_York';
export const NFL_FACTORS = [
  { key: 'qb', label: 'Quarterback', weight: 20, detail: 'EPA/dropback, accuracy, pressure/blitz splits, sack avoidance, mobility, red-zone execution, recent 4-game form and backup readiness.' },
  { key: 'trenches', label: 'Offensive line vs. front', weight: 15, detail: 'Pass-block win rate, pressure and sacks allowed, interior/edge matchup, run blocking and current OL injuries on both sides.' },
  { key: 'run', label: 'Running game', weight: 10, detail: 'Rushing EPA, success rate, yards before/after contact, workload, explosive runs and opponent short-yardage defense.' },
  { key: 'defense', label: 'Defensive matchup', weight: 15, detail: 'Opponent-adjusted EPA, pressure, coverage, run defense, explosives allowed, red-zone and third-down defense. Explain the matchup, not just the ranking.' },
  { key: 'injuries', label: 'Injuries & depth', weight: 10, detail: 'Player importance × replacement quality × depth × matchup impact. Evaluate both teams; one missing receiver is never the whole argument.' },
  { key: 'form', label: 'Recent form', weight: 10, detail: 'Season baseline plus opponent-adjusted recent games. Last 3: 50/30/20; last 4 and 8 provide context. Flag QB, OL, coaching and scheme changes.' },
  { key: 'environment', label: 'Home & environment', weight: 5, detail: 'Modest home effect, travel, rest, time zones, Thursday turnaround, international games, wind, precipitation and surface.' },
  { key: 'scripts', label: 'Game-script stability', weight: 10, detail: 'Control, close fourth quarter, playing from behind, opponent lead, and turnover-driven scripts; include coaching, special teams and multiple upset paths.' },
  { key: 'turnovers', label: 'Turnover volatility', weight: 5, detail: 'Pressure-induced mistakes and turnover-worthy plays, not an assumption that fumble luck, defensive touchdowns or interception spikes will repeat.' },
] as const;
export const MLB_FACTORS = [
  { key: 'starter', label: 'Starting pitcher', weight: 20, detail: 'FIP, xFIP, SIERA, xERA, K–BB%, CSW%, SwStr%, contact quality, velocity and pitch mix. ERA alone is not a model.' },
  { key: 'workload', label: 'Workload reliability', weight: 20, detail: 'Recent innings and pitch counts, batters faced, manager usage, MLB experience, health, pitch restrictions and early-hook distribution.' },
  { key: 'matchup', label: 'Opponent & lineup', weight: 15, detail: 'Confirmed batting order, handedness, K/BB/contact rates, wRC+, ISO, platoons, pitch-type matchup and expected plate appearances.' },
  { key: 'bullpen', label: 'Bullpen availability', weight: 10, detail: 'Last 3 days usage, closer/high-leverage availability, injuries, FIP, left/right options and extra-inning exposure. Reduced relevance to F5 markets.' },
  { key: 'injuries', label: 'Health & depth', weight: 10, detail: 'Starter health, lineup scratches, replacement depth and return-from-IL restrictions. Never let a single injury dominate the analysis.' },
  { key: 'environment', label: 'Park & weather', weight: 10, detail: 'Run/HR park factors, temperature, wind, roof, humidity, rain/delay risk. Coors adds uncertainty; it does not automatically justify an Over.' },
  { key: 'form', label: 'Underlying form', weight: 5, detail: '60% established skill + 25% recent 7/15/30-day form + 15% matchup. Shrink small samples toward a suitable MLB prior.' },
  { key: 'stability', label: 'Game environment', weight: 10, detail: 'Expected runs/margin, defensive quality, one-run variance, blowout risk and dependence on a single game script.' },
] as const;
export function factorsFor(sport: Sport) { return sport === 'NFL' ? NFL_FACTORS : MLB_FACTORS; }
export const NFL_CHECKS = [
  ['schedule', 'Exact game & week'], ['starters', 'Both starting QBs'], ['backups', 'Backup QB situation'],
  ['injuries', 'Current injury/practice reports'], ['line', 'Exact moneyline'], ['metrics', 'Opponent-adjusted metrics'],
  ['trenches', 'OL & pass-rush matchups'], ['weather', 'Weather, rest & travel'], ['scripts', 'Five game scripts & upset test'], ['calibration', 'Validated probability model'],
] as const;
export const MLB_CHECKS = [
  ['schedule', 'Exact date & matchup'], ['starters', 'Both starters confirmed'], ['lineup', 'Both starting lineups'],
  ['injuries', 'Injuries & late scratches'], ['workload', 'Pitch counts & early-hook risk'], ['bullpen', 'Bullpen availability'],
  ['park', 'Ballpark & roof status'], ['weather', 'Weather & delay risk'], ['metrics', 'Underlying MLB metrics'],
  ['line', 'Exact market & line'], ['calibration', 'Validated probability model'],
] as const;
export function checksFor(sport: Sport) { return sport === 'NFL' ? NFL_CHECKS : MLB_CHECKS; }
export const HARD_RISKS: Record<string, string> = {
  qb_uncertain: 'Major quarterback uncertainty', ol_crisis: 'Major offensive-line disadvantage', starter_uncertain: 'Starting pitcher is uncertain',
  lineup_uncertain: 'Unresolved lineup changes', workload_uncertain: 'No reliable workload projection', severe_weather: 'Severe weather or delay risk',
  conflicting_signals: 'Conflicting matchup evidence', injury_uncertain: 'Major injury uncertainty', no_win_path: 'No credible path to winning',
  opener: 'Opener/bulk-pitcher uncertainty', unsustainable_form: 'Recent results depend on unsustainable variance', one_player_dependency: 'Too dependent on one player',
};
export const RISK_PENALTIES: Record<string, { label: string; points: number }> = {
  early_hook: { label: 'Early-hook exposure', points: 8 }, rookie: { label: 'Limited MLB sample', points: 7 },
  bullpen_tired: { label: 'Depleted bullpen', points: 5 }, coors: { label: 'Coors environment', points: 6 },
  low_total: { label: 'Low-total / one-run variance', points: 5 }, thursday: { label: 'Short-week volatility', points: 3 },
  travel: { label: 'Travel / rest disadvantage', points: 2 }, turnover_luck: { label: 'Turnover regression', points: 4 },
  high_k: { label: 'Aggressive strikeout threshold', points: 5 }, total_bases: { label: 'Total-bases variance', points: 8 },
  home_runs: { label: 'Home-run variance', points: 12 }, two_hits: { label: 'Multi-hit variance', points: 8 },
  thin_total: { label: 'Thin team-total margin', points: 8 }, low_volume: { label: 'Low expected opportunities', points: 6 },
  blowout: { label: 'Blowout / usage sensitivity', points: 4 }, multiple_upsets: { label: 'Multiple credible upset paths', points: 8 },
};
export const IMPROVEMENTS = [
  { title: 'Score is not probability', body: 'An 85/100 matchup score does not mean an 85% chance of winning. Probability needs a separately validated, out-of-sample model.' },
  { title: 'Price comes last', body: 'Evaluate the football or baseball case first. Then require the conservative probability bound to beat the actual break-even price—not just the no-vig market.' },
  { title: 'Uncertainty has a veto', body: 'Missing, stale or conflicting evidence blocks an official pick. Schedule data is not an injury report, and a probable pitcher is not a confirmed starter.' },
  { title: 'Workload before strikeouts', body: 'Model strikeouts across low/base/high batters-faced scenarios. Shrink small samples; a great K rate cannot compensate for insufficient opportunities.' },
  { title: 'One risk, one adjustment', body: 'Risk penalties reduce the safety score, not an already risk-adjusted probability a second time. The probability model must explicitly account for the same risks.' },
  { title: 'No invented Underdog odds', body: 'Use only the exact Underdog player, direction and line. Pick’em payouts are entry-dependent; indicative odds are not a standalone leg’s break-even probability.' },
  { title: 'Protect the whole card', body: 'Rank by the conservative probability bound, cap the card at three and keep only one selection per game or shared risk group. No forced parlays.' },
  { title: 'Learn across a sample', body: 'Freeze the original line and forecast before the game. Track Brier score, calibration and failure reasons; one loss is evidence to review, not a reason to rewrite the model.' },
];
export const LESSONS = [
  ['High K lines', 'Strong strikeout ability does not remove early-hook or blowup risk.'],
  ['Outs Unders', 'Fatigue or regression alone is not evidence of a shorter outing. Require a documented restriction or recent removal pattern.'],
  ['Thin team totals', 'One swing can erase the margin. Require a substantially larger edge.'],
  ['Total bases & home runs', 'A favorable matchup can still produce 0-for-4. Raise the threshold or choose a less volatile market.'],
  ['Low-total moneylines', 'The better starter can still lose 2–1. Evaluate expected margin and one-run variance.'],
  ['F5 alternatives', 'Separate starting-pitcher confidence from bullpen uncertainty; first-five markets still require an exact price and tie rules.'],
  ['Prospect performance', 'Minor-league dominance is not an MLB probability. Established workload and MLB-level indicators matter.'],
];
