import { db } from '@/db';
import { dataCache } from '@/db/schema';
import { eq } from 'drizzle-orm';

type Cached = { data: unknown; fetchedAt: string; stale: boolean };
const memory = new Map<string, Cached>();
const pending = new Map<string, Promise<Cached>>();
export async function cachedJson(key: string, url: string, ttlSeconds=300, force=false, headers?: HeadersInit): Promise<Cached> {
  let previous=memory.get(key);
  if(!previous) { try { const [row]=await db.select().from(dataCache).where(eq(dataCache.key,key)).limit(1); if(row) previous={data:row.payload,fetchedAt:row.fetchedAt.toISOString(),stale:false}; } catch { /* A feed can work even while the cache is unavailable. */ } }
  const age=previous?Date.now()-Date.parse(previous.fetchedAt):Infinity;
  if(previous&&age<(force?30:ttlSeconds)*1000) return {...previous,stale:false};
  if(pending.has(key)) return pending.get(key)!;
  const request=(async()=>{
    try {
      const response=await fetch(url,{headers,cache:'no-store',signal:AbortSignal.timeout(12_000)});
      if(!response.ok) throw new Error(`Provider returned HTTP ${response.status}`);
      const data:unknown=await response.json();
      const value={data,fetchedAt:new Date().toISOString(),stale:false};
      if(memory.size>300) memory.delete(memory.keys().next().value!);
      memory.set(key,value);
      try { await db.insert(dataCache).values({key,payload:data,fetchedAt:new Date(value.fetchedAt)}).onConflictDoUpdate({target:dataCache.key,set:{payload:data,fetchedAt:new Date(value.fetchedAt)}}); } catch { /* Keep the live response; do not fabricate cache health. */ }
      return value;
    } catch(error) { if(previous&&age<24*3600_000) return {...previous,stale:true}; throw error; }
    finally { pending.delete(key); }
  })();
  pending.set(key,request); return request;
}
export async function saveCachedGames(games: {id:string}[]) {
  if(!games.length) return;
  await db.insert(dataCache).values(games.map(game=>({key:`game:${game.id}`,payload:game,fetchedAt:new Date()}))).onConflictDoUpdate({target:dataCache.key,set:{payload:(await import('drizzle-orm')).sql`excluded.payload`,fetchedAt:new Date()}});
}
export async function getCachedGame<T>(id:string):Promise<T|null> { const [row]=await db.select().from(dataCache).where(eq(dataCache.key,`game:${id}`)).limit(1); return row?row.payload as T:null; }
