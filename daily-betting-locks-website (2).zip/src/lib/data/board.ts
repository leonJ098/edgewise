import type { BoardData, Game } from '../types';
import { assessGame, addDays, easternDate, limitOfficialCard } from '../safety/engine';
import { TIMEZONE, VERSION } from '../safety/rules';
import { getAnalytics, getSchedules, attachOdds } from './providers';
import { attachInjuries } from './injuries';
import { saveCachedGames } from './cache';

export async function getBoard(date=easternDate(),days=7,force=false,maxPicks=3):Promise<BoardData> {
  const [schedule,analytics]=await Promise.all([getSchedules(date,days,force),getAnalytics(force)]);
  const [oddsSources,injurySources]=await Promise.all([attachOdds(schedule.games,date,days,force),attachInjuries(schedule.games,force)]);
  const sources=[...schedule.sources,...oddsSources,...injurySources,analytics.source];
  const assessed=schedule.games.map(game=>{
    const reports=analytics.reports.filter(r=>r.gameId===game.id);
    const all=reports.length?reports.map(r=>assessGame(game,r)): [assessGame(game,undefined)];
    all.sort((a,b)=>(a.decision==='OFFICIAL'?-1:0)-(b.decision==='OFFICIAL'?-1:0)||(b.lower??-1)-(a.lower??-1));
    return {...game,analysis:all[0]};
  });
  const games=limitOfficialCard(assessed,maxPicks);
  await saveCachedGames(games);
  return {games,sources,today:easternDate(),startDate:date,endDate:addDays(date,days-1),refreshedAt:new Date().toISOString(),timezone:TIMEZONE,nflWeek:games.find(g=>g.sport==='NFL')?.week??null,officialCount:games.filter(g=>g.analysis.decision==='OFFICIAL').length,algorithmVersion:VERSION,warnings:sources.filter(s=>['error','stale','partial'].includes(s.state)).map(s=>`${s.name}: ${s.detail}`)};
}
export function cleanGame(game:Game):Game { const {id,providerId,sport,date,startsAt,fetchedAt,scheduleStale,home,away,venue,status,week,season,competition,doubleheader,gameNumber,timeTbd,neutralSite,conditional,sourceUrl,quote,props,homeScore,awayScore,homeInjuries,awayInjuries,spread,overUnder,broadcast}=game; return {id,providerId,sport,date,startsAt,fetchedAt,scheduleStale,home,away,venue,status,week,season,competition,doubleheader,gameNumber,timeTbd,neutralSite,conditional,sourceUrl,quote,props,homeScore,awayScore,homeInjuries,awayInjuries,spread,overUnder,broadcast}; }
