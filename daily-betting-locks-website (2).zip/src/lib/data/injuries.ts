import { db } from '@/db';
import { dataCache } from '@/db/schema';
import { eq } from 'drizzle-orm';
import type { Game, Injury, SourceStatus, Sport, TeamInjuryReport } from '../types';

const NFL_URL = 'https://site.api.espn.com/apis/site/v2/sports/football/nfl/injuries';
const MLB_URL = 'https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/injuries';
const TTL_MS = 15 * 60_000;
const SKIP = new Set(['active', 'probable']);

const NFL_POS: Record<string, number> = {
  QB: 1, OT: 0.38, T: 0.38, G: 0.32, C: 0.36, OL: 0.32, OG: 0.32, OC: 0.36,
  WR: 0.28, RB: 0.26, HB: 0.26, FB: 0.08, TE: 0.18,
  DE: 0.22, DT: 0.2, NT: 0.18, EDGE: 0.24, LB: 0.16, ILB: 0.16, OLB: 0.2, MLB: 0.16,
  CB: 0.2, S: 0.16, FS: 0.16, SS: 0.16, SAF: 0.16, DB: 0.16,
  K: 0.1, PK: 0.1, P: 0.06, LS: 0.04,
};
const MLB_POS: Record<string, number> = {
  SP: 0.7, P: 0.22, RP: 0.16, CP: 0.2, C: 0.32, '1B': 0.16, '2B': 0.22, SS: 0.26, '3B': 0.18,
  LF: 0.14, CF: 0.24, RF: 0.14, OF: 0.16, DH: 0.18, INF: 0.14,
};

function keyOf(status: string): Injury['statusKey'] {
  const s = status.toLowerCase();
  if (s.includes('injured reserve') || s === 'ir') return 'ir';
  if (s.includes('-il') || s.includes('day il') || s.includes('injured list')) return 'il';
  if (s === 'out' || s === 'suspension') return 'out';
  if (s === 'doubtful') return 'doubtful';
  if (s === 'questionable') return 'questionable';
  if (s.includes('day-to-day') || s === 'dtd') return 'dtd';
  return 'other';
}

function statusMult(key: Injury['statusKey']): number {
  if (key === 'out' || key === 'ir') return 1;
  if (key === 'il') return 0.9;
  if (key === 'doubtful') return 0.75;
  if (key === 'questionable') return 0.35;
  if (key === 'dtd') return 0.22;
  return 0;
}

function posWeight(sport: Sport, pos: string): number {
  const p = pos.toUpperCase();
  const table = sport === 'NFL' ? NFL_POS : MLB_POS;
  return table[p] ?? (sport === 'NFL' ? 0.08 : 0.12);
}

export function scoreInjury(sport: Sport, position: string, status: string): number {
  return Math.round(posWeight(sport, position) * statusMult(keyOf(status)) * 1000) / 1000;
}

function headline(team: string, players: Injury[]): string {
  const stars = players.filter((p) => p.impact >= 0.2).slice(0, 4);
  if (!stars.length) return `${team}: no high-impact absences on the current report.`;
  return `${team}: ${stars.map((p) => `${p.player} (${p.position} · ${p.status})`).join('; ')}.`;
}

function parseLeague(sport: Sport, raw: unknown, fetchedAt: string): Map<string, TeamInjuryReport> {
  const out = new Map<string, TeamInjuryReport>();
  const root = raw as { timestamp?: string; injuries?: { id?: string; displayName?: string; injuries?: unknown[] }[] };
  const ts = typeof root.timestamp === 'string' ? root.timestamp : fetchedAt;
  const sourceUrl = sport === 'NFL' ? 'https://www.espn.com/nfl/injuries' : 'https://www.espn.com/mlb/injuries';
  for (const team of root.injuries ?? []) {
    const teamId = String(team.id ?? '');
    const teamName = team.displayName ?? 'Unknown';
    const players: Injury[] = [];
    for (const item of team.injuries ?? []) {
      const row = item as {
        status?: string; shortComment?: string; longComment?: string; date?: string;
        athlete?: { displayName?: string; position?: { abbreviation?: string; displayName?: string } };
        details?: { type?: string; location?: string; detail?: string; side?: string; returnDate?: string };
      };
      const status = row.status ?? '';
      if (!status || SKIP.has(status.toLowerCase())) continue;
      const position = row.athlete?.position?.abbreviation || row.athlete?.position?.displayName || '—';
      const impact = scoreInjury(sport, position, status);
      if (impact <= 0) continue;
      const body = [row.details?.side, row.details?.type, row.details?.detail].filter((x) => x && x !== 'Not Specified').join(' ');
      players.push({
        player: row.athlete?.displayName ?? 'Unknown player',
        position,
        status,
        statusKey: keyOf(status),
        bodyPart: body || 'Undisclosed',
        comment: (row.shortComment || row.longComment || '').slice(0, 280),
        returnDate: row.details?.returnDate ?? null,
        updatedAt: row.date ?? ts,
        impact,
      });
    }
    players.sort((a, b) => b.impact - a.impact);
    const impact = Math.min(1.5, players.reduce((s, p) => s + p.impact, 0));
    const report: TeamInjuryReport = {
      teamId, teamName, fetchedAt: ts, sourceUrl, players, impact: Math.round(impact * 1000) / 1000, headline: headline(teamName, players),
    };
    if (teamId) out.set(`${sport}:${teamId}`, report);
    out.set(`${sport}:name:${norm(teamName)}`, report);
  }
  return out;
}

function norm(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]/g, '');
}

type Compact = { fetchedAt: string; teams: Record<string, TeamInjuryReport> };

async function loadCompact(sport: Sport, force = false): Promise<{ map: Map<string, TeamInjuryReport>; fetchedAt: string; stale: boolean; error?: string }> {
  const cacheKey = `injuries-compact:${sport}`;
  try {
    const [row] = await db.select().from(dataCache).where(eq(dataCache.key, cacheKey)).limit(1);
    const age = row ? Date.now() - row.fetchedAt.getTime() : Infinity;
    if (row && age < (force ? 30_000 : TTL_MS)) {
      const payload = row.payload as Compact;
      return { map: new Map(Object.entries(payload.teams ?? {})), fetchedAt: payload.fetchedAt, stale: false };
    }
  } catch { /* fall through to live fetch */ }

  const url = sport === 'NFL' ? NFL_URL : MLB_URL;
  try {
    const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(20_000) });
    if (!response.ok) throw new Error(`Injury feed HTTP ${response.status}`);
    const json: unknown = await response.json();
    const fetchedAt = new Date().toISOString();
    const map = parseLeague(sport, json, fetchedAt);
    const compact: Compact = { fetchedAt, teams: Object.fromEntries(map) };
    try {
      await db.insert(dataCache).values({ key: cacheKey, payload: compact, fetchedAt: new Date(fetchedAt) })
        .onConflictDoUpdate({ target: dataCache.key, set: { payload: compact, fetchedAt: new Date(fetchedAt) } });
    } catch { /* live parse still usable */ }
    return { map, fetchedAt, stale: false };
  } catch (error) {
    try {
      const [row] = await db.select().from(dataCache).where(eq(dataCache.key, cacheKey)).limit(1);
      if (row) {
        const payload = row.payload as Compact;
        return { map: new Map(Object.entries(payload.teams ?? {})), fetchedAt: payload.fetchedAt, stale: true, error: error instanceof Error ? error.message : 'Injury feed failed' };
      }
    } catch { /* none */ }
    return { map: new Map(), fetchedAt: new Date().toISOString(), stale: true, error: error instanceof Error ? error.message : 'Injury feed failed' };
  }
}

function matchReport(sport: Sport, teamId: string, teamName: string, map: Map<string, TeamInjuryReport>): TeamInjuryReport | undefined {
  return map.get(`${sport}:${teamId}`) || map.get(`${sport}:name:${norm(teamName)}`);
}

export function qbStatus(report?: TeamInjuryReport): Injury | undefined {
  return report?.players.find((p) => p.position === 'QB' && ['out', 'ir', 'doubtful', 'questionable'].includes(p.statusKey));
}

export function starterOnReport(name: string | undefined, report?: TeamInjuryReport): Injury | undefined {
  if (!name || !report) return undefined;
  const n = norm(name);
  return report.players.find((p) => norm(p.player) === n || n.includes(norm(p.player)) || norm(p.player).includes(n));
}

export async function attachInjuries(games: Game[], force = false): Promise<SourceStatus[]> {
  const sports = [...new Set(games.map((g) => g.sport))];
  const sources: SourceStatus[] = [];
  for (const sport of sports) {
    const result = await loadCompact(sport, force);
    let matched = 0;
    for (const game of games.filter((g) => g.sport === sport)) {
      game.homeInjuries = matchReport(sport, game.home.id, game.home.name, result.map);
      game.awayInjuries = matchReport(sport, game.away.id, game.away.name, result.map);
      if (game.homeInjuries || game.awayInjuries) matched++;
    }
    const name = sport === 'NFL' ? 'ESPN NFL injuries' : 'ESPN MLB injuries';
    sources.push({
      id: `injuries-${sport.toLowerCase()}`,
      name,
      state: result.error && !result.map.size ? 'error' : result.stale ? 'stale' : matched ? 'connected' : 'partial',
      detail: result.error && !result.map.size
        ? `${name} could not be reached. Picks will warn that injury status is unverified — never assume healthy.`
        : `Live ESPN injury report (${result.map.size ? 'cached compact snapshot' : 'empty'}). Out, IR/IL, doubtful and questionable only. Active/healthy listings are ignored. Updated ${result.fetchedAt}.`,
      checkedAt: result.fetchedAt,
      url: sport === 'NFL' ? 'https://www.espn.com/nfl/injuries' : 'https://www.espn.com/mlb/injuries',
    });
  }
  return sources;
}

export function injuryFeature(game: Game): { value: number; notes: string[]; warnings: string[]; missing: boolean } {
  const notes: string[] = [];
  const warnings: string[] = [];
  if (!game.homeInjuries && !game.awayInjuries) {
    return { value: 0, notes, warnings: ['Current injury report could not be matched for this game. Do not assume both teams are healthy.'], missing: true };
  }
  const homeImp = game.homeInjuries?.impact ?? 0;
  const awayImp = game.awayInjuries?.impact ?? 0;
  const value = Math.max(-1.2, Math.min(1.2, awayImp - homeImp));
  const homeQb = qbStatus(game.homeInjuries);
  const awayQb = qbStatus(game.awayInjuries);
  if (homeQb) notes.push(`${game.home.shortName} QB ${homeQb.player} is ${homeQb.status}${homeQb.bodyPart ? ` (${homeQb.bodyPart})` : ''}.`);
  if (awayQb) notes.push(`${game.away.shortName} QB ${awayQb.player} is ${awayQb.status}${awayQb.bodyPart ? ` (${awayQb.bodyPart})` : ''}.`);
  const homeStarter = starterOnReport(game.home.starter?.name, game.homeInjuries);
  const awayStarter = starterOnReport(game.away.starter?.name, game.awayInjuries);
  if (homeStarter) notes.push(`Probable home starter ${homeStarter.player} is on the report: ${homeStarter.status} — ${homeStarter.bodyPart}.`);
  if (awayStarter) notes.push(`Probable away starter ${awayStarter.player} is on the report: ${awayStarter.status} — ${awayStarter.bodyPart}.`);
  const top = (rep?: TeamInjuryReport, label?: string) => (rep?.players ?? []).filter((p) => p.impact >= 0.18).slice(0, 3)
    .map((p) => `${label}: ${p.player} ${p.position} ${p.status}${p.bodyPart ? ` (${p.bodyPart})` : ''}`);
  notes.push(...top(game.awayInjuries, game.away.shortName), ...top(game.homeInjuries, game.home.shortName));
  if (homeQb && ['out', 'ir', 'doubtful'].includes(homeQb.statusKey)) warnings.push(`${game.home.shortName} starting-quarterback availability is compromised (${homeQb.status}).`);
  if (awayQb && ['out', 'ir', 'doubtful'].includes(awayQb.statusKey)) warnings.push(`${game.away.shortName} starting-quarterback availability is compromised (${awayQb.status}).`);
  if (homeImp >= 0.6) warnings.push(`${game.home.shortName} injury load is elevated (${homeImp.toFixed(2)} impact).`);
  if (awayImp >= 0.6) warnings.push(`${game.away.shortName} injury load is elevated (${awayImp.toFixed(2)} impact).`);
  return { value: Math.round(value * 1000) / 1000, notes: [...new Set(notes)].slice(0, 6), warnings: [...new Set(warnings)], missing: false };
}
