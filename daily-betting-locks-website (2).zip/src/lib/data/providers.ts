import { z } from 'zod';
import type { Game, Team, SourceStatus, Sport, PropQuote, Market } from '../types';
import { cachedJson } from './cache';
import { addDays, easternDate, fresh } from '../safety/engine';
import { reportFeedSchema, type AnalyticsReport } from '../safety/validation';

const mlbTeam=z.object({team:z.object({id:z.number(),name:z.string(),abbreviation:z.string().optional(),teamName:z.string().optional()}),leagueRecord:z.object({wins:z.number(),losses:z.number()}).optional(),probablePitcher:z.object({id:z.number(),fullName:z.string()}).optional(),score:z.number().optional()});
const mlbGame=z.object({gamePk:z.number(),gameDate:z.string(),officialDate:z.string(),season:z.string().optional(),status:z.object({abstractGameState:z.string(),detailedState:z.string(),startTimeTBD:z.boolean().optional()}),teams:z.object({home:mlbTeam,away:mlbTeam}),venue:z.object({name:z.string()}),doubleHeader:z.string().optional(),gameNumber:z.number().optional(),seriesDescription:z.string().optional(),ifNecessary:z.string().optional()});
const mlbSchedule=z.object({dates:z.array(z.object({games:z.array(mlbGame)}))});
const espnCompetitor=z.object({homeAway:z.string(),team:z.object({id:z.string(),displayName:z.string(),shortDisplayName:z.string().optional(),abbreviation:z.string(),logo:z.string().optional(),color:z.string().optional()}),score:z.string().optional(),records:z.array(z.object({type:z.string(),summary:z.string()})).optional()});
const espnEvent=z.object({id:z.string(),date:z.string(),season:z.object({year:z.number(),type:z.number()}).optional(),week:z.object({number:z.number()}).optional(),competitions:z.array(z.object({date:z.string().optional(),timeValid:z.boolean().optional(),neutralSite:z.boolean().optional(),venue:z.object({fullName:z.string()}).optional(),competitors:z.array(espnCompetitor),status:z.object({type:z.object({state:z.string(),name:z.string(),completed:z.boolean().optional()})}).optional(),odds:z.array(z.object({details:z.string().optional(),overUnder:z.number().optional(),spread:z.number().optional()})).optional(),broadcasts:z.array(z.object({names:z.array(z.string()).optional()})).optional(),broadcast:z.string().optional()})),status:z.object({type:z.object({state:z.string(),name:z.string(),completed:z.boolean().optional()})}).optional()});
const espnSchedule=z.object({events:z.array(espnEvent)});
const mlbColors:Record<string,string>={'145':'272b30','114':'c42736','144':'ba243d','119':'075aaa','147':'13294b','121':'e76a27','111':'c63b48','146':'009caa','137':'ef6c36','135':'714c2b','136':'006e73','143':'cf3040','158':'bd8c36','139':'146b9c','141':'1475bb','116':'e96930','117':'ee7026','112':'2469ae','134':'b9941b'};
function normalizeMLB(g:z.infer<typeof mlbGame>,fetchedAt:string):Game {
  const team=(s:'home'|'away'):Team=>{const t=g.teams[s];return {id:String(t.team.id),name:t.team.name,shortName:t.team.teamName??t.team.name,abbreviation:t.team.abbreviation??t.team.name.slice(0,3).toUpperCase(),logo:`https://www.mlbstatic.com/team-logos/${t.team.id}.svg`,color:mlbColors[t.team.id]??'24726b',record:t.leagueRecord?`${t.leagueRecord.wins}–${t.leagueRecord.losses}`:undefined,starter:t.probablePitcher?{id:String(t.probablePitcher.id),name:t.probablePitcher.fullName,status:'probable'}:undefined};};
  const state=g.status.abstractGameState;
  return {id:`mlb-${g.gamePk}`,providerId:String(g.gamePk),sport:'MLB',date:g.officialDate,startsAt:g.gameDate,fetchedAt,home:team('home'),away:team('away'),venue:g.venue.name,status:/postpon|suspend|cancel|delay/i.test(g.status.detailedState)?'postponed':state==='Final'?'final':state==='Live'?'live':'scheduled',season:g.season,competition:g.seriesDescription??'MLB',doubleheader:!!g.doubleHeader&&g.doubleHeader!=='N',gameNumber:g.gameNumber??1,timeTbd:g.status.startTimeTBD??false,conditional:g.ifNecessary==='Y',neutralSite:false,sourceUrl:`https://www.mlb.com/gameday/${g.gamePk}`,quote:null,props:[],homeScore:g.teams.home.score,awayScore:g.teams.away.score};
}
function normalizeNFL(e:z.infer<typeof espnEvent>,fetchedAt:string):Game|null {
  const c=e.competitions[0]; if(!c) return null;
  const home=c.competitors.find(t=>t.homeAway==='home'),away=c.competitors.find(t=>t.homeAway==='away');if(!home||!away) return null;
  const team=(t:typeof home):Team=>({id:t.team.id,name:t.team.displayName,shortName:t.team.shortDisplayName??t.team.displayName,abbreviation:t.team.abbreviation,logo:t.team.logo??'',color:`#${t.team.color??'286257'}`,record:t.records?.find(r=>r.type==='total')?.summary});
  const status=c.status?.type??e.status?.type;
  const line=c.odds?.[0];
  return {id:`nfl-${e.id}`,providerId:e.id,sport:'NFL',date:easternDate(new Date(e.date)),startsAt:e.date,fetchedAt,home:team(home),away:team(away),venue:c.venue?.fullName??'Venue to be confirmed',status:status?.completed?'final':/postpon|cancel|delay/i.test(status?.name??'')?'postponed':status?.state==='in'?'live':'scheduled',week:e.week?.number,season:String(e.season?.year??new Date(e.date).getFullYear()),competition:e.season?.type===1?'Preseason':e.season?.type===3?'Postseason':`Week ${e.week?.number??'TBD'} · Regular season`,doubleheader:false,gameNumber:1,timeTbd:c.timeValid===false,neutralSite:c.neutralSite??false,conditional:false,sourceUrl:`https://www.espn.com/nfl/game/_/gameId/${e.id}`,quote:null,props:[],homeScore:home.score?Number(home.score):undefined,awayScore:away.score?Number(away.score):undefined,spread:line?.details,overUnder:line?.overUnder,broadcast:c.broadcast??c.broadcasts?.[0]?.names?.[0]};
}
export async function getSchedules(date:string,days:number,force=false):Promise<{games:Game[];sources:SourceStatus[]}> {
  const end=addDays(date,days-1),games:Game[]=[],sources:SourceStatus[]=[];
  await Promise.all([
    (async()=>{try{const value=await cachedJson(`mlb-schedule:${date}:${end}`,`https://statsapi.mlb.com/api/v1/schedule?sportId=1&startDate=${date}&endDate=${end}&hydrate=team,probablePitcher,linescore`,300,force);const data=mlbSchedule.parse(value.data);games.push(...data.dates.flatMap(d=>d.games.map(g=>({...normalizeMLB(g,value.fetchedAt),scheduleStale:value.stale}))));sources.push({id:'mlb',name:'MLB Stats',state:value.stale?'stale':'connected',detail:'Official schedules, venue, game status and probable pitchers. Confirmation and workload are separate checks.',checkedAt:value.fetchedAt,url:'https://www.mlb.com/scores'});}catch{sources.push({id:'mlb',name:'MLB Stats',state:'error',detail:'MLB schedule could not be verified. No replacement or sample games were used.',checkedAt:null,url:'https://www.mlb.com/scores'});}})(),
    (async()=>{let failed=0,stale=0;const times:string[]=[];await Promise.all(Array.from({length:days},(_,i)=>(async()=>{const day=addDays(date,i);try{const value=await cachedJson(`nfl-schedule:${day}`,`https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=${day.replaceAll('-','')}&limit=100`,300,force);const data=espnSchedule.parse(value.data);games.push(...data.events.map(e=>normalizeNFL(e,value.fetchedAt)).filter((g):g is Game=>!!g&&g.date>=date&&g.date<=end).map(g=>({...g,scheduleStale:value.stale})));times.push(value.fetchedAt);if(value.stale)stale++;}catch{failed++;}})()));sources.push({id:'nfl',name:'ESPN NFL',state:failed===days?'error':failed?'partial':stale?'stale':'connected',detail:failed?`${failed} of ${days} daily schedule requests unavailable. No substitute matchups.`:'Public ESPN schedule feed (unofficial API). Exact week and home/away; passing leaders are never treated as confirmed QBs.',checkedAt:times.sort()[0]??null,url:'https://www.espn.com/nfl/schedule'});})(),
  ]);
  const unique=Array.from(new Map(games.map(g=>[g.id,g])).values()).sort((a,b)=>Date.parse(a.startsAt)-Date.parse(b.startsAt));
  return {games:unique,sources:sources.sort((a,b)=>a.id.localeCompare(b.id))};
}

const oddsResponse=z.array(z.object({id:z.string(),home_team:z.string(),away_team:z.string(),commence_time:z.string(),bookmakers:z.array(z.object({key:z.string(),title:z.string(),last_update:z.string().optional(),markets:z.array(z.object({key:z.string(),last_update:z.string().optional(),outcomes:z.array(z.object({name:z.string(),price:z.number().optional(),description:z.string().optional(),point:z.number().optional(),multiplier:z.number().optional()}))}))}))}));
const normalizeName=(s:string)=>s.toLowerCase().replace(/[^a-z0-9]/g,'').replace('athletics','athletics');
export async function attachOdds(games:Game[],date:string,days:number,force=false):Promise<SourceStatus[]> {
  const key=process.env.ODDS_API_KEY;
  const base={checkedAt:null,url:'https://the-odds-api.com'};
  if(!key) return [{id:'odds',name:'Moneyline prices',state:'not-configured',detail:'ODDS_API_KEY is not configured. No moneyline price or implied probability is invented.',...base},{id:'underdog',name:'Underdog exact lines',state:'not-configured',detail:'Requires The Odds API and Underdog market coverage. Other sportsbooks are never substituted.',...base}];
  let failures=0,count=0,props=0,propFailures=0;
  const foundTimes:string[]=[];
  await Promise.all((['NFL','MLB'] as Sport[]).map(async sport=>{
    const group=games.filter(g=>g.sport===sport&&g.status==='scheduled');if(!group.length)return;
    try {
      const sportKey=sport==='NFL'?'americanfootball_nfl':'baseball_mlb';
      const url=new URL(`https://api.the-odds-api.com/v4/sports/${sportKey}/odds`);
      url.search=new URLSearchParams({apiKey:key,regions:'us',markets:'h2h',oddsFormat:'american',commenceTimeFrom:`${date}T00:00:00Z`,commenceTimeTo:`${addDays(date,days)}T12:00:00Z`}).toString();
      const value=await cachedJson(`odds:${sport}:${date}:${days}`,url.toString(),120,force);
      if(value.stale) throw new Error('Stale moneyline feed cannot verify current prices.');
      const events=oddsResponse.parse(value.data);
      await Promise.all(group.map(async game=>{
        const event=events.find(e=>normalizeName(e.home_team)===normalizeName(game.home.name)&&normalizeName(e.away_team)===normalizeName(game.away.name)&&Math.abs(Date.parse(e.commence_time)-Date.parse(game.startsAt))<5*60_000);
        if(!event)return;
        for(const book of event.bookmakers) {const market=book.markets.find(m=>m.key==='h2h');const h=market?.outcomes.find(o=>o.name===event.home_team)?.price,a=market?.outcomes.find(o=>o.name===event.away_team)?.price;const time=market?.last_update??book.last_update;
          if(h!==undefined&&a!==undefined&&Math.abs(h)>=100&&Math.abs(a)>=100&&time&&fresh(time,15)) {game.quote={home:h,away:a,bookmaker:book.title,observedAt:time,sourceUrl:'https://the-odds-api.com'};count++;foundTimes.push(time);break;}
        }
        if(sport==='MLB'&&Date.parse(game.startsAt)<Date.now()+36*3600_000) {
          try{
            const markets='pitcher_strikeouts,pitcher_outs,pitcher_earned_runs,batter_hits,batter_total_bases,batter_home_runs';
            const propUrl=`https://api.the-odds-api.com/v4/sports/baseball_mlb/events/${event.id}/odds?${new URLSearchParams({apiKey:key,bookmakers:'underdog',markets,oddsFormat:'american',includeMultipliers:'true'})}`;
            const v=await cachedJson(`underdog:${event.id}`,propUrl,180,force);
            if(v.stale) throw new Error('Stale prop data cannot verify an exact line.');
            const result=oddsResponse.parse([v.data])[0];const book=result.bookmakers.find(b=>b.key==='underdog');
            for(const m of book?.markets??[]) for(const outcome of m.outcomes) if(outcome.description&&outcome.point!==undefined&&m.last_update&&fresh(m.last_update,15)&&['Over','Under'].includes(outcome.name)) {const p:PropQuote={player:outcome.description,market:m.key as Market,line:outcome.point,direction:outcome.name==='Over'?'over':'under',bookmaker:'underdog',observedAt:m.last_update,sourceUrl:'https://underdogfantasy.com/pick-em',multiplier:outcome.multiplier};game.props.push(p);props++;}
          }catch{propFailures++;}
        }
      }));
    }catch{failures++;}
  }));
  return [{id:'odds',name:'Moneyline prices',state:count?'connected':failures?'error':'partial',detail:count?`${count} games have fresh two-sided prices. Source and timestamp are preserved.`:failures?'Odds feed request failed. Check subscription and credentials server-side.':'Connected configuration; no fresh matching prices returned.',checkedAt:foundTimes.sort()[0]??null,url:base.url},{id:'underdog',name:'Underdog exact lines',state:props?'connected':propFailures?'error':'partial',detail:props?`${props} exact Underdog outcomes retrieved. DFS indicative prices are not per-leg break-even odds.`:'No exact Underdog lines verified for this slate. Props remain unofficial.',checkedAt:props?new Date().toISOString():null,url:'https://underdogfantasy.com/pick-em'}];
}
export async function getAnalytics(force=false):Promise<{reports:AnalyticsReport[];source:SourceStatus}> {
  const endpoint=process.env.ANALYTICS_FEED_URL;
  const source:SourceStatus={id:'analytics',name:'Advanced matchup data',state:'not-configured',detail:'No licensed analytics feed connected. Advanced metrics, injuries and calibrated forecasts remain unverified.',checkedAt:null,url:'https://github.com/nflverse/nflverse-data'};
  if(!endpoint)return {reports:[],source};
  try {if(!endpoint.startsWith('https://'))throw new Error('HTTPS required');const result=await cachedJson('analytics:feed',endpoint,120,force,process.env.ANALYTICS_FEED_TOKEN?{Authorization:`Bearer ${process.env.ANALYTICS_FEED_TOKEN}`}:undefined);const data=reportFeedSchema.parse(result.data);return {reports:result.stale?[]:data.reports,source:{...source,state:result.stale?'stale':'connected',checkedAt:result.fetchedAt,detail:`${data.reports.length} schema-validated research reports. Every game still must pass freshness, identity, price and safety gates.`}};}catch{return {reports:[],source:{...source,state:'error',detail:'Analytics feed unavailable or rejected by the evidence schema. No official picks from this feed.'}};}
}

export async function mlbPitcherDetail(game:Game) {
  if(game.sport!=='MLB')return [];
  return Promise.all((['away','home'] as const).map(async side=>{
    const starter=game[side].starter;if(!starter)return {side,name:'Not announced',status:'unavailable',season:null,recent:[]};
    try{const url=`https://statsapi.mlb.com/api/v1/people/${starter.id}/stats?stats=season,gameLog&group=pitching&season=${game.season}`;const value=await cachedJson(`pitching:${starter.id}:${game.season}`,url,1800);
      const stat=z.record(z.string(),z.union([z.number(),z.string(),z.boolean(),z.null()]));
      const data=z.object({stats:z.array(z.object({type:z.object({displayName:z.string()}),splits:z.array(z.object({date:z.string().optional(),stat}))}))}).parse(value.data);
      const season=data.stats.find(s=>s.type.displayName==='stats'||s.type.displayName==='season')?.splits[0]?.stat??null;
      const recent=(data.stats.find(s=>s.type.displayName==='gameLog')?.splits??[]).filter(s=>s.date&&s.date<game.date).sort((a,b)=>(b.date??'').localeCompare(a.date??'')).slice(0,3);
      return {side,name:starter.name,status:'probable',season,recent,sourceUrl:url,fetchedAt:value.fetchedAt};
    }catch{return {side,name:starter.name,status:'probable',season:null,recent:[]};}
  }));
}
