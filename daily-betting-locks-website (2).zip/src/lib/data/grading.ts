import { z } from 'zod';
import type { Game, Assessment } from '../types';
import { cachedJson } from './cache';
import { getSchedules } from './providers';
export type GradeResult={grade:'win'|'loss'|'push';actual:number;resultSource:string;review:string};
function compare(actual:number,line:number,direction:'over'|'under'):'win'|'loss'|'push' {if(actual===line)return 'push';return (direction==='over'?actual>line:actual<line)?'win':'loss';}
export function inningsToOuts(ip:string) {if(!/^\d+(\.[012])?$/.test(ip))return null;const [innings,partial='0']=ip.split('.');return Number(innings)*3+Number(partial);}
export async function gradeVerified(game:Game,analysis:Assessment):Promise<GradeResult|null> {
  if(analysis.decision!=='OFFICIAL'||Date.parse(game.startsAt)>Date.now())return null;
  if(game.sport==='NFL') {const slate=await getSchedules(game.date,1,true);const actual=slate.games.find(g=>g.id===game.id);if(!actual||actual.status!=='final'||actual.home.id!==game.home.id||actual.away.id!==game.away.id||actual.homeScore===undefined||actual.awayScore===undefined||!analysis.side||analysis.market!=='moneyline')return null;const margin=analysis.side==='home'?actual.homeScore-actual.awayScore:actual.awayScore-actual.homeScore;return {grade:margin===0?'push':margin>0?'win':'loss',actual:margin,resultSource:actual.sourceUrl,review:`Verified final: ${actual.away.name} ${actual.awayScore} – ${actual.home.name} ${actual.homeScore}. Outcome alone does not establish the cause; complete the post-game review.`};}
  const url=`https://statsapi.mlb.com/api/v1.1/game/${game.providerId}/feed/live`;
  const response=await cachedJson(`mlb-final:${game.providerId}`,url,60,true);
  const player=z.object({stats:z.object({pitching:z.object({strikeOuts:z.number().optional(),earnedRuns:z.number().optional(),inningsPitched:z.string().optional(),gamesStarted:z.number().optional()}).optional(),batting:z.object({hits:z.number().optional(),doubles:z.number().optional(),triples:z.number().optional(),homeRuns:z.number().optional(),plateAppearances:z.number().optional()}).optional()})});
  const team=z.object({battingOrder:z.array(z.number()).optional(),pitchers:z.array(z.number()).optional(),players:z.record(z.string(),player)});
  const data=z.object({gameData:z.object({datetime:z.object({officialDate:z.string()}),status:z.object({abstractGameState:z.string()}),teams:z.object({home:z.object({id:z.number()}),away:z.object({id:z.number()})})}),liveData:z.object({linescore:z.object({teams:z.object({home:z.object({runs:z.number().optional()}),away:z.object({runs:z.number().optional()})})}),boxscore:z.object({teams:z.object({home:team,away:team})})})}).parse(response.data);
  if(data.gameData.status.abstractGameState!=='Final'||data.gameData.datetime.officialDate!==game.date||String(data.gameData.teams.home.id)!==game.home.id||String(data.gameData.teams.away.id)!==game.away.id)return null;
  const score=data.liveData.linescore.teams;if(score.home.runs===undefined||score.away.runs===undefined)return null;
  let actual:number|null=null,grade:'win'|'loss'|'push';
  if(analysis.market==='moneyline'&&analysis.side){actual=analysis.side==='home'?score.home.runs-score.away.runs:score.away.runs-score.home.runs;grade=actual===0?'push':actual>0?'win':'loss';}
  else {
    if(!analysis.playerId||analysis.exactLine===null||!analysis.direction||!analysis.side)return null;
    const box=data.liveData.boxscore.teams[analysis.side],person=box.players[`ID${analysis.playerId}`];if(!person)return null;
    if(analysis.market.startsWith('pitcher_')) {
      if(box.pitchers?.[0]!==Number(analysis.playerId))return null; // A scratch/opener change requires settlement-rule review, not a made-up loss.
      const stats=person.stats.pitching;if(!stats)return null;
      if(analysis.market==='pitcher_strikeouts')actual=stats.strikeOuts??null;
      if(analysis.market==='pitcher_earned_runs')actual=stats.earnedRuns??null;
      if(analysis.market==='pitcher_outs')actual=stats.inningsPitched?inningsToOuts(stats.inningsPitched):null;
    } else {
      const stats=person.stats.batting;if(!stats?.plateAppearances||!box.battingOrder?.includes(Number(analysis.playerId)))return null;
      if(analysis.market==='batter_hits')actual=stats.hits??null;
      if(analysis.market==='batter_home_runs')actual=stats.homeRuns??null;
      if(analysis.market==='batter_total_bases'&&stats.hits!==undefined&&stats.doubles!==undefined&&stats.triples!==undefined&&stats.homeRuns!==undefined)actual=stats.hits+stats.doubles+2*stats.triples+3*stats.homeRuns;
    }
    if(actual===null||!Number.isFinite(actual))return null;grade=compare(actual,analysis.exactLine,analysis.direction);
  }
  return {grade,actual,resultSource:url,review:`Verified final: ${game.away.abbreviation} ${score.away.runs} – ${game.home.abbreviation} ${score.home.runs}. ${analysis.market==='moneyline'?'Team margin':'Exact player statistic'}: ${actual}. Statistical grade only; provider entry settlement may differ. Review the cause before changing a model.`};
}
