export type Sport = 'NFL' | 'MLB';
export type Decision = 'OFFICIAL' | 'WATCH' | 'PASS';
export type Market = 'moneyline' | 'pitcher_strikeouts' | 'pitcher_outs' | 'pitcher_earned_runs' | 'batter_hits' | 'batter_total_bases' | 'batter_home_runs' | 'team_total' | 'f5_total';
export type Side = 'home' | 'away';
export type Injury = {
  player: string; position: string; status: string; statusKey: 'out' | 'doubtful' | 'questionable' | 'ir' | 'il' | 'dtd' | 'other';
  bodyPart: string; comment: string; returnDate: string | null; updatedAt: string; impact: number;
};
export type TeamInjuryReport = {
  teamId: string; teamName: string; fetchedAt: string; sourceUrl: string;
  players: Injury[]; impact: number; headline: string;
};
export type Team = { id: string; name: string; shortName: string; abbreviation: string; logo: string; color: string; record?: string; starter?: { id: string; name: string; status: 'probable' | 'confirmed' } };
export type MoneylineQuote = { home: number; away: number; bookmaker: string; observedAt: string; sourceUrl: string };
export type PropQuote = { player: string; market: Market; line: number; direction: 'over' | 'under'; bookmaker: 'underdog'; observedAt: string; sourceUrl: string; multiplier?: number };
export type Game = {
  id: string; providerId: string; sport: Sport; date: string; startsAt: string; fetchedAt: string; scheduleStale?: boolean;
  home: Team; away: Team; venue: string; status: 'scheduled' | 'live' | 'final' | 'postponed';
  week?: number; season?: string; competition: string; doubleheader: boolean; gameNumber: number;
  timeTbd: boolean; neutralSite: boolean; conditional: boolean; sourceUrl: string;
  quote: MoneylineQuote | null; props: PropQuote[]; homeScore?: number; awayScore?: number;
  homeInjuries?: TeamInjuryReport; awayInjuries?: TeamInjuryReport;
  spread?: string; overUnder?: number; broadcast?: string;
};
export type Verification = { key: string; label: string; status: 'verified' | 'missing' | 'stale'; detail: string; sourceUrl?: string; checkedAt?: string };
export type FactorResult = { key: string; label: string; weight: number; rating: number | null; points: number | null; detail: string };
export type Penalty = { key: string; label: string; points: number };
export type Assessment = {
  gameId: string; sport: Sport; decision: Decision; label: string; market: Market; selection: string | null;
  side: Side | null; player: string | null; playerId: string | null; direction: 'over' | 'under' | null;
  exactLine: number | null; odds: number | null; bookmaker: string | null;
  score: number | null; probability: number | null; lower: number | null; upper: number | null;
  implied: number | null; noVig: number | null; edge: number | null; fairOdds: number | null;
  reasons: string[]; strengths: string[]; mainRisk: string; checks: Verification[];
  factors: FactorResult[]; penalties: Penalty[]; verifiedCount: number; requiredCount: number;
  scripts: Record<string, string>; upsetPaths: string[]; modelVersion: string;
  correlationGroup: string; generatedAt: string; expiresAt: string; probabilitySource: string | null;
};
export type AnalyzedGame = Game & { analysis: Assessment };
export type SourceStatus = { id: string; name: string; state: 'connected' | 'partial' | 'not-configured' | 'error' | 'stale'; detail: string; checkedAt: string | null; url: string };
export type BoardData = { games: AnalyzedGame[]; sources: SourceStatus[]; today: string; startDate: string; endDate: string; refreshedAt: string; timezone: string; nflWeek: number | null; officialCount: number; algorithmVersion: string; warnings: string[] };
export type Workspace = { displayName: string; maxPicks: number; defaultSport: 'ALL' | Sport; watchlist: { id: string; gameId: string; game: Game; createdAt: string; note: string }[]; runs: { id: string; createdAt: string; gamesChecked: number; officialCount: number }[] };
export type OfficialRecord = { id: string; game: Game; analysis: Assessment; publishedAt: string; grade: 'pending' | 'win' | 'loss' | 'push' | 'void'; actual: number | null; resultSource: string | null; gradedAt: string | null; review: string | null };
export type LockTier = 'LOCK' | 'STRONG' | 'LEAN' | 'PASS';
export type ModelPick = {
  gameId: string; sport: Sport; date: string; startsAt: string;
  homeId: string; awayId: string; homeName: string; awayName: string;
  homeAbbr: string; awayAbbr: string; venue: string;
  predictedSide: Side; pickName: string; homeProb: number; confidence: number;
  tier: LockTier; edge: number; fairOdds: number | null;
  features: Record<string, number>; reasoning: string[]; warnings: string[];
  modelVersion: string; status: 'pending' | 'win' | 'loss' | 'push';
  homeScore?: number; awayScore?: number;
  injuries?: {
    home: Injury[]; away: Injury[];
    homeImpact: number; awayImpact: number;
    summary: string[]; fetchedAt: string | null; sourceUrl: string | null;
  };
  spread?: string; overUnder?: number; broadcast?: string;
};
export type LocksData = {
  locks: ModelPick[]; all: ModelPick[]; today: string; startDate: string; endDate: string;
  refreshedAt: string; modelVersions: Record<Sport, string>;
  performance: Record<Sport, { graded: number; wins: number; losses: number; pushes: number; winRate: number | null; brier: number | null; streak: number }>;
  learning: { newlyGraded: number; lessonsCreated: number; evolved: boolean; summary: string | null };
};
export type Lesson = { id: string; sport: Sport; category: string; title: string; detail: string; adjustment: Record<string, number>; sampleSize: number; createdAt: string };
export type EvolutionEntry = { id: string; sport: Sport; fromVersion: string; toVersion: string; trigger: string; summary: string; metricsBefore: Record<string, number | null>; metricsAfter: Record<string, number | null>; weightDelta: Record<string, number>; gradedInCycle: number; createdAt: string };
export type LearnData = {
  models: Record<Sport, { version: string; weights: Record<string, number>; defaultWeights: Record<string, number>; thresholds: { lock: number; strong: number; lean: number }; stats: { graded: number; wins: number; losses: number; pushes: number; brier: number | null; winRate: number | null }; calibration: { bucket: string; predicted: number; observed: number; count: number }[]; updatedAt: string }>;
  lessons: Lesson[]; evolution: EvolutionEntry[];
  recent: { gameId: string; sport: Sport; date: string; pick: string; confidence: number; tier: string; status: string; score: string }[];
  ratings: { sport: Sport; teamId: string; teamName: string; rating: number; games: number; wins: number; streak: number }[];
};
