import test from 'node:test';
import assert from 'node:assert/strict';
import {
  sigmoid, predictHomeProb, bucketFor, applyCalibration, tierFor,
  fairAmerican, clampWeight, bumpVersion, DEFAULT_WEIGHTS, DEFAULT_THRESHOLDS,
} from './model';
import { parseRecord, expectedScore, formScore, daysBetween, K_FACTOR } from './ratings';
import { buildFeatures, pitcherEdgeFromStats } from './features';
import { scoreInjury } from '../data/injuries';
import type { Game } from '../types';

const game = (over: Partial<Game> = {}): Game => ({
  id: 'nfl-1', providerId: '1', sport: 'NFL', date: '2026-10-10', startsAt: '2026-10-10T17:00:00Z',
  fetchedAt: new Date().toISOString(),
  home: { id: '1', name: 'Home Team', shortName: 'Home', abbreviation: 'HOM', logo: '', color: '#123456', record: '3-1' },
  away: { id: '2', name: 'Away Team', shortName: 'Away', abbreviation: 'AWY', logo: '', color: '#abcdef', record: '1-3' },
  venue: 'Test Stadium', status: 'scheduled', week: 5, season: '2026', competition: 'Week 5',
  doubleheader: false, gameNumber: 1, timeTbd: false, neutralSite: false, conditional: false,
  sourceUrl: 'https://example.com', quote: null, props: [], ...over,
});
const rating = (teamId: string, overrides = {}) => ({
  id: `NFL:${teamId}`, sport: 'NFL' as const, teamId, teamName: teamId,
  rating: 1500, games: 4, wins: 2, losses: 2, streak: 0, recentForm: [] as string[], lastGameDate: '2026-10-03', ...overrides,
});

test('sigmoid is bounded and centered', () => {
  assert.equal(sigmoid(0), 0.5);
  assert.ok(sigmoid(5) > 0.99 && sigmoid(-5) < 0.01);
});

test('logistic prediction favors the stronger home team', () => {
  const w = DEFAULT_WEIGHTS.NFL;
  const p = predictHomeProb({ elo: 1, winPct: 0.5, form: 0.4, home: 1, rest: 0, streak: 0.2 }, w);
  assert.ok(p > 0.7, `expected strong home prob, got ${p}`);
  const q = predictHomeProb({ elo: -1, winPct: -0.5, form: -0.4, home: 0, rest: 0, streak: -0.2 }, w);
  assert.ok(q < 0.35, `expected weak home prob, got ${q}`);
});

test('neutral site removes the home edge', () => {
  const w = DEFAULT_WEIGHTS.NFL;
  const a = predictHomeProb({ elo: 0, winPct: 0, form: 0, home: 1, rest: 0, streak: 0 }, w);
  const b = predictHomeProb({ elo: 0, winPct: 0, form: 0, home: 0, rest: 0, streak: 0 }, w);
  assert.ok(a > b && b === 0.5);
});

test('calibration only adjusts with enough samples', () => {
  const thin = applyCalibration(0.7, { '70-75': { predicted: 0.7, observed: 0.5, count: 3 } });
  assert.equal(thin.adjusted, false);
  const rich = applyCalibration(0.7, { '70-75': { predicted: 0.72, observed: 0.5, count: 20 } });
  assert.equal(rich.adjusted, true);
  assert.ok(rich.prob < 0.7 && rich.prob > 0.5);
});

test('tiers follow thresholds', () => {
  assert.equal(tierFor(0.7, DEFAULT_THRESHOLDS), 'LOCK');
  assert.equal(tierFor(0.63, DEFAULT_THRESHOLDS), 'STRONG');
  assert.equal(tierFor(0.57, DEFAULT_THRESHOLDS), 'LEAN');
  assert.equal(tierFor(0.52, DEFAULT_THRESHOLDS), 'PASS');
});

test('fair odds mirror the safety engine convention', () => {
  assert.equal(fairAmerican(0.68), -213);
  assert.equal(fairAmerican(0.4), 150);
});

test('weights stay bounded and versions bump', () => {
  assert.equal(clampWeight('elo', 99), 3.0);
  assert.equal(clampWeight('home', -99), -0.4);
  assert.equal(bumpVersion('3.0.4'), '3.0.5');
  assert.equal(bumpVersion('garbage'), '3.0.0');
});

test('records parse with dashes and en dashes', () => {
  assert.deepEqual(parseRecord('3-1'), { wins: 3, losses: 1, pct: 0.75, games: 4 });
  assert.deepEqual(parseRecord('10–6'), { wins: 10, losses: 6, pct: 0.625, games: 16 });
  assert.equal(parseRecord(undefined).pct, 0.5);
});

test('elo expectations are symmetric', () => {
  assert.equal(expectedScore(1500, 1500), 0.5);
  assert.ok(expectedScore(1700, 1500) > 0.75);
  assert.ok(Math.abs(expectedScore(1600, 1500) + expectedScore(1500, 1600) - 1) < 1e-9);
});

test('form, rest and K factors behave', () => {
  assert.equal(formScore(['W', 'W', 'L', 'W', 'W']), 0.8);
  assert.equal(formScore([]), null);
  assert.equal(daysBetween('2026-10-01', '2026-10-10'), 9);
  assert.equal(daysBetween(null, '2026-10-10'), null);
  assert.ok(K_FACTOR.NFL > K_FACTOR.MLB);
});

test('features favor the 3-1 home team over the 1-3 road team', () => {
  const g = game();
  const built = buildFeatures(g, rating('1', { rating: 1560, recentForm: ['W', 'W', 'W', 'L', 'W'], streak: 1 }), rating('2', { rating: 1440, recentForm: ['L', 'L', 'W', 'L', 'L'], streak: -2 }));
  assert.ok(built.features.elo > 0 && built.features.winPct > 0 && built.features.form > 0);
  assert.equal(built.features.home, 1);
  assert.ok(built.reasoning.length >= 2);
  const p = predictHomeProb(built.features, DEFAULT_WEIGHTS.NFL);
  assert.ok(p > 0.6, `expected home favoritism, got ${p}`);
});

test('pitcher edge rewards the better run prevention', () => {
  const g = game({ sport: 'MLB', home: { ...game().home, starter: { id: '1', name: 'Ace Home', status: 'probable' } }, away: { ...game().away, starter: { id: '2', name: 'Mid Road', status: 'probable' } } });
  const edge = pitcherEdgeFromStats({ era: 2.8, whip: 1.05, strikeoutsPer9Inn: 10.5, inningsPitched: 120 }, { era: 4.6, whip: 1.38, strikeoutsPer9Inn: 7.5, inningsPitched: 110 }, g);
  assert.ok(edge.edge > 0.2 && !edge.missing && edge.detail?.includes('Ace Home'));
  const missing = pitcherEdgeFromStats(null, null, g);
  assert.equal(missing.missing, true);
});

test('injury scoring weights QBs and Out/IR far above a backup lineman', () => {
  assert.ok(scoreInjury('NFL', 'QB', 'Out') > 0.9);
  assert.ok(scoreInjury('NFL', 'QB', 'Questionable') < scoreInjury('NFL', 'QB', 'Out'));
  assert.equal(scoreInjury('NFL', 'QB', 'Active'), 0);
  assert.ok(scoreInjury('NFL', 'QB', 'Out') > scoreInjury('NFL', 'WR', 'Out') * 2);
  assert.ok(scoreInjury('MLB', 'SP', '15-Day-IL') > scoreInjury('MLB', 'RF', 'Day-To-Day'));
});

test('a listed QB Out is injected into reasoning and the injuries feature', () => {
  const g = game({
    homeInjuries: {
      teamId: '1', teamName: 'Home Team', fetchedAt: new Date().toISOString(), sourceUrl: 'https://www.espn.com/nfl/injuries',
      impact: 1, headline: 'QB out',
      players: [{ player: 'Starter McGee', position: 'QB', status: 'Out', statusKey: 'out', bodyPart: 'Ankle', comment: 'Ruled out', returnDate: null, updatedAt: new Date().toISOString(), impact: 1 }],
    },
  });
  const built = buildFeatures(g, rating('1'), rating('2'));
  assert.ok(built.features.injuries < 0, `home QB out should hurt home side, got ${built.features.injuries}`);
  assert.ok(built.reasoning.some((r) => r.includes('Starter McGee')));
  assert.ok(built.warnings.some((w) => /quarterback/i.test(w)));
});

test('buckets cover the confidence range', () => {
  assert.equal(bucketFor(0.52), '50-55');
  assert.equal(bucketFor(0.68), '65-70');
  assert.equal(bucketFor(0.99), '90-95');
});
