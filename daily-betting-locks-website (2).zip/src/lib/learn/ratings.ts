import { eq, and } from 'drizzle-orm';
import { db } from '@/db';
import { adaptiveTeamRatings } from '@/db/schema';
import type { Sport } from '../types';

export const K_FACTOR: Record<Sport, number> = { NFL: 24, MLB: 14 };
const BASE_RATING = 1500;

export type TeamRating = {
  id: string; sport: Sport; teamId: string; teamName: string;
  rating: number; games: number; wins: number; losses: number;
  streak: number; recentForm: string[]; lastGameDate: string | null;
};

export function ratingId(sport: Sport, teamId: string) { return `${sport}:${teamId}`; }

/** Parse "12-4", "12–4" (en dash), "12 - 4" into win pct. */
export function parseRecord(record?: string): { wins: number; losses: number; pct: number; games: number } {
  if (!record) return { wins: 0, losses: 0, pct: 0.5, games: 0 };
  const m = record.replace(/[–—]/g, '-').match(/(\d+)\s*-\s*(\d+)/);
  if (!m) return { wins: 0, losses: 0, pct: 0.5, games: 0 };
  const wins = parseInt(m[1], 10), losses = parseInt(m[2], 10);
  const games = wins + losses;
  return { wins, losses, pct: games ? wins / games : 0.5, games };
}

export function expectedScore(ratingA: number, ratingB: number) {
  return 1 / (1 + Math.pow(10, -(ratingA - ratingB) / 400));
}

export async function getRating(sport: Sport, teamId: string, teamName: string): Promise<TeamRating> {
  const id = ratingId(sport, teamId);
  const [row] = await db.select().from(adaptiveTeamRatings).where(eq(adaptiveTeamRatings.id, id)).limit(1);
  if (row) {
    return {
      id: row.id, sport: row.sport as Sport, teamId: row.teamId, teamName: row.teamName,
      rating: row.rating, games: row.games, wins: row.wins, losses: row.losses,
      streak: row.streak, recentForm: (row.recentForm ?? []) as string[], lastGameDate: row.lastGameDate,
    };
  }
  const created: TeamRating = {
    id, sport, teamId, teamName, rating: BASE_RATING, games: 0, wins: 0, losses: 0, streak: 0, recentForm: [], lastGameDate: null,
  };
  try {
    await db.insert(adaptiveTeamRatings).values({
      id, sport, teamId, teamName, rating: BASE_RATING, games: 0, wins: 0, losses: 0, streak: 0, recentForm: [],
    }).onConflictDoNothing();
  } catch { /* ratings work from defaults if the table is unavailable */ }
  return created;
}

export async function getRatingsBatch(sport: Sport, teams: { id: string; name: string }[]): Promise<Map<string, TeamRating>> {
  const out = new Map<string, TeamRating>();
  await Promise.all(teams.map(async (t) => { out.set(t.id, await getRating(sport, t.id, t.name)); }));
  return out;
}

/** Recent-form score 0..1 from last-5 W/L strings; null when no history yet. */
export function formScore(recentForm: string[]): number | null {
  if (!recentForm.length) return null;
  const last = recentForm.slice(-5);
  return last.filter((r) => r === 'W').length / last.length;
}

/** Days between two YYYY-MM-DD dates. */
export function daysBetween(a: string | null | undefined, b: string): number | null {
  if (!a) return null;
  const ms = Date.parse(b) - Date.parse(a);
  if (!Number.isFinite(ms)) return null;
  return Math.round(ms / 86400000);
}

export async function applyResult(
  sport: Sport,
  homeId: string, homeName: string,
  awayId: string, awayName: string,
  homeScore: number, awayScore: number,
  gameDate: string,
): Promise<{ homeDelta: number; awayDelta: number; pushed: boolean }> {
  const pushed = homeScore === awayScore;
  const homeWon = homeScore > awayScore;
  const [home, away] = await Promise.all([
    getRating(sport, homeId, homeName),
    getRating(sport, awayId, awayName),
  ]);
  const k = K_FACTOR[sport];
  const expHome = expectedScore(home.rating, away.rating);
  // Margin-of-victory multiplier (damped): blowouts teach more, but not linearly.
  const margin = Math.abs(homeScore - awayScore);
  const mov = pushed ? 0 : Math.log(margin + 1) * (sport === 'NFL' ? 0.55 : 0.32) + 0.55;
  const actualHome = pushed ? 0.5 : homeWon ? 1 : 0;
  const delta = k * mov * (actualHome - expHome);
  const homeDelta = Math.max(-48, Math.min(48, delta));

  const pushForm = async (r: TeamRating, won: boolean) => {
    const form = [...r.recentForm, pushed ? 'P' : won ? 'W' : 'L'].slice(-10);
    const streak = pushed ? 0 : won ? (r.streak >= 0 ? r.streak + 1 : 1) : (r.streak <= 0 ? r.streak - 1 : -1);
    await db.update(adaptiveTeamRatings).set({
      rating: Math.round((r.rating + (r.teamId === homeId ? homeDelta : -homeDelta)) * 10) / 10,
      games: r.games + 1,
      wins: r.wins + (!pushed && won ? 1 : 0),
      losses: r.losses + (!pushed && !won ? 1 : 0),
      streak, recentForm: form, lastGameDate: gameDate, updatedAt: new Date(),
    }).where(and(eq(adaptiveTeamRatings.sport, sport), eq(adaptiveTeamRatings.teamId, r.teamId)));
  };
  await Promise.all([pushForm(home, homeWon), pushForm(away, !homeWon)]);
  return { homeDelta: Math.round(homeDelta * 10) / 10, awayDelta: Math.round(-homeDelta * 10) / 10, pushed };
}

export async function topRatings(sport: Sport, limit = 10) {
  const rows = await db.select().from(adaptiveTeamRatings).where(eq(adaptiveTeamRatings.sport, sport)).limit(60);
  return rows.sort((a, b) => b.rating - a.rating).slice(0, limit).map((r) => ({
    sport: r.sport as Sport, teamId: r.teamId, teamName: r.teamName,
    rating: Math.round(r.rating), games: r.games, wins: r.wins, streak: r.streak,
  }));
}
