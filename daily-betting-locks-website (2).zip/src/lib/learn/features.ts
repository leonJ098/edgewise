import type { Game, Sport } from '../types';
import { parseRecord, formScore, daysBetween, type TeamRating } from './ratings';
import { injuryFeature, qbStatus } from '../data/injuries';

export type PitcherEdge = {
  edge: number; // home-perspective, roughly -1..1
  detail: string | null;
  missing: boolean;
};

export type BuiltFeatures = {
  features: Record<string, number>;
  reasoning: string[];
  warnings: string[];
  inputs: {
    homePct: number; awayPct: number; homeGames: number; awayGames: number;
    eloDiff: number; formDiff: number | null; restDiff: number | null; streakDiff: number;
  };
};

/** Clamp helper so one noisy input can't dominate the logit. */
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export function buildFeatures(
  game: Game,
  homeRating: TeamRating,
  awayRating: TeamRating,
  pitcher?: PitcherEdge,
): BuiltFeatures {
  const home = parseRecord(game.home.record);
  const away = parseRecord(game.away.record);
  const reasoning: string[] = [];
  const warnings: string[] = [];

  // Season record gap, shrunk toward .500 early in the season.
  const shrink = (games: number) => Math.min(1, games / (game.sport === 'NFL' ? 6 : 40));
  const homePctS = 0.5 + (home.pct - 0.5) * shrink(home.games || homeRating.games);
  const awayPctS = 0.5 + (away.pct - 0.5) * shrink(away.games || awayRating.games);
  const winPctDiff = clamp((homePctS - awayPctS) * 2, -1, 1);

  // Elo gap normalized: 200 points ≈ 1 unit.
  const eloDiff = homeRating.rating - awayRating.rating;
  const eloFeat = clamp(eloDiff / 200, -2, 2);

  // Recent form gap from tracked W/L only — never double-count season record.
  const hf = formScore(homeRating.recentForm);
  const af = formScore(awayRating.recentForm);
  const formDiff = hf !== null && af !== null ? clamp(hf - af, -1, 1) : 0;

  // Home edge: neutral site cancels it.
  const homeFeat = game.neutralSite ? 0 : 1;

  // Rest edge from last-game dates (tracked as we grade).
  const homeRest = daysBetween(homeRating.lastGameDate, game.date);
  const awayRest = daysBetween(awayRating.lastGameDate, game.date);
  const restDiff = homeRest !== null && awayRest !== null ? clamp((homeRest - awayRest) / 7, -1, 1) : 0;

  // Momentum gap from streaks.
  const streakDiff = clamp((homeRating.streak - awayRating.streak) / 5, -1, 1);

  const features: Record<string, number> = {
    elo: Math.round(eloFeat * 1000) / 1000,
    winPct: Math.round(winPctDiff * 1000) / 1000,
    form: Math.round(formDiff * 1000) / 1000,
    home: homeFeat,
    rest: Math.round(restDiff * 1000) / 1000,
    streak: Math.round(streakDiff * 1000) / 1000,
  };
  if (game.sport === 'MLB') {
    features.pitcher = pitcher ? Math.round(clamp(pitcher.edge, -1.5, 1.5) * 1000) / 1000 : 0;
  }
  const inj = injuryFeature(game);
  features.injuries = inj.value;

  // ── Human-readable reasoning (top drivers only) ──
  const lead = (v: number) => (v > 0.03 ? game.home.shortName : v < -0.03 ? game.away.shortName : null);
  if (Math.abs(eloDiff) >= 25) {
    const who = eloDiff > 0 ? game.home.shortName : game.away.shortName;
    reasoning.push(`${who} is rated ${Math.abs(Math.round(eloDiff))} points higher in the adaptive power rating (${Math.round(Math.max(homeRating.rating, awayRating.rating))} vs ${Math.round(Math.min(homeRating.rating, awayRating.rating))}).`);
  }
  if (Math.abs(homePctS - awayPctS) >= 0.06 && (home.games + away.games + homeRating.games + awayRating.games) > 0) {
    const who = homePctS >= awayPctS ? game.home.shortName : game.away.shortName;
    reasoning.push(`${who} owns the better record (${game.home.record ?? '—'} vs ${game.away.record ?? '—'}), shrunk for sample size.`);
  }
  if (hf !== null && af !== null && Math.abs(hf - af) >= 0.2) {
    const who = hf > af ? game.home.shortName : game.away.shortName;
    reasoning.push(`${who} is in better recent form (${homeRating.recentForm.slice(-5).join('') || '—'} vs ${awayRating.recentForm.slice(-5).join('') || '—'} over the last five tracked games).`);
  }
  if (pitcher?.detail) reasoning.push(pitcher.detail);
  for (const note of inj.notes.slice(0, 3)) reasoning.push(note);
  if (!game.neutralSite) reasoning.push(`Home-field edge at ${game.venue} (${game.home.shortName}).`);
  else reasoning.push('Neutral-site game — no home-field edge applied.');
  if (Math.abs(homeRating.streak) >= 3 || Math.abs(awayRating.streak) >= 3) {
    const hot = homeRating.streak >= 3 ? game.home.shortName : awayRating.streak >= 3 ? game.away.shortName : null;
    const cold = homeRating.streak <= -3 ? game.home.shortName : awayRating.streak <= -3 ? game.away.shortName : null;
    if (hot) reasoning.push(`${hot} rides a ${Math.max(homeRating.streak, awayRating.streak)}-game winning streak.`);
    if (cold) reasoning.push(`${cold} is mired in a ${Math.abs(Math.min(homeRating.streak, awayRating.streak))}-game skid.`);
  }
  const leader = lead(winPctDiff + eloFeat * 0.5);
  if (!reasoning.length && leader) reasoning.push(`${leader} grades slightly better across the blended inputs.`);

  // ── Honest warnings ──
  if (homeRating.games + awayRating.games < 4) warnings.push('Early-season sample: both power ratings are close to the 1500 baseline.');
  if (game.sport === 'MLB' && (!pitcher || pitcher.missing)) warnings.push('Starting-pitcher comparison is incomplete — pitcher edge set to neutral.');
  if (game.sport === 'NFL' && !game.week) warnings.push('NFL week could not be verified for this matchup.');
  if (game.doubleheader) warnings.push('Doubleheader game — bullpen and lineup usage add variance.');
  if (game.sport === 'NFL' && home.games + away.games < 8) warnings.push('Short NFL season sample — records are heavily shrunk toward average.');
  warnings.push(...inj.warnings);
  const homeQb = qbStatus(game.homeInjuries);
  const awayQb = qbStatus(game.awayInjuries);
  if (homeQb?.statusKey === 'questionable' || awayQb?.statusKey === 'questionable') {
    warnings.push('A starting quarterback is questionable — availability can change up to kickoff. Recheck the report before betting.');
  }

  return {
    features, reasoning: reasoning.slice(0, 7), warnings,
    inputs: { homePct: homePctS, awayPct: awayPctS, homeGames: home.games, awayGames: away.games, eloDiff, formDiff: hf !== null && af !== null ? hf - af : null, restDiff: homeRest !== null && awayRest !== null ? homeRest - awayRest : null, streakDiff: homeRating.streak - awayRating.streak },
  };
}

/** Convert pitcher season stats into a home-perspective edge. */
export function pitcherEdgeFromStats(
  home: Record<string, string | number | boolean | null> | null,
  away: Record<string, string | number | boolean | null> | null,
  game: Game,
): PitcherEdge {
  const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v)) ? Number(v) : null);
  if (!home || !away) {
    return { edge: 0, detail: null, missing: true };
  }
  // Lower ERA/WHIP is better; higher K/9 is better. League-ish anchors keep it bounded.
  const eraH = num(home.era), eraA = num(away.era);
  const whipH = num(home.whip), whipA = num(away.whip);
  const kH = num(home.strikeoutsPer9Inn), kA = num(away.strikeoutsPer9Inn);
  const ipH = num(home.inningsPitched), ipA = num(away.inningsPitched);
  let edge = 0, parts = 0;
  if (eraH !== null && eraA !== null) { edge += clamp((eraA - eraH) / 2.5, -1, 1); parts++; }
  if (whipH !== null && whipA !== null) { edge += clamp((whipA - whipH) / 0.6, -1, 1); parts++; }
  if (kH !== null && kA !== null) { edge += clamp((kH - kA) / 4, -1, 1); parts++; }
  if (!parts) return { edge: 0, detail: null, missing: true };
  edge = edge / parts;
  // Shrink when either starter has a tiny sample.
  const minIP = Math.min(ipH ?? 0, ipA ?? 0);
  if (minIP < 20) edge *= 0.4 + (minIP / 20) * 0.6;
  const hn = game.home.starter?.name ?? 'Home starter', an = game.away.starter?.name ?? 'Away starter';
  const fmt = (v: number | null, d = 2) => (v === null ? '—' : v.toFixed(d));
  const detail = edge > 0.08
    ? `${hn} grades better on season run prevention (ERA ${fmt(eraH)} / WHIP ${fmt(whipH)} vs ${fmt(eraA)} / ${fmt(whipA)}).`
    : edge < -0.08
      ? `${an} grades better on season run prevention (ERA ${fmt(eraA)} / WHIP ${fmt(whipA)} vs ${fmt(eraH)} / ${fmt(whipH)}).`
      : `Starting-pitcher comparison is close (${hn.split(' ').slice(-1)} ERA ${fmt(eraH)} vs ${an.split(' ').slice(-1)} ERA ${fmt(eraA)}).`;
  return { edge: Math.round(edge * 1000) / 1000, detail, missing: false };
}

export type { Sport };
