import type { Sport } from '../types';

// Adaptive model v3: self-contained logistic model over free-data features.
// Weights live in the DB and are updated by the learning cycle after every
// batch of graded games. Nothing here requires a paid feed.

export const ADAPTIVE_BASE_VERSION = '3.0.0';

export const DEFAULT_WEIGHTS: Record<Sport, Record<string, number>> = {
  NFL: { elo: 1.6, winPct: 1.1, form: 0.9, home: 0.45, rest: 0.25, streak: 0.15, injuries: 1.35, intercept: 0 },
  MLB: { elo: 1.4, winPct: 0.9, form: 0.8, home: 0.35, pitcher: 1.2, rest: 0.15, injuries: 0.95, intercept: 0 },
};

export const DEFAULT_THRESHOLDS = { lock: 0.68, strong: 0.62, lean: 0.56 };

export const WEIGHT_BOUNDS: Record<string, [number, number]> = {
  elo: [0.4, 3.0], winPct: [0.1, 2.5], form: [0.1, 2.0], home: [-0.4, 1.2],
  pitcher: [0.2, 2.5], rest: [-0.5, 0.8], streak: [-0.4, 0.8], intercept: [-0.5, 0.5],
};

export const FEATURE_LABELS: Record<string, string> = {
  elo: 'Power rating gap', winPct: 'Season record gap', form: 'Recent form gap',
  home: 'Home-field edge', pitcher: 'Starting-pitcher edge', rest: 'Rest edge',
  streak: 'Momentum gap', injuries: 'Injury-report edge', intercept: 'Baseline',
};

export function sigmoid(x: number) { return 1 / (1 + Math.exp(-Math.max(-12, Math.min(12, x)))); }

export function logitOf(p: number) {
  const c = Math.min(0.985, Math.max(0.015, p));
  return Math.log(c / (1 - c));
}

/** Raw logistic prediction from home-perspective features. */
export function predictHomeProb(features: Record<string, number>, weights: Record<string, number>): number {
  let logit = weights.intercept ?? 0;
  for (const [key, value] of Object.entries(features)) {
    if (key === 'intercept') continue;
    const w = weights[key] ?? 0;
    if (Number.isFinite(value) && Number.isFinite(w)) logit += w * value;
  }
  return sigmoid(logit);
}

export function bucketFor(p: number): string {
  const lo = Math.floor(Math.min(0.94, Math.max(0.5, p)) * 20) * 5;
  return `${lo}-${lo + 5}`;
}

/** Shrink raw probability toward observed bucket performance (learned calibration). */
export function applyCalibration(
  raw: number,
  calibration: Record<string, { predicted: number; observed: number; count: number }>,
): { prob: number; adjusted: boolean } {
  const bucket = calibration[bucketFor(raw)];
  if (!bucket || bucket.count < 8) return { prob: raw, adjusted: false };
  const gap = bucket.observed - bucket.predicted;
  const adjusted = Math.min(0.96, Math.max(0.04, raw + gap * 0.5));
  return { prob: adjusted, adjusted: Math.abs(adjusted - raw) > 0.004 };
}

export function tierFor(confidence: number, t: { lock: number; strong: number; lean: number }) {
  if (confidence >= t.lock) return 'LOCK' as const;
  if (confidence >= t.strong) return 'STRONG' as const;
  if (confidence >= t.lean) return 'LEAN' as const;
  return 'PASS' as const;
}

export function fairAmerican(p: number): number | null {
  if (!Number.isFinite(p) || p <= 0.01 || p >= 0.99) return null;
  return Math.round(p >= 0.5 ? (-100 * p) / (1 - p) : (100 * (1 - p)) / p);
}

export function clampWeight(key: string, value: number): number {
  const [lo, hi] = WEIGHT_BOUNDS[key] ?? [-2, 2];
  return Math.min(hi, Math.max(lo, value));
}

export function bumpVersion(version: string): string {
  const parts = version.split('.').map((n) => parseInt(n, 10));
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return ADAPTIVE_BASE_VERSION;
  return `${parts[0]}.${parts[1]}.${parts[2] + 1}`;
}
