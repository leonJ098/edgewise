import { eq, desc } from 'drizzle-orm';
import { db } from '@/db';
import { adaptivePredictions } from '@/db/schema';
import type { Game, LocksData, ModelPick, Side, Sport } from '../types';
import { getModelState, learningCycle } from './evolve';
import { getRatingsBatch } from './ratings';
import { buildFeatures, pitcherEdgeFromStats } from './features';
import { predictHomeProb, applyCalibration, tierFor, fairAmerican } from './model';
import { getSchedules, mlbPitcherDetail } from '../data/providers';
import { attachInjuries, qbStatus } from '../data/injuries';
import { easternDate, addDays } from '../safety/engine';

async function pitcherEdges(games: Game[]): Promise<Map<string, { edge: number; detail: string | null; missing: boolean }>> {
  const out = new Map<string, { edge: number; detail: string | null; missing: boolean }>();
  const mlb = games.filter((g) => g.sport === 'MLB' && g.status === 'scheduled');
  await Promise.all(mlb.slice(0, 24).map(async (g) => {
    try {
      const details = await mlbPitcherDetail(g);
      const home = details.find((d) => d.side === 'home')?.season ?? null;
      const away = details.find((d) => d.side === 'away')?.season ?? null;
      out.set(g.id, pitcherEdgeFromStats(home, away, g));
    } catch {
      out.set(g.id, { edge: 0, detail: null, missing: true });
    }
  }));
  return out;
}

export async function getModelLocks(date = easternDate(), days = 7): Promise<LocksData> {
  // ── Always be learning: grade new finals + evolve before predicting ──
  let learning = { newlyGraded: 0, lessonsCreated: 0, evolved: false, summary: null as string | null };
  try {
    const cycle = await learningCycle();
    const summaries = [...new Set(cycle.results.map((r) => r.summary).filter(Boolean))];
    learning = {
      newlyGraded: cycle.graded,
      lessonsCreated: cycle.results.reduce((s, r) => s + r.lessonsCreated, 0),
      evolved: cycle.results.some((r) => r.changed),
      summary: summaries.join(' ') || null,
    };
  } catch {
    // Predictions must work even if the learning step hiccups.
  }

  const [schedule, nflState, mlbState] = await Promise.all([
    getSchedules(date, days),
    getModelState('NFL'),
    getModelState('MLB'),
  ]);
  const states: Record<Sport, typeof nflState> = { NFL: nflState, MLB: mlbState };
  const upcoming = schedule.games
    .filter((g) => g.status === 'scheduled' && Date.parse(g.startsAt) > Date.now())
    .sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt));

  try { await attachInjuries(upcoming); } catch { /* injury miss is a warning, not a crash */ }
  const edges = await pitcherEdges(upcoming);
  const picks: ModelPick[] = [];

  for (const sport of ['NFL', 'MLB'] as Sport[]) {
    const games = upcoming.filter((g) => g.sport === sport);
    if (!games.length) continue;
    const state = states[sport];
    const teams = games.flatMap((g) => [{ id: g.home.id, name: g.home.name }, { id: g.away.id, name: g.away.name }]);
    const ratings = await getRatingsBatch(sport, [...new Map(teams.map((t) => [t.id, t])).values()]);
    for (const g of games) {
      const homeR = ratings.get(g.home.id)!, awayR = ratings.get(g.away.id)!;
      const built = buildFeatures(g, homeR, awayR, sport === 'MLB' ? edges.get(g.id) : undefined);
      let raw = predictHomeProb(built.features, state.weights);
      // Cold-start tempering: shrink toward 50/50 until both teams have tracked history.
      if (homeR.games + awayR.games < 6) raw = 0.5 + (raw - 0.5) * 0.7;
      const { prob, adjusted } = applyCalibration(raw, state.calibration);
      const predictedSide: Side = prob >= 0.5 ? 'home' : 'away';
      let confidence = predictedSide === 'home' ? prob : 1 - prob;
      let tier = tierFor(confidence, state.thresholds);
      const warnings = [...built.warnings];
      if (adjusted) warnings.push('Probability adjusted by learned calibration from similar past picks.');
      const pickQb = qbStatus(predictedSide === 'home' ? g.homeInjuries : g.awayInjuries);
      if (pickQb && ['out', 'ir', 'doubtful'].includes(pickQb.statusKey)) {
        tier = 'PASS';
        warnings.unshift(`${predictedSide === 'home' ? g.home.shortName : g.away.shortName} QB ${pickQb.player} is ${pickQb.status}. This side cannot be a lock until the quarterback is cleared.`);
      } else if (pickQb?.statusKey === 'questionable' && (tier === 'LOCK' || tier === 'STRONG')) {
        tier = 'LEAN';
        warnings.unshift(`Quarterback ${pickQb.player} is questionable. Confidence capped at a lean until the game-day report is final.`);
      }
      const reasoning = [...built.reasoning];
      if (tier === 'LOCK') reasoning.unshift(`Model confidence ${Math.round(confidence * 100)}% clears the ${Math.round(state.thresholds.lock * 100)}% lock bar (v${state.version}) after the live injury report.`);
      const pick: ModelPick = {
        gameId: g.id, sport, date: g.date, startsAt: g.startsAt,
        homeId: g.home.id, awayId: g.away.id, homeName: g.home.name, awayName: g.away.name,
        homeAbbr: g.home.abbreviation, awayAbbr: g.away.abbreviation, venue: g.venue,
        predictedSide, pickName: predictedSide === 'home' ? g.home.name : g.away.name,
        homeProb: Math.round(prob * 1000) / 1000, confidence: Math.round(confidence * 1000) / 1000,
        tier, edge: Math.round(Math.abs(prob - 0.5) * 2000) / 10,
        fairOdds: fairAmerican(predictedSide === 'home' ? prob : 1 - prob),
        features: built.features, reasoning, warnings,
        modelVersion: state.version, status: 'pending',
        injuries: {
          home: g.homeInjuries?.players ?? [],
          away: g.awayInjuries?.players ?? [],
          homeImpact: g.homeInjuries?.impact ?? 0,
          awayImpact: g.awayInjuries?.impact ?? 0,
          summary: [g.awayInjuries?.headline, g.homeInjuries?.headline].filter((x): x is string => !!x),
          fetchedAt: g.homeInjuries?.fetchedAt ?? g.awayInjuries?.fetchedAt ?? null,
          sourceUrl: g.homeInjuries?.sourceUrl ?? g.awayInjuries?.sourceUrl ?? null,
        },
        spread: g.spread, overUnder: g.overUnder, broadcast: g.broadcast,
      };
      picks.push(pick);
      // Persist for future grading (never overwrite a graded pick).
      try {
        const [existing] = await db.select({ id: adaptivePredictions.id, status: adaptivePredictions.status })
          .from(adaptivePredictions).where(eq(adaptivePredictions.gameId, g.id)).limit(1);
        if (!existing) {
          await db.insert(adaptivePredictions).values({
            gameId: g.id, sport, homeId: g.home.id, awayId: g.away.id,
            homeName: g.home.name, awayName: g.away.name, date: g.date, startsAt: new Date(g.startsAt),
            predictedSide, homeProb: pick.homeProb, confidence: pick.confidence, tier,
            edge: pick.edge, features: built.features, reasoning, modelVersion: state.version,
          }).onConflictDoNothing();
        } else if (existing.status === 'pending') {
          await db.update(adaptivePredictions).set({
            predictedSide, homeProb: pick.homeProb, confidence: pick.confidence, tier,
            edge: pick.edge, features: built.features, reasoning, modelVersion: state.version,
          }).where(eq(adaptivePredictions.id, existing.id));
        }
      } catch { /* a cache hiccup must not block picks */ }
    }
  }

  picks.sort((a, b) => b.confidence - a.confidence || Date.parse(a.startsAt) - Date.parse(b.startsAt));
  // The card: top 3, but never two picks that are really the same game.
  const seen = new Set<string>();
  const locks: typeof picks = [];
  for (const p of picks) {
    if (locks.length >= 3) break;
    if (seen.has(p.gameId)) continue;
    seen.add(p.gameId);
    locks.push(p);
  }

  const performance = {} as LocksData['performance'];
  for (const sport of ['NFL', 'MLB'] as Sport[]) {
    const s = states[sport].stats;
    const recentRows = await db.select({ status: adaptivePredictions.status }).from(adaptivePredictions)
      .where(eq(adaptivePredictions.sport, sport)).orderBy(desc(adaptivePredictions.gradedAt)).limit(40);
    const gradedRecent = recentRows.filter((r) => r.status === 'win' || r.status === 'loss');
    let streak = 0;
    for (const r of gradedRecent) {
      if (r.status === 'win' && streak >= 0) streak++;
      else if (r.status === 'loss' && streak <= 0) streak--;
      else break;
    }
    performance[sport] = {
      graded: s.graded, wins: s.wins, losses: s.losses, pushes: s.pushes,
      winRate: s.graded ? s.wins / s.graded : null,
      brier: s.graded ? s.brierSum / s.graded : null, streak,
    };
  }

  return {
    locks, all: picks, today: easternDate(), startDate: date, endDate: addDays(date, days - 1),
    refreshedAt: new Date().toISOString(),
    modelVersions: { NFL: nflState.version, MLB: mlbState.version },
    performance, learning,
  };
}
