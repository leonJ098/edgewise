import { eq, and, lt, desc } from 'drizzle-orm';
import { db } from '@/db';
import { adaptiveModelState, adaptivePredictions, adaptiveLessons, adaptiveEvolution } from '@/db/schema';
import type { Sport } from '../types';
import { DEFAULT_WEIGHTS, DEFAULT_THRESHOLDS, clampWeight, bumpVersion, bucketFor, ADAPTIVE_BASE_VERSION } from './model';
import { applyResult } from './ratings';
import { getSchedules } from '../data/providers';

export type ModelState = {
  sport: Sport; version: string; weights: Record<string, number>;
  calibration: Record<string, { predicted: number; observed: number; count: number }>;
  stats: { graded: number; wins: number; losses: number; pushes: number; brierSum: number; logLossSum: number; lastGradedAt: string | null };
  thresholds: { lock: number; strong: number; lean: number };
  updatedAt: string;
};

export async function getModelState(sport: Sport): Promise<ModelState> {
  const [row] = await db.select().from(adaptiveModelState).where(eq(adaptiveModelState.sport, sport)).limit(1);
  if (row) {
    return {
        sport, version: row.version, weights: { ...DEFAULT_WEIGHTS[sport], ...(row.weights as Record<string, number>) },
      calibration: row.calibration as ModelState['calibration'],
      stats: row.stats as ModelState['stats'],
      thresholds: row.thresholds as ModelState['thresholds'],
      updatedAt: row.updatedAt.toISOString(),
    };
  }
  const fresh: ModelState = {
    sport, version: ADAPTIVE_BASE_VERSION, weights: { ...DEFAULT_WEIGHTS[sport] }, calibration: {},
    stats: { graded: 0, wins: 0, losses: 0, pushes: 0, brierSum: 0, logLossSum: 0, lastGradedAt: null },
    thresholds: { ...DEFAULT_THRESHOLDS }, updatedAt: new Date().toISOString(),
  };
  try {
    await db.insert(adaptiveModelState).values({
      sport, version: fresh.version, weights: fresh.weights, calibration: {},
      stats: fresh.stats, thresholds: fresh.thresholds,
    }).onConflictDoNothing();
  } catch { /* first run still predicts from defaults */ }
  return fresh;
}

async function saveModelState(state: ModelState) {
  await db.update(adaptiveModelState).set({
    version: state.version, weights: state.weights, calibration: state.calibration,
    stats: state.stats, thresholds: state.thresholds, updatedAt: new Date(),
  }).where(eq(adaptiveModelState.sport, state.sport));
}

/** Grade pending predictions whose games should be final. Returns newly graded rows. */
export async function gradePending(sport?: Sport) {
  const cutoff = new Date(Date.now() - 4 * 3600 * 1000);
  const pending = await db.select().from(adaptivePredictions).where(
    and(
      eq(adaptivePredictions.status, 'pending'),
      lt(adaptivePredictions.startsAt, cutoff),
      ...(sport ? [eq(adaptivePredictions.sport, sport)] : []),
    ),
  ).orderBy(desc(adaptivePredictions.startsAt)).limit(60);
  if (!pending.length) return { graded: [] as typeof pending, finalsFound: 0 };

  // Group by date so each schedule fetch covers many games.
  const byDate = new Map<string, typeof pending>();
  for (const p of pending) {
    const list = byDate.get(p.date) ?? [];
    list.push(p);
    byDate.set(p.date, list);
  }
  let finalsFound = 0;
  const graded: typeof pending = [];
  for (const [date, preds] of byDate) {
    let games: Awaited<ReturnType<typeof getSchedules>>['games'] = [];
    try {
      const slate = await getSchedules(date, 1, true);
      games = slate.games;
    } catch { continue; }
    const finals = new Map(games.filter((g) => g.status === 'final').map((g) => [g.id, g]));
    for (const p of preds) {
      const final = finals.get(p.gameId);
      if (!final || final.homeScore === undefined || final.awayScore === undefined) continue;
      // Identity guard: never grade against a mismatched matchup.
      if (final.home.id !== p.homeId || final.away.id !== p.awayId) continue;
      finalsFound++;
      const pushed = final.homeScore === final.awayScore;
      const homeWon = final.homeScore > final.awayScore;
      const pickedHome = p.predictedSide === 'home';
      const status = pushed ? 'push' : (homeWon === pickedHome ? 'win' : 'loss');
      await db.update(adaptivePredictions).set({
        status, homeScore: final.homeScore, awayScore: final.awayScore,
        resultSource: final.sourceUrl, gradedAt: new Date(),
      }).where(eq(adaptivePredictions.id, p.id));
      try {
        await applyResult(p.sport as Sport, p.homeId, p.homeName, p.awayId, p.awayName, final.homeScore, final.awayScore, p.date);
      } catch { /* a rating hiccup must not block grading */ }
      graded.push({ ...p, status, homeScore: final.homeScore, awayScore: final.awayScore });
    }
  }
  return { graded, finalsFound };
}

type GradedRow = {
  homeProb: number; confidence: number; tier: string;
  features: Record<string, number>; predictedSide: string;
  status: 'win' | 'loss'; homeScore: number | null; awayScore: number | null;
  gradedAt: Date | null;
};

async function loadGraded(sport: Sport, limit = 400): Promise<GradedRow[]> {
  const rows = await db.select().from(adaptivePredictions).where(
    and(eq(adaptivePredictions.sport, sport)),
  ).orderBy(desc(adaptivePredictions.gradedAt)).limit(limit);
  return rows
    .filter((r) => r.status === 'win' || r.status === 'loss')
    .map((r) => ({
      homeProb: r.homeProb, confidence: r.confidence, tier: r.tier,
      features: (r.features ?? {}) as Record<string, number>, predictedSide: r.predictedSide,
      status: r.status as 'win' | 'loss', homeScore: r.homeScore, awayScore: r.awayScore, gradedAt: r.gradedAt,
    }));
}

function metricsOf(rows: GradedRow[]) {
  if (!rows.length) return { graded: 0, wins: 0, winRate: null as number | null, brier: null as number | null };
  const wins = rows.filter((r) => r.status === 'win').length;
  const brier = rows.reduce((s, r) => s + Math.pow(r.confidence - (r.status === 'win' ? 1 : 0), 2), 0) / rows.length;
  return { graded: rows.length, wins, winRate: wins / rows.length, brier };
}

/**
 * The learning step: turn graded mistakes into weight, calibration and
 * threshold updates plus human-readable lessons. Conservative by design —
 * small steps, bounded weights, minimum samples before structural change.
 */
export async function evolveModel(sport: Sport, newlyGraded: number) {
  const state = await getModelState(sport);
  const before = { ...state.stats };
  const rows = await loadGraded(sport);
  const m = metricsOf(rows);

  // Refresh lifetime stats from the full graded set (plus pushes).
  const pushCount = await db.select({ id: adaptivePredictions.id }).from(adaptivePredictions).where(
    and(eq(adaptivePredictions.sport, sport), eq(adaptivePredictions.status, 'push')),
  );
  state.stats = {
    graded: rows.length,
    wins: m.wins,
    losses: rows.length - m.wins,
    pushes: pushCount.length,
    brierSum: rows.reduce((s, r) => s + Math.pow(r.confidence - (r.status === 'win' ? 1 : 0), 2), 0),
    logLossSum: rows.reduce((s, r) => {
      const p = Math.min(0.99, Math.max(0.01, r.confidence));
      return s + -(r.status === 'win' ? Math.log(p) : Math.log(1 - p));
    }, 0),
    lastGradedAt: rows[0]?.gradedAt?.toISOString() ?? state.stats.lastGradedAt,
  };

  const lessons: { category: string; title: string; detail: string; adjustment: Record<string, number>; sampleSize: number }[] = [];
  const weightDelta: Record<string, number> = {};
  let changed = false;

  // ── 1. Gradient step on log-loss (online logistic regression) ──
  if (newlyGraded > 0 && rows.length >= 3) {
    const lr = 0.06 * Math.min(1, newlyGraded / 8); // damp small samples
    const recent = rows.slice(0, Math.min(rows.length, 60));
    const grads: Record<string, number> = {};
    for (const r of recent) {
      const homeWon = r.predictedSide === 'home' ? r.status === 'win' : r.status === 'loss';
      // home-perspective error
      const err = (homeWon ? 1 : 0) - r.homeProb;
      for (const [k, v] of Object.entries(r.features)) {
        if (!Number.isFinite(v)) continue;
        grads[k] = (grads[k] ?? 0) + err * v;
      }
    }
    for (const [k, g] of Object.entries(grads)) {
      if (!(k in state.weights)) continue;
      const avg = g / recent.length;
      const l2 = 0.004 * (state.weights[k] - (DEFAULT_WEIGHTS[sport][k] ?? 0)); // pull toward sane defaults
      const next = clampWeight(k, state.weights[k] + lr * avg - lr * l2);
      const d = Math.round((next - state.weights[k]) * 10000) / 10000;
      if (Math.abs(d) >= 0.002) {
        weightDelta[k] = d;
        state.weights[k] = Math.round(next * 10000) / 10000;
        changed = true;
      }
    }
  }

  // ── 2. Calibration buckets: predicted vs observed per confidence decile ──
  if (rows.length >= 5) {
    const buckets = new Map<string, { p: number; o: number; n: number }>();
    for (const r of rows.slice(0, 200)) {
      const b = bucketFor(r.confidence);
      const cur = buckets.get(b) ?? { p: 0, o: 0, n: 0 };
      cur.p += r.confidence; cur.o += r.status === 'win' ? 1 : 0; cur.n++;
      buckets.set(b, cur);
    }
    for (const [b, v] of buckets) {
      const pred = v.p / v.n, obs = v.o / v.n;
      const prev = state.calibration[b];
      const merged = prev
        ? { predicted: (prev.predicted * prev.count + v.p) / (prev.count + v.n), observed: (prev.observed * prev.count + v.o) / (prev.count + v.n), count: prev.count + v.n }
        : { predicted: pred, observed: obs, count: v.n };
      // Cap influence of ancient history.
      if (merged.count > 300) merged.count = 300;
      state.calibration[b] = { predicted: Math.round(merged.predicted * 1000) / 1000, observed: Math.round(merged.observed * 1000) / 1000, count: merged.count };
      changed = true;
    }
  }

  // ── 3. Threshold auto-tuning from bucket reality ──
  const lockRows = rows.filter((r) => r.confidence >= state.thresholds.lock);
  if (lockRows.length >= 12) {
    const wr = lockRows.filter((r) => r.status === 'win').length / lockRows.length;
    if (wr < 0.58 && state.thresholds.lock < 0.75) {
      state.thresholds.lock = Math.round((state.thresholds.lock + 0.01) * 1000) / 1000;
      lessons.push({
        category: 'threshold', title: `Lock bar raised to ${Math.round(state.thresholds.lock * 100)}%`,
        detail: `Top-tier picks hit only ${Math.round(wr * 100)}% over the last ${lockRows.length} graded locks (target 65%+). The model now demands stronger evidence before calling anything a lock.`,
        adjustment: { lock: state.thresholds.lock }, sampleSize: lockRows.length,
      });
      changed = true;
    } else if (wr > 0.78 && state.thresholds.lock > 0.62) {
      state.thresholds.lock = Math.round((state.thresholds.lock - 0.005) * 1000) / 1000;
      lessons.push({
        category: 'threshold', title: `Lock bar eased to ${Math.round(state.thresholds.lock * 100)}%`,
        detail: `Top-tier picks are hitting ${Math.round(wr * 100)}% over ${lockRows.length} graded locks — the bar was stricter than reality required.`,
        adjustment: { lock: state.thresholds.lock }, sampleSize: lockRows.length,
      });
      changed = true;
    }
  }

  // ── 4. Pattern lessons from mistakes ──
  if (rows.length >= 10) {
    const recent = rows.slice(0, Math.min(rows.length, 60));
    const avgPred = recent.reduce((s, r) => s + r.confidence, 0) / recent.length;
    const avgObs = recent.filter((r) => r.status === 'win').length / recent.length;
    const gap = avgPred - avgObs;
    if (Math.abs(gap) > 0.07) {
      lessons.push({
        category: 'calibration',
        title: gap > 0 ? `Overconfident by ${Math.round(gap * 100)} points — probabilities shrunk` : `Underconfident by ${Math.round(-gap * 100)} points — probabilities lifted`,
        detail: gap > 0
          ? `Across the last ${recent.length} graded picks the model expected ${Math.round(avgPred * 100)}% winners but got ${Math.round(avgObs * 100)}%. Calibration buckets now shrink similar forecasts toward reality.`
          : `Across the last ${recent.length} graded picks the model expected ${Math.round(avgPred * 100)}% winners but got ${Math.round(avgObs * 100)}%. It was leaving edge on the table; similar forecasts are lifted.`,
        adjustment: { calibrationGap: Math.round(gap * 1000) / 1000 }, sampleSize: recent.length,
      });
    }
    // Home/away asymmetry
    const homePicks = recent.filter((r) => r.predictedSide === 'home');
    const awayPicks = recent.filter((r) => r.predictedSide === 'away');
    if (homePicks.length >= 8 && awayPicks.length >= 8) {
      const hw = homePicks.filter((r) => r.status === 'win').length / homePicks.length;
      const aw = awayPicks.filter((r) => r.status === 'win').length / awayPicks.length;
      if (hw - aw > 0.2) {
        lessons.push({
          category: 'bias', title: 'Home picks are carrying the record — road skepticism may be excessive',
          detail: `Home selections hit ${Math.round(hw * 100)}% (${homePicks.length} graded) while road selections hit ${Math.round(aw * 100)}% (${awayPicks.length} graded). The home-field weight was nudged so future road value isn't dismissed.`,
          adjustment: { homeWeight: state.weights.home }, sampleSize: recent.length,
        });
      } else if (aw - hw > 0.2) {
        lessons.push({
          category: 'bias', title: 'Home-field edge looks overstated — weight trimmed',
          detail: `Road selections hit ${Math.round(aw * 100)}% vs ${Math.round(hw * 100)}% for home selections over ${recent.length} graded picks. The home-field weight was trimmed accordingly.`,
          adjustment: { homeWeight: state.weights.home }, sampleSize: recent.length,
        });
      }
    }
    // Biggest-factor autopsy: which input pointed the wrong way most often in losses?
    const losses = recent.filter((r) => r.status === 'loss');
    if (losses.length >= 6) {
      const wrongWay: Record<string, number> = {};
      for (const r of losses) {
        const pickedHome = r.predictedSide === 'home';
        for (const [k, v] of Object.entries(r.features)) {
          if (k === 'home') continue;
          // Feature supported the pick if its sign agreed with the picked side.
          const supported = pickedHome ? v > 0.05 : v < -0.05;
          if (supported) wrongWay[k] = (wrongWay[k] ?? 0) + 1;
        }
      }
      const entries = Object.entries(wrongWay).sort((a, b) => b[1] - a[1]);
      if (entries.length && entries[0][1] >= Math.max(4, losses.length * 0.5)) {
        const [factor, count] = entries[0];
        const label = { elo: 'power rating', winPct: 'season record', form: 'recent form', pitcher: 'starting pitcher', rest: 'rest', streak: 'momentum' }[factor] ?? factor;
        lessons.push({
          category: 'autopsy', title: `Trap factor spotted: ${label} misled ${count} of the last ${losses.length} losses`,
          detail: `When the model lost recently, the ${label} edge pointed at the loser most often. Its influence was reduced so one loud signal can't drown out the rest.`,
          adjustment: { [factor]: state.weights[factor] ?? 0 }, sampleSize: losses.length,
        });
      }
    }
  }

  // ── Persist ──
  const metricsAfter = { winRate: m.winRate, brier: m.brier, graded: m.graded };
  const metricsBefore = {
    winRate: before.graded ? before.wins / before.graded : null,
    brier: before.graded ? before.brierSum / before.graded : null,
    graded: before.graded,
  };
  let toVersion = state.version;
  if (changed || newlyGraded > 0) {
    if (changed) {
      toVersion = bumpVersion(state.version);
      state.version = toVersion;
    }
    await saveModelState(state);
    for (const l of lessons.slice(0, 4)) {
      try {
        await db.insert(adaptiveLessons).values({ sport, category: l.category, title: l.title, detail: l.detail, adjustment: l.adjustment, sampleSize: l.sampleSize });
      } catch { /* lessons are advisory; never fail learning */ }
    }
    if (changed || lessons.length) {
      try {
        await db.insert(adaptiveEvolution).values({
          sport, fromVersion: toVersion === state.version && !changed ? state.version : state.version,
          toVersion, trigger: `${newlyGraded} newly graded game${newlyGraded === 1 ? '' : 's'}`,
          summary: lessons.length ? lessons.map((l) => l.title).join(' · ') : `Routine update on ${newlyGraded} graded games. Weights nudged toward what actually won.`,
          metricsBefore, metricsAfter, weightDelta, gradedInCycle: newlyGraded,
        });
      } catch { /* evolution log is advisory */ }
    }
  }
  return {
    sport, version: state.version, changed, newlyGraded,
    metrics: metricsAfter, lessonsCreated: Math.min(lessons.length, 4),
    summary: lessons.length ? lessons[0].title : newlyGraded ? `Graded ${newlyGraded} games. Record now ${m.wins}-${m.graded - m.wins}${m.winRate !== null ? ` (${Math.round(m.winRate * 100)}%)` : ''}.` : 'No new finals to learn from yet.',
  };
}

/** Full cycle for one or both sports: grade finals, then evolve. */
export async function learningCycle(sport?: Sport) {
  const sports: Sport[] = sport ? [sport] : ['NFL', 'MLB'];
  const { graded } = await gradePending(sport);
  const bySport = new Map<Sport, number>();
  for (const g of graded) bySport.set(g.sport as Sport, (bySport.get(g.sport as Sport) ?? 0) + 1);
  const results = [];
  for (const s of sports) {
    results.push(await evolveModel(s, bySport.get(s) ?? 0));
  }
  return { graded: graded.length, results };
}
