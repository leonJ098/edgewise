'use client';
import { useCallback, useEffect, useState } from 'react';
import { ArrowUpRight, BrainCircuit, CheckCircle2, FlaskConical, GraduationCap, History, Lightbulb, RefreshCw, Scale, Target, TrendingUp, TriangleAlert, Trophy } from 'lucide-react';
import type { LearnData, Sport } from '@/lib/types';
import { Badge, EmptyState } from './ui';
import { FEATURE_LABELS } from '@/lib/learn/model';

export function EvolutionView({ notify }: { notify: (m: string, e?: boolean) => void }) {
  const [data, setData] = useState<LearnData | null>(null);
  const [loading, setLoading] = useState(true);
  const [learning, setLearning] = useState(false);
  const [error, setError] = useState('');
  const [cycleMsg, setCycleMsg] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const r = await fetch('/api/learn');
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setData(d);
    } catch (e) { setError(e instanceof Error ? e.message : 'Learning data unavailable.'); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function runCycle() {
    if (learning) return;
    setLearning(true); setCycleMsg('');
    try {
      const r = await fetch('/api/learn', { method: 'POST' });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setData(d);
      setCycleMsg(d.cycleSummary);
      notify(d.graded ? `Learning cycle graded ${d.graded} games.` : 'Learning cycle complete — no new finals yet.');
    } catch (e) { notify(e instanceof Error ? e.message : 'Learning cycle failed.', true); }
    finally { setLearning(false); }
  }

  if (loading && !data) return <div className="loading-block"><RefreshCw className="spin" size={23} /><p>Loading the learning journal…</p></div>;
  if (error && !data) {
    return <div className="surface"><EmptyState icon={<TriangleAlert size={28} />} heading="Evolution data unavailable." body={error} action={<button className="button secondary" onClick={load}>Try again</button>} /></div>;
  }
  if (!data) return null;
  const totalGraded = data.models.NFL.stats.graded + data.models.MLB.stats.graded;

  return (
    <div className="evo-page">
      <div className="surface evo-hero">
        <span className="evo-hero-icon"><BrainCircuit size={28} /></span>
        <div><Badge tone="green">Always learning</Badge><h2>Every mistake makes the next card smarter.</h2><p>Each pick is frozen before the game, graded against the real final, and fed back into power ratings, weights, calibration and lock thresholds. Nothing is hidden — wins, losses and lessons all live here.</p></div>
        <div className="evo-hero-side"><strong>{totalGraded}</strong><span>games graded<br />& learned from</span><button className="button primary small" onClick={runCycle} disabled={learning}>{learning ? <RefreshCw size={14} className="spin" /> : <GraduationCap size={14} />}{learning ? 'Learning…' : 'Run learning cycle'}</button></div>
      </div>
      {cycleMsg && <div className="learn-banner"><CheckCircle2 size={17} /><p>{cycleMsg}</p></div>}

      <div className="evo-grid-2">
        {(['NFL', 'MLB'] as Sport[]).map((s) => <ModelCard key={s} sport={s} model={data.models[s]} />)}
      </div>

      <div className="section-heading" style={{ marginTop: 30 }}><div><span className="eyebrow">HOW THE MACHINE IMPROVES</span><h2>The learning loop.</h2></div></div>
      <div className="evo-loop">
        {[['01', 'Predict & freeze', 'Every upcoming game gets a probability, tier and reasoning — saved before kickoff.'], ['02', 'Grade the truth', 'Finals are pulled from MLB Stats and ESPN. Wins, losses and pushes, no simulations.'], ['03', 'Update the brain', 'Power ratings move with margin of victory; weights shift toward what actually predicted winners.'], ['04', 'Recalibrate honesty', 'Confidence buckets, lock bars and lessons adjust so 70% really means 70%.']].map(([n, t, b]) => (
          <div key={n} className="evo-step"><span>{n}</span><div><h4>{t}</h4><p>{b}</p></div></div>
        ))}
      </div>

      <div className="evo-grid-2" style={{ marginTop: 26 }}>
        <section className="surface evo-panel">
          <div className="section-heading"><div><span className="eyebrow">MISTAKES → FIXES</span><h3>Lessons learned</h3></div><Lightbulb size={20} /></div>
          {data.lessons.length ? <div className="lesson-list">{data.lessons.map((l) => (
            <article key={l.id}><div className="lesson-top"><Badge tone={l.category === 'autopsy' ? 'amber' : 'neutral'}>{l.sport} · {l.category}</Badge><small>{l.sampleSize} games</small></div><h4>{l.title}</h4><p>{l.detail}</p></article>
          ))}</div> : <EmptyState icon={<Lightbulb size={26} />} heading="The journal is open." body="Lessons appear here once games finish and the model spots patterns in its mistakes — overconfidence, trap factors, threshold misses." action={null} />}
        </section>
        <section className="surface evo-panel">
          <div className="section-heading"><div><span className="eyebrow">VERSION HISTORY</span><h3>Evolution log</h3></div><History size={20} /></div>
          {data.evolution.length ? <div className="evo-timeline">{data.evolution.map((e) => (
            <article key={e.id}><div className="evo-ver"><span>v{e.fromVersion}</span><ArrowUpRight size={12} /><strong>v{e.toVersion}</strong><Badge tone="neutral">{e.sport}</Badge></div><p>{e.summary}</p><small>{e.trigger} · {new Date(e.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</small></article>
          ))}</div> : <EmptyState icon={<History size={26} />} heading="Version 3.0.0 — the starting brain." body="Every weight change, threshold move and calibration update will be logged here with before/after metrics." action={null} />}
        </section>
      </div>

      <div className="evo-grid-2" style={{ marginTop: 26 }}>
        <section className="surface evo-panel">
          <div className="section-heading"><div><span className="eyebrow">LIVE POWER RATINGS</span><h3>Who the model fears</h3></div><Trophy size={20} /></div>
          {(['NFL', 'MLB'] as Sport[]).map((s) => (
            <div key={s} className="rating-block"><h5>{s}</h5>{data.ratings.filter((r) => r.sport === s).map((r, i) => (
              <div key={r.teamId} className="rating-row"><span className="rating-pos">{i + 1}</span><span className="rating-name">{r.teamName}</span><span className="rating-streak">{r.streak > 1 ? `W${r.streak}` : r.streak < -1 ? `L${Math.abs(r.streak)}` : ''}</span><strong>{r.rating}</strong></div>
            ))}{!data.ratings.some((r) => r.sport === s) && <p className="muted">Ratings seed at 1500 and move with every graded game.</p>}</div>
          ))}
        </section>
        <section className="surface evo-panel">
          <div className="section-heading"><div><span className="eyebrow">TRACK RECORD</span><h3>Recent picks</h3></div><Target size={20} /></div>
          {data.recent.length ? <div className="recent-list">{data.recent.map((r) => (
            <div key={r.gameId} className="recent-row"><Badge tone={r.status === 'win' ? 'green' : r.status === 'loss' ? 'red' : 'neutral'}>{r.status === 'pending' ? '…' : r.status === 'win' ? 'W' : r.status === 'loss' ? 'L' : 'P'}</Badge><div><strong>{r.pick}</strong><small>{r.sport} · {r.date} · {Math.round(r.confidence * 100)}% · {r.tier}</small></div><span className="recent-score">{r.score}</span></div>
          ))}</div> : <p className="muted">No picks recorded yet — visit Locks to generate the first card.</p>}
        </section>
      </div>
      <div className="review-principles"><FlaskConical size={19} /><p><strong>Honest by construction.</strong> The model only knows public schedules, records, ratings and pitcher stats. It shows its work, grades itself against real finals, and gets recalibrated — never hand-tuned to look good.</p></div>
    </div>
  );
}

function ModelCard({ sport, model }: { sport: Sport; model: LearnData['models']['NFL'] }) {
  const wr = model.stats.winRate !== null ? `${Math.round(model.stats.winRate * 100)}%` : '—';
  return (
    <section className="surface evo-panel">
      <div className="section-heading"><div><span className="eyebrow">{sport} ADAPTIVE MODEL</span><h3>Version {model.version}</h3></div><TrendingUp size={20} /></div>
      <div className="evo-stats">
        <div><span>Record</span><strong>{model.stats.wins}-{model.stats.losses}{model.stats.pushes ? `-${model.stats.pushes}` : ''}</strong></div>
        <div><span>Win rate</span><strong>{wr}</strong></div>
        <div><span>Brier ↓</span><strong>{model.stats.brier ?? '—'}</strong></div>
        <div><span>Lock bar</span><strong>{Math.round(model.thresholds.lock * 100)}%</strong></div>
      </div>
      <h5 className="evo-sub">Factor weights <small>current vs starting</small></h5>
      <div className="weight-list">
        {Object.entries(model.weights).filter(([k]) => k !== 'intercept').map(([k, v]) => {
          const dflt = model.defaultWeights[k] ?? 0;
          const delta = v - dflt;
          return (
            <div key={k} className="weight-row-live"><span className="weight-name">{FEATURE_LABELS[k] ?? k}</span>
              <span className="weight-bar"><i style={{ width: `${Math.min(100, Math.abs(v) / 3 * 100)}%` }} /></span>
              <strong>{v.toFixed(2)}</strong>
              <small className={delta > 0.005 ? 'up' : delta < -0.005 ? 'down' : ''}>{Math.abs(delta) < 0.005 ? '—' : `${delta > 0 ? '+' : ''}${delta.toFixed(2)}`}</small>
            </div>
          );
        })}
      </div>
      {!!model.calibration.length && (
        <><h5 className="evo-sub">Calibration <small>predicted vs actual win rate</small></h5>
        <div className="cal-list">{model.calibration.map((c) => (
          <div key={c.bucket} className="cal-row" title={`${c.count} graded picks`}><span>{c.bucket}%</span>
            <span className="cal-bars"><i className="pred" style={{ width: `${c.predicted * 100}%` }} /><i className="obs" style={{ width: `${c.observed * 100}%` }} /></span>
            <small>{Math.round(c.observed * 100)}% ({c.count})</small></div>
        ))}</div></>
      )}
      <p className="fine-print"><Scale size={12} /> Updated {new Date(model.updatedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })} · Lower Brier is better · Weights bounded to prevent overreaction.</p>
    </section>
  );
}
