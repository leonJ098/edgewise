'use client';
import { useEffect,useId,useRef,useState,type ReactNode } from 'react';
import { X,Bookmark,ArrowUpRight,Clock3,Check,ShieldCheck } from 'lucide-react';
import type { AnalyzedGame,Sport,Team,TeamInjuryReport } from '@/lib/types';

export function SportIcon({sport,size=19}:{sport:Sport;size?:number}) {return sport==='MLB'?<svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M5 5c8 5 8 9 0 14M19 5c-8 5-8 9 0 14M6 7l2-1m0 4 2-1m0 6-2-1m-2 4 2-1m10-10-2-1m0 4-2-1m0 6 2-1m2 4-2-1"/></svg>:<svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true"><path d="M4 20C-1 8 8-1 20 4c5 12-4 21-16 16Z"/><path d="m7 17 10-10M9 11l4 4m-1-7 4 4M3 13l8 8M13 3l8 8"/></svg>;}
export function BrandMark(){return <span className="brand-mark"><svg viewBox="0 0 28 28" fill="none" aria-hidden="true"><path d="m7 7 14 0-4.5 5.5H7V7Zm0 8.5h8L10.5 21H7v-5.5Z" fill="currentColor"/><path d="m17 15.5 4 0-4.5 5.5h-4l4.5-5.5Z" fill="currentColor" opacity=".5"/></svg></span>;}
export function TeamMark({team,size='normal'}:{team:Team;size?:'normal'|'large'|'small'}){const [failed,setFailed]=useState(false);return <span className={`team-mark ${size}`} style={{'--team-color':team.color.startsWith('#')?team.color:`#${team.color}`} as React.CSSProperties}>{!failed&&team.logo?<img src={team.logo} alt={`${team.name} logo`} onError={()=>setFailed(true)} loading="lazy"/>:<b>{team.abbreviation}</b>}</span>;}
export function Badge({children,tone='neutral'}:{children:ReactNode;tone?:'green'|'amber'|'red'|'neutral'}){return <span className={`badge ${tone}`}>{children}</span>;}
export const percent=(n:number|null,digits=0)=>n===null?'—':`${(n*100).toFixed(digits)}%`;
export const signed=(n:number|null)=>n===null?'—':n>0?`+${n}`:String(n);
export function gameTime(date:string){return new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',hour:'numeric',minute:'2-digit'}).format(new Date(date));}
export function shortDate(date:string){return new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',month:'short',day:'numeric'}).format(new Date(date.length===10?date+'T12:00:00Z':date));}
export function Panel({title,eyebrow,children,onClose,wide=false}:{title:string;eyebrow?:string;children:ReactNode;onClose:()=>void;wide?:boolean}){
  const id=useId(),ref=useRef<HTMLElement>(null),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{const before=document.activeElement as HTMLElement|null;const overflow=document.body.style.overflow;document.body.style.overflow='hidden';ref.current?.querySelector<HTMLButtonElement>('button')?.focus();
    const handler=(e:KeyboardEvent)=>{if(e.key==='Escape')close.current();if(e.key==='Tab'){const all=Array.from(ref.current?.querySelectorAll<HTMLElement>('a[href],button:not(:disabled),input:not(:disabled),select,textarea,[tabindex="0"]')??[]).filter(n=>n.offsetParent!==null);const first=all[0],last=all[all.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}};document.addEventListener('keydown',handler);return()=>{document.removeEventListener('keydown',handler);document.body.style.overflow=overflow;before?.focus();};},[]);
  return <div className="panel-overlay" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section ref={ref} role="dialog" aria-modal="true" aria-labelledby={id} className={`side-panel ${wide?'wide':''}`}><header className="panel-header"><div>{eyebrow&&<span className="eyebrow">{eyebrow}</span>}<h2 id={id}>{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close panel"><X size={20}/></button></header>{children}</section></div>;
}
export function EmptyState({icon,heading,body,action}:{icon:ReactNode;heading:string;body:string;action?:ReactNode}){return <div className="empty-state"><span className="empty-symbol">{icon}</span><h3>{heading}</h3><p>{body}</p>{action}</div>;}
export function GameCard({game,saved,onSave,onOpen,note,onNote,busy=false}:{game:AnalyzedGame;saved:boolean;onSave:()=>void;onOpen:()=>void;note?:string;onNote?:(value:string)=>Promise<void>;busy?:boolean}){
  const a=game.analysis,official=a.decision==='OFFICIAL';const [draft,setDraft]=useState(note??''),[saving,setSaving]=useState(false);
  useEffect(()=>setDraft(note??''),[note]);
  const day=new Intl.DateTimeFormat('en-US',{weekday:'short',timeZone:'America/New_York'}).format(new Date(game.startsAt));
  return <article className={`game-card ${official?'official-game':''}`}>
    <div className="game-card-top"><div className="league-mark"><SportIcon sport={game.sport}/><strong>{game.sport}</strong><span className="dot-separator">·</span><span>{game.sport==='NFL'?`Week ${game.week??'TBD'}`:game.competition.includes('Division')?'Division series':game.competition.includes('Wild')?'Wild card':'Baseball'}</span></div><button className={`icon-button bookmark-button ${saved?'is-saved':''}`} onClick={onSave} disabled={busy} aria-label={saved?`Remove ${game.away.shortName} at ${game.home.shortName} from watchlist`:`Save ${game.away.shortName} at ${game.home.shortName} to watchlist`} aria-pressed={saved}><Bookmark size={17} fill={saved?'currentColor':'none'}/></button></div>
    <div className="game-date"><Clock3 size={12}/>{day}, {shortDate(game.startsAt)} <span>·</span> {game.timeTbd?'Time TBD':`${gameTime(game.startsAt)} ET`}{game.doubleheader&&<span> · Game {game.gameNumber}</span>}</div>
    <button className="matchup-button" onClick={onOpen} aria-label={`View ${game.away.name} at ${game.home.name} analysis`}>
      <div className="matchup-team"><TeamMark team={game.away}/><div><span>{game.away.name.replace(game.away.shortName,'').trim()||'Away'}</span><strong>{game.away.shortName}</strong></div></div>
      <span className="at-sign">@</span>
      <div className="matchup-team"><TeamMark team={game.home}/><div><span>{game.home.name.replace(game.home.shortName,'').trim()||'Home'}</span><strong>{game.home.shortName}</strong></div></div>
    </button>
    <div className="starter-line">{a.checks.some(c=>c.key==='starters'&&c.status==='verified')?'Starting personnel source-verified':game.sport==='MLB'?`${game.away.starter?.name?.split(' ').slice(-1)[0]??'TBD'} vs. ${game.home.starter?.name?.split(' ').slice(-1)[0]??'TBD'} · Probable starters`:`${game.neutralSite?'Neutral site · ':''}${game.spread?`${game.spread}${game.overUnder?` · O/U ${game.overUnder}`:''}`:'Starting QBs awaiting confirmation'}`}</div>
    {(game.homeInjuries||game.awayInjuries)&&<div className="injury-strip">{injuryChip(game.away.shortName,game.awayInjuries)}{injuryChip(game.home.shortName,game.homeInjuries)}</div>}
    <div className="game-status-line"><Badge tone={official?'green':game.status!=='scheduled'?'neutral':'amber'}>{official?<ShieldCheck size={12}/>:<span className="status-dot"/>}{official?'Official pick':game.status!=='scheduled'?game.status==='final'?'Final — no new pick':game.status==='live'?'In progress — no new pick':'Postponed':a.decision==='PASS'?'Pass':'Awaiting verification'}</Badge><span className="market-caption">{a.market==='moneyline'?'MONEYLINE':'PLAYER PROP'}</span></div>
    {official?<div className="official-selection"><strong>{a.selection}</strong><span>{percent(a.probability)} <small>model est.</small></span></div>:<div className="readiness-row"><div><span>Safety checks</span><strong>{a.verifiedCount}<span> / {a.requiredCount}</span></strong></div><div className="segmented-progress" aria-label={`${a.verifiedCount} of ${a.requiredCount} checks verified`}>{Array.from({length:a.requiredCount},(_,i)=><i key={i} className={i<a.verifiedCount?'complete':''}/>)}</div></div>}
    <div className="game-card-bottom"><span className="muted"><span className="live-tiny"/> {game.sport==='MLB'?'MLB Stats':'ESPN'} schedule</span><button className="text-button" onClick={onOpen}>View analysis <ArrowUpRight size={15}/></button></div>
    {onNote&&<div className="card-note"><label htmlFor={`note-${game.id}`}>Your research note</label><textarea id={`note-${game.id}`} value={draft} maxLength={2000} onChange={e=>setDraft(e.target.value)} placeholder="What are you waiting to verify?" rows={2}/><button className="text-button" disabled={saving||draft===note} onClick={async()=>{setSaving(true);try{await onNote(draft);}finally{setSaving(false);}}}><Check size={13}/>{saving?'Saving…':'Save note'}</button></div>}
    </article>;
}
function injuryChip(label:string, report?: TeamInjuryReport) {
  if (!report) return null;
  const hot = report.players.filter((p) => ['out', 'ir', 'il', 'doubtful'].includes(p.statusKey)).length;
  const q = report.players.filter((p) => p.statusKey === 'questionable' || p.statusKey === 'dtd').length;
  if (!hot && !q) return null;
  return <span className={`injury-chip ${hot ? 'hot' : 'warm'}`}>{label}: {hot ? `${hot} out/IR` : ''}{hot && q ? ' · ' : ''}{q ? `${q} Q` : ''}</span>;
}
