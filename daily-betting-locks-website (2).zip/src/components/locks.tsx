'use client';
import { useState } from 'react';
import { ArrowUpRight, BrainCircuit, CheckCircle2, ChevronDown, Clock3, Flame, RefreshCw, ShieldCheck, Sparkles, Target, TriangleAlert, Trophy } from 'lucide-react';
import type { LocksData, ModelPick, Sport } from '@/lib/types';
import { Badge, EmptyState, SportIcon, gameTime, shortDate } from './ui';

const TIER_TONE: Record<string, 'green' | 'amber' | 'red' | 'neutral'> = { LOCK: 'green', STRONG: 'green', LEAN: 'amber', PASS: 'neutral' };
const TIER_ICON: Record<string, string> = { LOCK: 'Model lock', STRONG: 'Strong lean', LEAN: 'Lean', PASS: 'Pass' };

export function LocksView({ data, loading, error, onRetry }: {
  data: LocksData | null; loading: boolean; error: string; onRetry: () => void;
}) {
  const [sport, setSport] = useState<'ALL' | Sport>('ALL');
  const [expanded, setExpanded] = useState<string | null>(null);
  if (loading && !data) {
    return <div className="loading-block"><RefreshCw className="spin" size={23} /><p>Scoring every upcoming matchup…</p></div>;
  }
  if (error && !data) {
    return <div className="surface"><EmptyState icon={<TriangleAlert size={28} />} heading="Locks could not load." body={error} action={<button className="button secondary" onClick={onRetry}>Try again</button>} /></div>;
  }
  if (!data) return null;
  const picks = data.all.filter((p) => sport === 'ALL' || p.sport === sport);
  const locks = data.locks.filter((p) => sport === 'ALL' || p.sport === sport);
  const lockCount = locks.filter((l) => l.tier === 'LOCK').length;

  return (
    <div className="locks-page">
      {data.learning.newlyGraded > 0 && (
        <div className="learn-banner"><BrainCircuit size={18} /><p><strong>Self-update complete.</strong> {data.learning.newlyGraded} finished game{data.learning.newlyGraded === 1 ? '' : 's'} graded{data.learning.lessonsCreated > 0 ? `, ${data.learning.lessonsCreated} new lesson${data.learning.lessonsCreated === 1 ? '' : 's'} learned` : ''}. {data.learning.summary}</p></div>
      )}
      <div className="metrics-grid locks-metrics">
        <PerfCard sport="NFL" perf={data.performance.NFL} version={data.modelVersions.NFL} />
        <PerfCard sport="MLB" perf={data.performance.MLB} version={data.modelVersions.MLB} />
        <div className="metric-card green"><div className="metric-label">Top locks today<span className="metric-icon green"><Trophy size={17} /></span></div><strong>{String(locks.length).padStart(2, '0')}</strong><span>{lockCount ? `${lockCount} clear the lock bar` : 'Best available — bar not cleared'}</span></div>
        <div className="metric-card"><div className="metric-label">Games scored<span className="metric-icon neutral"><Target size={17} /></span></div><strong>{String(picks.length).padStart(2, '0')}</strong><span>Across the selected window</span></div>
      </div>

      <div className="section-heading locks-heading">
        <div><h2>{lockCount ? "Today's locks." : 'Best available plays.'}</h2><p>{lockCount ? 'Highest-confidence model picks, ranked by calibrated probability.' : 'No pick clears the lock bar today — these are the strongest available, labeled honestly.'}</p></div>
        <div className="sport-tabs" role="tablist" aria-label="Filter locks by sport">
          {(['ALL', 'NFL', 'MLB'] as const).map((s) => (
            <button key={s} role="tab" aria-selected={sport === s} className={sport === s ? 'active' : ''} onClick={() => setSport(s)}>
              {s !== 'ALL' && <SportIcon sport={s} size={14} />}<span>{s === 'ALL' ? 'All' : s}</span>
            </button>
          ))}
        </div>
      </div>

      {locks.length ? (
        <div className="locks-grid">{locks.map((pick, i) => <LockCard key={pick.gameId} pick={pick} rank={i + 1} expanded={expanded === pick.gameId} onToggle={() => setExpanded(expanded === pick.gameId ? null : pick.gameId)} />)}</div>
      ) : (
        <div className="surface"><EmptyState icon={<ShieldCheck size={30} />} heading="No upcoming games in this view." body="Try another sport or widen the date window. Picks appear as soon as schedules publish." action={null} /></div>
      )}

      <div className="section-heading" style={{ marginTop: 34 }}><div><h2>Every upcoming game, scored.</h2><p>Full slate ranked by model confidence. Tap any row for the reasoning.</p></div></div>
      <div className="surface pick-list">
        {picks.map((pick) => (
          <div key={pick.gameId} className="pick-row-wrap">
            <button className={`pick-row ${expanded === pick.gameId ? 'open' : ''}`} onClick={() => setExpanded(expanded === pick.gameId ? null : pick.gameId)} aria-expanded={expanded === pick.gameId}>
              <span className="pick-sport"><SportIcon sport={pick.sport} size={15} /></span>
              <span className="pick-match"><strong>{pick.awayAbbr} @ {pick.homeAbbr}</strong><small>{shortDate(pick.startsAt)}, {gameTime(pick.startsAt)} ET</small></span>
              <span className="pick-side"><strong>{pick.predictedSide === 'home' ? pick.homeAbbr : pick.awayAbbr}</strong><small>{Math.round(pick.confidence * 100)}%</small></span>
              <span className="pick-bar"><i style={{ width: `${Math.round(pick.confidence * 100)}%` }} className={pick.tier === 'LOCK' ? 'lock' : pick.tier === 'PASS' ? 'pass' : ''} /></span>
              <Badge tone={TIER_TONE[pick.tier]}>{pick.tier}</Badge>
              <ChevronDown size={15} className={expanded === pick.gameId ? 'flipped' : ''} />
            </button>
            {expanded === pick.gameId && <PickDetail pick={pick} />}
          </div>
        ))}
        {!picks.length && <p className="pick-empty">No games match this filter.</p>}
      </div>
      <div className="radar-note"><Sparkles size={14} /><span>Estimates use live ESPN injury reports (Out / IR / IL / Doubtful / Questionable), schedules, records, power ratings and pitcher data. A missing QB is never treated as healthy.</span></div>
    </div>
  );
}

function PerfCard({ sport, perf, version }: { sport: Sport; perf: LocksData['performance']['NFL']; version: string }) {
  const rate = perf.winRate !== null ? `${Math.round(perf.winRate * 100)}%` : '—';
  return (
    <div className="metric-card">
      <div className="metric-label">{sport} model v{version}<span className="metric-icon neutral"><SportIcon sport={sport} size={16} /></span></div>
      <strong>{perf.graded ? `${perf.wins}-${perf.losses}` : '0-0'}</strong>
      <span>{perf.graded ? `${rate} · ${perf.graded} graded` : 'Awaiting first graded games'}{perf.streak !== 0 ? ` · ${perf.streak > 0 ? `W${perf.streak}` : `L${Math.abs(perf.streak)}`} streak` : ''}</span>
    </div>
  );
}

function LockCard({ pick, rank, expanded, onToggle }: { pick: ModelPick; rank: number; expanded: boolean; onToggle: () => void }) {
  const pct = Math.round(pick.confidence * 100);
  return (
    <article className={`lock-card tier-${pick.tier.toLowerCase()}`}>
      <div className="lock-rank"><span>0{rank}</span><Badge tone={TIER_TONE[pick.tier]}>{pick.tier === 'LOCK' ? <Flame size={11} /> : pick.tier === 'PASS' ? <Clock3 size={11} /> : <CheckCircle2 size={11} />}{TIER_ICON[pick.tier]}</Badge></div>
      <div className="lock-league"><SportIcon sport={pick.sport} size={14} /><strong>{pick.sport}</strong><span>·</span><span>{shortDate(pick.startsAt)}, {gameTime(pick.startsAt)} ET</span></div>
      <h3>{pick.awayName} <span className="lock-at">at</span> {pick.homeName}</h3>
      <div className="lock-pick"><span>The model pick</span><strong>{pick.pickName}</strong></div>
      {pick.injuries && (pick.injuries.home.length > 0 || pick.injuries.away.length > 0) && (
        <div className="lock-injuries">
          <span>Live injury report</span>
          <strong>{pick.injuries.away.filter((p) => ['out', 'ir', 'il', 'doubtful'].includes(p.statusKey)).length} away · {pick.injuries.home.filter((p) => ['out', 'ir', 'il', 'doubtful'].includes(p.statusKey)).length} home out/IR</strong>
        </div>
      )}
      <div className="lock-confidence"><div><span>Model confidence</span><strong>{pct}%</strong></div><div className="lock-bar"><i style={{ width: `${pct}%` }} /></div></div>
      <div className="lock-meta"><span>Fair odds {pick.fairOdds !== null && pick.fairOdds !== undefined ? (pick.fairOdds > 0 ? `+${pick.fairOdds}` : pick.fairOdds) : '—'}</span><span>{pick.spread ? pick.spread : `v${pick.modelVersion}`}</span></div>
      <button className="text-button lock-toggle" onClick={onToggle} aria-expanded={expanded}>Why this pick? <ChevronDown size={14} className={expanded ? 'flipped' : ''} /></button>
      {expanded && <PickDetail pick={pick} bare />}
    </article>
  );
}

function PickDetail({ pick, bare = false }: { pick: ModelPick; bare?: boolean }) {
  const inj = pick.injuries;
  return (
    <div className={bare ? 'pick-detail bare' : 'pick-detail'}>
      <ul>{pick.reasoning.map((r, i) => <li key={i}>{r}</li>)}</ul>
      {!!pick.warnings.length && <div className="pick-warnings">{pick.warnings.map((w, i) => <p key={i}><TriangleAlert size={12} />{w}</p>)}</div>}
      {inj && (inj.home.length > 0 || inj.away.length > 0) && (
        <div className="injury-detail">
          <h5>Current ESPN injury report {inj.fetchedAt ? `· ${new Date(inj.fetchedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: 'America/New_York' })} ET` : ''}</h5>
          {([['Away', inj.away], ['Home', inj.home]] as const).map(([label, list]) => list.length ? (
            <div key={label} className="injury-team">
              <strong>{label} · {label === 'Away' ? pick.awayAbbr : pick.homeAbbr}</strong>
              <ul>{list.slice(0, 8).map((p) => <li key={`${p.player}-${p.status}`}><span className={`inj-status ${p.statusKey}`}>{p.status}</span>{p.player} <small>{p.position}{p.bodyPart ? ` · ${p.bodyPart}` : ''}</small>{p.comment ? <em>{p.comment}</em> : null}</li>)}</ul>
            </div>
          ) : null)}
          {inj.sourceUrl && <a className="source-link" href={inj.sourceUrl} target="_blank" rel="noreferrer">Open full injury report <ArrowUpRight size={11} /></a>}
        </div>
      )}
      {(pick.spread || pick.overUnder || pick.broadcast) && <p className="fine-print">{[pick.spread, pick.overUnder ? `O/U ${pick.overUnder}` : null, pick.broadcast].filter(Boolean).join(' · ')}</p>}
      <div className="pick-factors">
        {Object.entries(pick.features).filter(([k]) => k !== 'intercept').map(([k, v]) => (
          <span key={k} title={`${k}: ${v > 0 ? '+' : ''}${v}`}><small>{k}</small><strong className={v > 0.05 ? 'pos' : v < -0.05 ? 'neg' : ''}>{v > 0 ? '+' : ''}{v}</strong></span>
        ))}
      </div>
      <a className="source-link" href={pick.sport === 'MLB' ? 'https://www.mlb.com/scores' : 'https://www.espn.com/nfl/schedule'} target="_blank" rel="noreferrer">Schedule source <ArrowUpRight size={11} /></a>
    </div>
  );
}
