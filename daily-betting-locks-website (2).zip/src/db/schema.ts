import { pgTable, serial, varchar, integer, timestamp, text, boolean, uuid, jsonb, uniqueIndex, doublePrecision } from 'drizzle-orm/pg-core';
import type { Game, Assessment, SourceStatus } from '@/lib/types';

export const dataCache = pgTable('safety_data_cache', {
  key: text('key').primaryKey(),
  payload: jsonb('payload').notNull(),
  fetchedAt: timestamp('fetched_at', { withTimezone: true }).defaultNow().notNull(),
});
export const workspaces = pgTable('safety_workspaces', {
  id: uuid('id').primaryKey().defaultRandom(),
  displayName: varchar('display_name', { length: 60 }).default('My workspace').notNull(),
  maxPicks: integer('max_picks').default(3).notNull(),
  defaultSport: varchar('default_sport', { length: 6 }).default('ALL').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});
export const watchlist = pgTable('safety_watchlist', {
  id: uuid('id').primaryKey().defaultRandom(),
  workspaceId: uuid('workspace_id').references(() => workspaces.id, { onDelete: 'cascade' }).notNull(),
  gameId: text('game_id').notNull(),
  game: jsonb('game').$type<Game>().notNull(),
  note: text('note').default('').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex('watchlist_workspace_game').on(table.workspaceId, table.gameId)]);
export const analysisRuns = pgTable('safety_analysis_runs', {
  id: uuid('id').primaryKey().defaultRandom(),
  workspaceId: uuid('workspace_id').references(() => workspaces.id, { onDelete: 'cascade' }).notNull(),
  gamesChecked: integer('games_checked').notNull(),
  officialCount: integer('official_count').notNull(),
  algorithmVersion: text('algorithm_version').notNull(),
  sources: jsonb('sources').$type<SourceStatus[]>().notNull(),
  decisions: jsonb('decisions').$type<Assessment[]>().notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});
export const officialSelections = pgTable('safety_official_selections', {
  id: uuid('id').primaryKey().defaultRandom(),
  workspaceId: uuid('workspace_id').references(() => workspaces.id, { onDelete: 'cascade' }).notNull(),
  selectionKey: text('selection_key').notNull(),
  game: jsonb('game').$type<Game>().notNull(),
  analysis: jsonb('analysis').$type<Assessment>().notNull(),
  publishedAt: timestamp('published_at', { withTimezone: true }).defaultNow().notNull(),
  grade: varchar('grade', { length: 16 }).default('pending').notNull(),
  actual: doublePrecision('actual'),
  resultSource: text('result_source'),
  gradedAt: timestamp('graded_at', { withTimezone: true }),
  review: text('review'),
}, (table) => [uniqueIndex('official_workspace_selection').on(table.workspaceId, table.selectionKey)]);

// ─── Adaptive learning engine: model remembers every pick, result & lesson ───
export const adaptiveModelState = pgTable('adaptive_model_state', {
  sport: varchar('sport', { length: 6 }).primaryKey(),
  version: text('version').notNull(),
  weights: jsonb('weights').$type<Record<string, number>>().notNull(),
  calibration: jsonb('calibration').$type<Record<string, { predicted: number; observed: number; count: number }>>().notNull(),
  stats: jsonb('stats').$type<{ graded: number; wins: number; losses: number; pushes: number; brierSum: number; logLossSum: number; lastGradedAt: string | null }>().notNull(),
  thresholds: jsonb('thresholds').$type<{ lock: number; strong: number; lean: number }>().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});
export const adaptiveTeamRatings = pgTable('adaptive_team_ratings', {
  id: text('id').primaryKey(),
  sport: varchar('sport', { length: 6 }).notNull(),
  teamId: text('team_id').notNull(),
  teamName: text('team_name').notNull(),
  rating: doublePrecision('rating').default(1500).notNull(),
  games: integer('games').default(0).notNull(),
  wins: integer('wins').default(0).notNull(),
  losses: integer('losses').default(0).notNull(),
  streak: integer('streak').default(0).notNull(),
  recentForm: jsonb('recent_form').$type<string[]>().default([]).notNull(),
  lastGameDate: text('last_game_date'),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});
export const adaptivePredictions = pgTable('adaptive_predictions', {
  id: uuid('id').primaryKey().defaultRandom(),
  gameId: text('game_id').notNull(),
  sport: varchar('sport', { length: 6 }).notNull(),
  homeId: text('home_id').notNull(),
  awayId: text('away_id').notNull(),
  homeName: text('home_name').notNull(),
  awayName: text('away_name').notNull(),
  date: text('date').notNull(),
  startsAt: timestamp('starts_at', { withTimezone: true }).notNull(),
  predictedSide: varchar('predicted_side', { length: 6 }).notNull(),
  homeProb: doublePrecision('home_prob').notNull(),
  confidence: doublePrecision('confidence').notNull(),
  tier: varchar('tier', { length: 16 }).notNull(),
  edge: doublePrecision('edge').notNull(),
  features: jsonb('features').$type<Record<string, number>>().notNull(),
  reasoning: jsonb('reasoning').$type<string[]>().notNull(),
  modelVersion: text('model_version').notNull(),
  status: varchar('status', { length: 12 }).default('pending').notNull(),
  homeScore: integer('home_score'),
  awayScore: integer('away_score'),
  resultSource: text('result_source'),
  gradedAt: timestamp('graded_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex('adaptive_predictions_game').on(table.gameId)]);
export const adaptiveLessons = pgTable('adaptive_lessons', {
  id: uuid('id').primaryKey().defaultRandom(),
  sport: varchar('sport', { length: 6 }).notNull(),
  category: varchar('category', { length: 40 }).notNull(),
  title: text('title').notNull(),
  detail: text('detail').notNull(),
  adjustment: jsonb('adjustment').$type<Record<string, number>>().notNull(),
  sampleSize: integer('sample_size').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});
export const adaptiveEvolution = pgTable('adaptive_evolution', {
  id: uuid('id').primaryKey().defaultRandom(),
  sport: varchar('sport', { length: 6 }).notNull(),
  fromVersion: text('from_version').notNull(),
  toVersion: text('to_version').notNull(),
  trigger: text('trigger').notNull(),
  summary: text('summary').notNull(),
  metricsBefore: jsonb('metrics_before').$type<Record<string, number | null>>().notNull(),
  metricsAfter: jsonb('metrics_after').$type<Record<string, number | null>>().notNull(),
  weightDelta: jsonb('weight_delta').$type<Record<string, number>>().notNull(),
  gradedInCycle: integer('graded_in_cycle').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});


export const games = pgTable('games', {
  id: serial('id').primaryKey(),
  sport: varchar('sport', { length: 50 }).notNull(), // e.g. 'NFL', 'NBA', 'SOCCER', 'UFC'
  homeTeam: varchar('home_team', { length: 100 }).notNull(),
  awayTeam: varchar('away_team', { length: 100 }).notNull(),
  homeLogo: varchar('home_logo', { length: 255 }),
  awayLogo: varchar('away_logo', { length: 255 }),
  gameDate: timestamp('game_date').defaultNow().notNull(),
  spread: varchar('spread', { length: 20 }), // e.g. "-7.5"
  overUnder: varchar('over_under', { length: 20 }), // e.g. "47.5"
  homeMoneyline: varchar('home_moneyline', { length: 20 }), // e.g. "-310"
  awayMoneyline: varchar('away_moneyline', { length: 20 }), // e.g. "+250"
  
  // Pick Recommendation
  recommendedPick: varchar('recommended_pick', { length: 100 }).notNull(), // e.g. "Chiefs -7.5" or "Over 47.5"
  pickType: varchar('pick_type', { length: 50 }).notNull(), // 'SPREAD' | 'MONEYLINE' | 'TOTAL'
  lockTier: varchar('lock_tier', { length: 50 }).notNull(), // 'DIAMOND' | 'GOLD' | 'STREET_LOCK' | 'TRAP'
  confidenceScore: integer('confidence_score').default(85).notNull(), // e.g. 94 (94%)
  analysis: text('analysis').notNull(), // Reason why it's a lock!
  
  // Status and Results
  status: varchar('status', { length: 20 }).default('scheduled').notNull(), // 'scheduled' | 'live' | 'completed'
  homeScore: integer('home_score').default(0).notNull(),
  awayScore: integer('away_score').default(0).notNull(),
  winner: varchar('winner', { length: 100 }), // team name or 'TIE'
  pickStatus: varchar('pick_status', { length: 20 }).default('pending').notNull(), // 'pending' | 'win' | 'loss' | 'push'
  
  // Matchup parameters to let the user simulate
  simulated: boolean('simulated').default(false).notNull(),
});

export const bets = pgTable('bets', {
  id: serial('id').primaryKey(),
  username: varchar('username', { length: 100 }).notNull(),
  gameId: integer('game_id').references(() => games.id, { onDelete: 'cascade' }).notNull(),
  betType: varchar('bet_type', { length: 50 }).notNull(), // 'SPREAD' | 'MONEYLINE' | 'TOTAL'
  betSelection: varchar('bet_selection', { length: 100 }).notNull(), // e.g. "Chiefs -7.5"
  odds: varchar('odds', { length: 20 }).notNull(), // e.g. "-110"
  amount: integer('amount').notNull(), // amount in LockBucks
  potentialPayout: integer('potential_payout').notNull(),
  status: varchar('status', { length: 20 }).default('pending').notNull(), // 'pending' | 'win' | 'loss'
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const votes = pgTable('votes', {
  id: serial('id').primaryKey(),
  gameId: integer('game_id').references(() => games.id, { onDelete: 'cascade' }).notNull(),
  voteType: varchar('vote_type', { length: 20 }).notNull(), // 'agree' | 'disagree'
  username: varchar('username', { length: 100 }).notNull(),
});

export const comments = pgTable('comments', {
  id: serial('id').primaryKey(),
  gameId: integer('game_id').references(() => games.id, { onDelete: 'cascade' }).notNull(),
  username: varchar('username', { length: 100 }).notNull(),
  avatar: varchar('avatar', { length: 100 }).notNull(), // Emoji or profile pic code
  comment: text('comment').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const userProfiles = pgTable('user_profiles', {
  username: varchar('username', { length: 100 }).primaryKey(),
  balance: integer('balance').default(10000).notNull(), // Starts with $10,000 LockBucks
  streak: integer('streak').default(0).notNull(), // Current active winning streak
  maxStreak: integer('max_streak').default(0).notNull(),
  wins: integer('wins').default(0).notNull(),
  losses: integer('losses').default(0).notNull(),
  netEarnings: integer('net_earnings').default(0).notNull(),
});
