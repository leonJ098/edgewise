# Edgewise — The Disciplined Edge

A Next.js App Router / PostgreSQL / Drizzle research application implementing conservative NFL moneyline and MLB selection policies. This replaces the previous mock-betting simulator. Legacy tables are retained but not read by the new application; the random outcomes and seed endpoints have been removed.

## Product

- Real upcoming NFL and MLB schedules with source timestamps and exact week/date metadata.
- Daily evidence gates, a separate official-pick card, and a legitimate no-pick state.
- Source-aware weighted matchup scores, independent risk-adjusted forecasts, conservative price checks and correlation limits.
- Exact Underdog-only prop matching; no bookmaker substitution or invented per-leg DFS break-even odds.
- Immutable official forecasts, verified score/statistic grading, post-game cause reviews and CSV export.
- Anonymous browser-scoped PostgreSQL workspaces, persistent watchlists and research notes.
- Clearly labeled research-only NFL score/price and MLB workload-mixture strikeout calculators.
- Responsive light workspace / forest-green navigation with local fonts and image assets.

## Data and configuration

Schedules need no API key. Current two-sided moneyline quotes and Underdog props use `ODDS_API_KEY` for The Odds API. A separate authorized advanced-data pipeline uses `ANALYTICS_FEED_URL` and optional `ANALYTICS_FEED_TOKEN`. Missing credentials or incomplete evidence are visible in Data sources and prevent official picks. The app does not ship with licensed advanced metrics or claim an independently validated forecasting model.

See [the complete data contract](public/data-guide.md) and the runtime Zod schemas in `src/lib/safety/validation.ts`. Secrets stay server-side. Strict thresholds are policy choices, not evidence of guaranteed returns. Estimates from the calculators never enter the official card.

## Database

Use the existing `DATABASE_URL`. New tables are prefixed `safety_`. After the environment has been bootstrapped, apply the schema with `npx drizzle-kit push`. Workspace authorization uses a secure, HTTP-only, SameSite cookie with an unguessable UUID. Clearing the browser cookie creates a new private workspace; this is not cross-device account authentication.

## Tests

- `npx tsx --test src/lib/safety/engine.test.ts`
- `PREVIEW_URL=https://your-running-preview node scripts/browser-check.mjs`

The browser suite needs Chromium (`npx playwright install chromium`, and system dependencies if necessary). It checks persistence, filtering, model calculations, sources, results, preferences, live analysis, dates, responsive overflow and JavaScript errors. Synthetic fixtures exist only in the test file, not in the live board.

Production validation: Next type generation, TypeScript `--noEmit`, `npm run build`, then the platform-managed build/start and `/api/health` check.

## Grading boundaries

Only archived official picks are eligible. No outcome uses Math.random. Final game identity, final score and exact selected statistic must agree with authoritative data. Scratches, postponements and unsupported settlement conditions stay pending. Statistical win/loss/push classification is not a promise of provider payout. Reviews annotate evidence; they do not automatically retrain an unvalidated model after one result.

## Attribution

Stadium: Stephen Leonardi / Pexels. Local Inter and Manrope fonts: Google Fonts, open-source font licenses. Sports marks belong to their respective owners. The application is not affiliated with leagues, ESPN, Underdog or The Odds API and does not accept wagers.
