// One-time bootstrap: seed Elo power ratings + recent form from real finals.
// Ratings are backward-looking by construction, so seeding them from past
// results is legitimate. Model *weights* are never touched here — they only
// move when real forward predictions get graded.
import { register } from 'node:module';
const isTs = true;
if (isTs) { await import('tsx/esm/api').catch(() => ({})); }
const { getSchedules } = await import('../src/lib/data/providers.ts');
const { applyResult } = await import('../src/lib/learn/ratings.ts');

const days = parseInt(process.argv[2] || '14', 10);
const toISO = (d) => d.toISOString().slice(0, 10);
const today = new Date();
let seeded = 0;
for (let back = days; back >= 1; back--) {
  const date = new Date(today.getTime() - back * 86400000);
  const iso = toISO(date);
  try {
    const { games } = await getSchedules(iso, 1);
    const finals = games
      .filter((g) => g.status === 'final' && g.homeScore !== undefined && g.awayScore !== undefined)
      .sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt));
    for (const g of finals) {
      await applyResult(g.sport, g.home.id, g.home.name, g.away.id, g.away.name, g.homeScore, g.awayScore, g.date);
      seeded++;
    }
    console.log(iso, 'finals:', finals.length);
  } catch (e) {
    console.log(iso, 'unavailable:', e.message);
  }
}
console.log(`Seeded ${seeded} finals into power ratings.`);
process.exit(0);
