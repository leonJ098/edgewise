// Self-cleaning end-to-end check of grade → evolve → restore.
// Inserts ONE test prediction for a real recent final, runs the learning
// cycle, asserts the grade + stats update, then removes every trace and
// restores ratings/stats so the live record stays honest.
import { eq } from 'drizzle-orm';
const { db } = await import('../src/db/index.ts');
const schema = await import('../src/db/schema.ts');
const { getSchedules } = await import('../src/lib/data/providers.ts');
const { learningCycle, evolveModel, getModelState } = await import('../src/lib/learn/evolve.ts');

const toISO = (d) => d.toISOString().slice(0, 10);
let target = null;
for (let back = 1; back <= 3 && !target; back--) {
  const iso = toISO(new Date(Date.now() - back * 86400000));
  console.log('checking', iso);
  const { games } = await getSchedules(iso, 1);
  console.log(iso, 'games:', games.length);
  target = games.find((g) => g.status === 'final' && g.homeScore !== undefined && g.awayScore !== undefined && g.homeScore !== g.awayScore);
}
if (!target) { console.log('SKIP: no decisive final found in last 6 days'); process.exit(0); }
console.log('Test game:', target.away.name, target.awayScore, '@', target.home.name, target.homeScore, target.date);

// Snapshot ratings + model state for the two teams / sport.
const snap = await db.select().from(schema.adaptiveTeamRatings);
const ratingSnap = new Map(snap.map((r) => [r.id, r]));
const stateBefore = await getModelState(target.sport);

// Insert a test prediction that picks the actual winner at 70%.
const homeWon = target.homeScore > target.awayScore;
const [row] = await db.insert(schema.adaptivePredictions).values({
  gameId: `test-${target.id}`, sport: target.sport, homeId: target.home.id, awayId: target.away.id,
  homeName: target.home.name, awayName: target.away.name, date: target.date, startsAt: new Date(target.startsAt),
  predictedSide: 'home', homeProb: homeWon ? 0.7 : 0.3, confidence: 0.7, tier: 'LOCK', edge: 20,
  features: { elo: 0.5, winPct: 0.3, form: 0.2, home: 1, rest: 0, streak: 0 },
  reasoning: ['Self-test prediction (deleted after verification).'], modelVersion: stateBefore.version,
}).returning();
// Point it at the real game id so grading finds the final.
await db.update(schema.adaptivePredictions).set({ gameId: target.id }).where(eq(schema.adaptivePredictions.id, row.id));

const cycle = await learningCycle(target.sport);
const [graded] = await db.select().from(schema.adaptivePredictions).where(eq(schema.adaptivePredictions.id, row.id));
console.log('Cycle graded:', cycle.graded, '| test row status:', graded.status, '| expected:', homeWon ? 'win' : 'loss');
if (graded.status !== (homeWon ? 'win' : 'loss')) throw new Error('Grade mismatch!');
const mid = await getModelState(target.sport);
console.log('Stats during test:', JSON.stringify(mid.stats), 'version:', mid.version);

// ── Restore: delete test row + any test lessons/evolution, restore ratings ──
await db.delete(schema.adaptivePredictions).where(eq(schema.adaptivePredictions.id, row.id));
await db.delete(schema.adaptiveLessons);
await db.delete(schema.adaptiveEvolution);
for (const id of [`${target.sport}:${target.home.id}`, `${target.sport}:${target.away.id}`]) {
  const s = ratingSnap.get(id);
  if (s) await db.update(schema.adaptiveTeamRatings).set({ rating: s.rating, games: s.games, wins: s.wins, losses: s.losses, streak: s.streak, recentForm: s.recentForm, lastGameDate: s.lastGameDate }).where(eq(schema.adaptiveTeamRatings.id, id));
}
await evolveModel(target.sport, 0);
const after = await getModelState(target.sport);
console.log('Stats after restore:', JSON.stringify(after.stats), 'version:', after.version);
if (after.stats.graded !== stateBefore.stats.graded || after.version !== stateBefore.version) throw new Error('Restore mismatch!');
console.log('VERIFY LEARNING: PASS — grade, evolve, and restore all correct.');
process.exit(0);
