# Edgewise — Max-Safety v2 data connections

## What works immediately

Real upcoming MLB games come from MLB Stats API. NFL schedules and exact week metadata come from the public ESPN site feed, an unofficial API with no service guarantee. All dates and official-pick day boundaries use America/New_York. Probable pitchers are explicitly not treated as confirmed starters. A passing leader is never treated as a confirmed starting quarterback.

Watchlists, private browser workspaces, notes, analysis snapshots, official selection archives and reviews are stored in PostgreSQL through Drizzle. This site does not accept bets or hold a bankroll.

No forecast, injury report, price or result is fabricated if a source is missing. No simulation enters official performance. Empty official cards are intentional.

## Environment variables (server only)

- `DATABASE_URL`: existing PostgreSQL connection.
- `ODDS_API_KEY`: The Odds API key. See https://the-odds-api.com/liveapi/guides/v4/ . Requests use h2h, American odds and source-market timestamps. MLB player props use bookmaker `underdog` only on the event-odds endpoint. Coverage and access depend on your subscription. Prop requests are limited to MLB games starting within 36 hours and are cached.
- `ANALYTICS_FEED_URL`: HTTPS URL of your authorized analytics pipeline, returning the contract below. This is a custom integration contract, not a claim that a bundled licensed statistical provider exists.
- `ANALYTICS_FEED_TOKEN`: optional bearer token for that feed.

Do not use NEXT_PUBLIC variables for secrets. Keys are never sent to the browser. Do not enter credentials in a public research note. Restart the application after changing its environment.

## Analytics feed contract

Response: an object with `reports`, an array of matchup-specific reports. Authoritative runtime validation is in `src/lib/safety/validation.ts` (`reportSchema`). A malformed feed is rejected, never guessed into shape. This endpoint must be configured by the application operator; browser users cannot submit official forecasts.

Each report includes:

| Field | Contract |
| --- | --- |
| gameId | Exact board ID, such as nfl-{ESPN event ID} or mlb-{MLB gamePk}. Doubleheaders have separate IDs. |
| sport | NFL or MLB |
| startsAt | ISO-8601 kickoff/first-pitch time matching the schedule |
| homeId, awayId | Exact provider team IDs, strings |
| generatedAt | ISO-8601 analysis time; cannot be future-dated |
| market | moneyline, pitcher_strikeouts, pitcher_outs, pitcher_earned_runs, batter_hits, batter_total_bases, batter_home_runs, team_total or f5_total |
| side | home or away: selected team or the player's team |
| player, playerId | Required in practice for player props; exact name and MLB ID |
| line, direction | Exact numeric threshold and over/under for props |
| factors | Object keyed by factor name. Each value contains rating (0–10), rationale (15+ characters), HTTPS sourceUrl, checkedAt timestamp. Ratings must come from documented current matchup analytics, not a team record alone. |
| evidence | Array of key, verified (boolean), detail (10+ characters), HTTPS sourceUrl and checkedAt. Evidence must cover both teams where applicable. |
| risks | Array of actual, identified risk keys; unknown risks force review |
| modeledRisks | Risk keys already represented in the risk-adjusted forecast and uncertainty interval |
| scripts | NFL requires control, close, trailing, underdogLead, turnovers. Each is a real matchup explanation of at least 15 characters. |
| upsetPaths | Explicit credible ways the selection loses; 2 or more blocks the max-safety card |
| strengths | At least two independently supported explanations |
| mainRisk | At least 15 characters; never “no risk” |
| correlationGroup | Common risk group across correlated selections; one per game is also enforced |
| probability | See the next section |
| entryEvaluation | Required for Underdog props; see DFS section |

### NFL factor keys and weights

qb 20, trenches 15, run 10, defense 15, injuries 10, form 10, environment 5, scripts 10, turnovers 5.

Use actual efficiency and opponent-adjusted metrics, OL/pass-rush interactions, replacement depth, recent 3/4/8 game context, coaching, rest, weather and game-script evidence. Recent three-game weights are 50/30/20; this is not a substitute for the season baseline. DVOA and proprietary metrics are optional if unavailable; never fabricate them.

### MLB factor keys and weights

starter 20, workload 20, matchup 15, bullpen 10, injuries 10, environment 10, form 5, stability 10.

Document FIP/xFIP/SIERA/xERA where available, K/BB/contact quality, pitch characteristics, actual lineup/platoons, recent pitch counts/innings and manager usage. Do not infer workload from pitcher quality. Explain the differing bullpen relevance of full-game versus F5 markets. The established/recent/matchup blend is 60/25/15.

### Required evidence keys

NFL: starters, backups, injuries, metrics, trenches, weather, scripts.

MLB: starters, lineup, injuries, workload, bullpen, park, weather, metrics.

Schedule, current exact line and model-calibration checks are derived by the server; a feed cannot simply mark them verified. Pitcher-outs Under additionally requires current `outs_restriction` evidence (pitch limit, recovery restriction or documented removal pattern). F5 and team-total decision support is documented, but official publishing remains disabled until an exact market/settlement adapter is supplied.

### Probability object

- estimate, lower, upper: decimal probabilities, with 0 < lower <= estimate <= upper < 1.
- riskModelVersion: `2.0.0`.
- modelVersion: actual provider model version.
- sourceUrl: HTTPS methodology/validation source.
- calibration: sampleSize (integer, minimum 200 held-out predictions), brierScore (0–1, must be below 0.25), method (10+ characters), trainedThrough, evaluationStart, evaluationEnd (ISO timestamps).

Training must precede the evaluation period, which must end before this game and not in the future. An already risk-adjusted forecast is not reduced by arbitrary percentage penalties again. The factor score is independent of probability. The site validates metadata and constraints; it does not independently audit or claim to have calibrated your external model. A Brier threshold is a minimum screen, not proof of reliable betting value. Audit calibration curves and compare a proper baseline before deploying any provider.

### DFS / Underdog

No book substitution. Matching requires exact player, market, direction and line, fresh within 15 minutes. A changed line invalidates the displayed prop probability until a matching forecast is supplied.

DFS indicative American prices are deliberately NOT converted into standalone leg break-even probabilities. Entry payout and dependence matter. `entryEvaluation` requires expectedReturnLower (decimal, at least 0.03), jointModel: true, rulesSourceUrl, checkedAt (within 15 minutes), and detail (30+ characters) documenting the actual entry payout rules and joint outcome model. Without that evidence, the prop cannot become official. Per-leg implied probability and edge remain unavailable.

### Risk keys

Hard passes: qb_uncertain, ol_crisis, starter_uncertain, lineup_uncertain, workload_uncertain, severe_weather, conflicting_signals, injury_uncertain, no_win_path, opener, unsustainable_form, one_player_dependency.

Safety-score penalties: early_hook (8), rookie (7), bullpen_tired (5), coors (6), low_total (5), thursday (3), travel (2), turnover_luck (4), high_k (5), total_bases (8), home_runs (12), two_hits (8), thin_total (8), low_volume (6), blowout (4), multiple_upsets (8, plus rejection).

These are conservative policy penalties, not fitted probability coefficients. Schedule-derived Thursday/Coors risks and market-derived volatility risks are added automatically. Every identified risk must also be represented in the probability model. Unknown risks block official status.

## Publication policy

- Same-day ET verification; future games are research/watch candidates only.
- At least 85/100 adjusted safety score; no missing factors.
- Conservative lower probability at least 68% NFL or 65% MLB; high-variance markets require 72%.
- Uncertainty interval at most 14 percentage points wide.
- Conservative price edge at least 2.5 points NFL or 4 points MLB, 8 points for higher-variance MLB markets.
- ML below -500 is rejected. Below -350 needs at least 95/100 and 4 points of conservative edge.
- NFL favorites from -110 to -160 need 90/100 plus at least a 9/10 QB/trenches/defense advantage.
- Maximum three daily picks; users may lower, not increase, this ceiling. One selection per game/shared risk group.
- A research calculator cannot publish official picks. Its numerical examples are explicitly uncalibrated.

These thresholds are versioned policy choices, not guarantees or claims of historical accuracy.

## Freshness

Schedules 20 min; exact quotes 15 min; model reports 60 min; starters/lineups/injuries 90 min; weather 60 min; backups/bullpen 180 min; workload/trenches/scripts 360 min; underlying metrics/park 720 min. Cache preserves original timestamps; failures do not advance them.

## Grading and learning

Only selections archived by a successful server-side analysis run can be graded. Original game identity, forecast, line and quote are immutable. Final scores/statistics are checked against the actual MLB/ESPN game; postponed, incomplete, mismatched or scratched-player cases remain pending rather than being simulated.

Moneyline compares the selected team's final margin. MLB props compare the exact final player statistic and original line. Innings such as 5.2 mean 17 outs, not 5.2 decimal innings. Statistical W/L/push grading is separate from provider-specific entry settlement. No payout is claimed.

Post-game reviews record supported causes (matchup, workload, hook, lineup, injury, bullpen, variance, sample, probability or price). They do not rewrite model coefficients after a single outcome. Brier score displays only after 10 graded win/loss forecasts, with sample size; meaningful validation requires much more data.

## Validation

Run `npx tsx --test src/lib/safety/engine.test.ts` for the deterministic policy/calculation regression suite. Test fixtures are synthetic and never loaded into the live board. Then run Next type generation, TypeScript checking, a production build, and the managed runtime healthcheck.
